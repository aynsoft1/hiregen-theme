<?php
/**
 * Job listing in the loop.
 *
 * This template can be overridden by copying it to yourtheme/job_manager/content-job_listing.php.
 *
 * @see         https://wpjobmanager.com/document/template-overrides/
 * @author      Automattic
 * @package     wp-job-manager
 * @category    Template
 * @since       1.0.0
 * @version     1.34.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

global $post;
?>
<li <?php job_listing_class(); ?> data-longitude="<?php echo esc_attr( isset( $post->geolocation_long ) ? $post->geolocation_long : '' ); ?>" data-latitude="<?php echo esc_attr( isset( $post->geolocation_lat ) ? $post->geolocation_lat : '' ); ?>">
	<?php
	/*
	 * Build a safe permalink. Prefer WP Job Manager getter if available,
	 * otherwise fall back to the post permalink.
	 */
	$job_permalink = '';
	if ( function_exists( 'get_the_job_permalink' ) ) {
		$job_permalink = get_the_job_permalink();
	}
	if ( empty( $job_permalink ) ) {
		$job_permalink = get_permalink( $post );
	}
	$job_permalink = esc_url( $job_permalink );
	?>
	<a href="<?php echo $job_permalink; ?>">
		<?php
		// the_company_logo() may output <img> HTML. Capture and allow only safe HTML.
		$company_logo_html = '';
		if ( function_exists( 'the_company_logo' ) ) {
			ob_start();
			the_company_logo();
			$company_logo_html = ob_get_clean();
		}
		// Allow only safe HTML tags for logo (img, src, alt, width, height, class, style).
		echo wp_kses( $company_logo_html, array(
			'img' => array(
				'src'    => array(),
				'alt'    => array(),
				'width'  => array(),
				'height' => array(),
				'class'  => array(),
				'style'  => array(),
				'srcset' => array(),
			),
		) );
		?>

		<div class="position">
			<?php
			// Job title: use the post title (safer) and escape.
			$job_title = get_the_title( $post );
			?>
			<h3><?php echo esc_html( $job_title ); ?></h3>

			<div class="company">
				<?php
				// the_company_name() may echo HTML (some themes/filters). Capture and sanitize.
				$company_name_html = '';
				if ( function_exists( 'the_company_name' ) ) {
					ob_start();
					the_company_name( '<div class="card-text">', '</div>' );
					$company_name_html = ob_get_clean();
				} else {
					// Best-effort fallback: try retrieving via post meta if WPJM stores it there.
					$company_name = get_post_meta( $post->ID, '_company_name', true );
					$company_name_html = $company_name ? '<div class="card-text">' . esc_html( $company_name ) . '</div>' : '';
				}
				// Allow minimal safe tags (e.g. <strong>) in company name output.
				echo wp_kses( $company_name_html, array( 'strong' => array() ) );
				?>

				<!-- Company tagline commented out in original. If you re-enable, escape it similarly:
				     $tagline = wp_strip_all_tags( get_post_meta( $post->ID, '_company_tagline', true ) );
				     echo '<span class="tagline">' . esc_html( $tagline ) . '</span>';
				-->
			</div>
		</div>

		<div class="location">
			<?php
			// the_job_location() can echo markup. Capture and escape as plain text to avoid XSS.
			$location_html = '';
			if ( function_exists( 'the_job_location' ) ) {
				ob_start();
				the_job_location( false );
				$location_html = ob_get_clean();
			} else {
				$location_html = get_post_meta( $post->ID, '_job_location', true );
			}
			// Strip tags and escape as plain text.
			echo esc_html( wp_strip_all_tags( $location_html ) );
			?>
		</div>

		<ul class="meta">
			<?php do_action( 'job_listing_meta_start' ); ?>

			<?php if ( get_option( 'job_manager_enable_types' ) ) { ?>
				<?php
				$types = array();
				if ( function_exists( 'wpjm_get_the_job_types' ) ) {
					$types = wpjm_get_the_job_types();
				}
				?>
				<?php if ( ! empty( $types ) ) : foreach ( $types as $type ) : ?>
					<li class="job-type <?php echo esc_attr( sanitize_title( $type->slug ) ); ?>"><?php echo esc_html( $type->name ); ?></li>
				<?php endforeach; endif; ?>
			<?php } ?>

			<!-- <li class="date"><?php the_job_publish_date(); ?></li> -->

			<?php do_action( 'job_listing_meta_end' ); ?>
		</ul>
	</a>
</li>
