// Go to Top Button
(function () {
    'use strict';

    const goTopBtn = document.getElementById('goTopBtn');
    if (!goTopBtn) return;

    // Show or hide the button
    window.addEventListener('scroll', function () {
        if (window.scrollY > 500) {
            goTopBtn.classList.add('show');
        } else {
            goTopBtn.classList.remove('show');
        }
    });

    // Smooth scroll to top
    goTopBtn.addEventListener('click', function () {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    });
})();
