<?php
/**
 * Admin notices for recommended/required plugins.
 *
 * Place this file in: inc/admin-notices.php
 * Make sure it's included from functions.php:
 * require_once HIREGEN_THEME_DIR . '/inc/admin-notices.php';
 *
 * Note: This file only displays notices. It does NOT register post types
 * or handle persistence — that must live in a plugin (hiregen-cpts).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Show notices recommending required plugins (WP Job Manager, Contact Form 7).
 */
if ( ! function_exists( 'hiregen_required_plugins_notice' ) ) {
    function hiregen_required_plugins_notice() {
        // Only show in admin area and to users who can install plugins.
        if ( ! is_admin() || ! current_user_can( 'install_plugins' ) ) {
            return;
        }

        $notices_html = '';

        // WP Job Manager: detect by main class
        if ( ! class_exists( 'WP_Job_Manager' ) ) {
            $msg    = esc_html__( 'To enable job support, install WP Job Manager.', 'hiregen-recruitment' );
            $link   = esc_url( admin_url( 'plugin-install.php?s=wp+job+manager&tab=search&type=term' ) );
            $anchor = esc_html__( 'Install WP Job Manager', 'hiregen-recruitment' );

            $notices_html .= sprintf(
                '<div class="notice notice-warning is-dismissible"><p>%s &nbsp; <a href="%s">%s</a></p></div>',
                $msg,
                $link,
                $anchor
            );
        }

        // Contact Form 7: detect by version constant
        if ( ! defined( 'WPCF7_VERSION' ) ) {
            $msg    = esc_html__( 'To enable contact forms, install Contact Form 7.', 'hiregen-recruitment' );
            $link   = esc_url( admin_url( 'plugin-install.php?s=contact+form+7&tab=search&type=term' ) );
            $anchor = esc_html__( 'Install Contact Form 7', 'hiregen-recruitment' );

            $notices_html .= sprintf(
                '<div class="notice notice-warning is-dismissible"><p>%s &nbsp; <a href="%s">%s</a></p></div>',
                $msg,
                $link,
                $anchor
            );
        }

        if ( $notices_html ) {
            echo wp_kses_post( $notices_html );
        }
    }

    add_action( 'admin_notices', 'hiregen_required_plugins_notice' );
}


/**
 * Admin notice: inform admin to activate the Hiregen CPT plugin if not active.
 *
 * This notice is intentionally light-weight and does NOT register any CPTs.
 */
if ( ! function_exists( 'hiregen_modal_plugin_admin_notice' ) ) {
    function hiregen_modal_plugin_admin_notice() {
        // Only show in admin and to users who can activate plugins
        if ( ! is_admin() || ! current_user_can( 'activate_plugins' ) ) {
            return;
        }

        // Ensure is_plugin_active() is available
        if ( ! function_exists( 'is_plugin_active' ) ) {
            include_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        // Check common plugin path variants:
        // - single-file plugin placed at: wp-content/plugins/hiregen-cpts.php
        // - folder plugin: wp-content/plugins/hiregen-cpts/hiregen-cpts.php
        $plugin_paths = array(
            'hiregen-cpts.php',
            'hiregen-cpts/hiregen-cpts.php',
        );

        $is_active = false;
        foreach ( $plugin_paths as $p ) {
            if ( is_plugin_active( $p ) ) {
                $is_active = true;
                break;
            }
        }

        if ( $is_active ) {
            return;
        }

        $plugins_page = esc_url( admin_url( 'plugins.php' ) );
        /* translators: %s: plugins page URL */
        $message = sprintf(
            /* translators: 1: link to Plugins page */
            __( 'Hiregen theme: To store modal submissions please install & activate the <strong>Hiregen CPTs</strong> plugin. Go to <a href="%1$s">Plugins → Installed Plugins</a> to activate it.', 'hiregen-recruitment' ),
            $plugins_page
        );

        // Output safe HTML (trusted small markup only)
        echo '<div class="notice notice-warning is-dismissible"><p>' . wp_kses_post( $message ) . '</p></div>';
    }

    add_action( 'admin_notices', 'hiregen_modal_plugin_admin_notice' );
}
