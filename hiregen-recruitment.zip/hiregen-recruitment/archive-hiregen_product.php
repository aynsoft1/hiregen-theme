<?php
/**
 * Archive template for hiregen_product CPT
 * Place this file in your theme root: archive-hiregen_product.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header();
?>

<?php
// Sub Header Section
?>

<div class="sub-header py-4">
  <div class="container">
    <?php
    // Get the "Our Products" section title from Customizer
    $products_title = get_theme_mod( 'hiregen_products_title', '' );

    if ( ! empty( $products_title ) ) {
        $title_to_show = $products_title;
    } else {
        // fallback: default archive title; ensure it returns a string
        $title_to_show = (string) get_the_archive_title();
    }
    ?>

    <h1 class="entry-title fw-bold"><?php echo wp_kses_post( $title_to_show ); ?></h1>

    <div class="breadcrumb mb-0" aria-label="<?php echo esc_attr__( 'Breadcrumb', 'hiregen-recruitment' ); ?>">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color:inherit;"><?php esc_html_e( 'Home', 'hiregen-recruitment' ); ?></a>
        &nbsp;→&nbsp;
        <?php echo esc_html( wp_strip_all_tags( $title_to_show ) ); ?>
    </div>
  </div>
</div>


<main id="main" class="site-main py-4" role="main">
  <div class="container">

    <?php
    // Use main query (archive)
    if ( have_posts() ) : ?>
      <div class="row row-cols-1 row-cols-md-3 g-4">
        <?php while ( have_posts() ) : the_post(); ?>

          <?php
          // product meta - sanitize/normalize values
          $post_id   = get_the_ID();
          $currency  = (string) get_post_meta( $post_id, 'product_currency', true );
          $regular   = get_post_meta( $post_id, 'product_regular_price', true );
          $sale      = get_post_meta( $post_id, 'product_sale_price', true );
          $buy_url   = get_post_meta( $post_id, 'product_button_url', true );
          $shortdesc = get_post_meta( $post_id, 'product_desc', true );

          // Symbols map (keep server-side)
          $symbols = array(
              'INR' => '₹',
              'USD' => '$',
              'EUR' => '€',
              'GBP' => '£',
              'JPY' => '¥',
          );
          $symbol = isset( $symbols[ $currency ] ) ? $symbols[ $currency ] : '';

          // Prepare safe permalink and title
          $permalink = esc_url( get_permalink( $post_id ) );
          $title     = get_the_title( $post_id );
          ?>

          <div class="col">
            <article id="post-<?php echo (int) $post_id; ?>" <?php post_class( 'card p-3 shadow-sm' ); ?>>

              <?php
              // Featured image or fallback
              if ( has_post_thumbnail( $post_id ) ) {
                  // Get alt text from title; ensure not echoed by the_title_attribute
                  $alt_text = the_title_attribute( array( 'echo' => false, 'post' => $post_id ) );
                  ?>
                  <a href="<?php echo $permalink; ?>" class="d-block">
                    <?php
                    // let WP output responsive img markup; pass class and alt attributes
                    the_post_thumbnail( 'hiregen-product', array(
                        'class'   => 'card-img-top img-fluid',
                        'alt'     => esc_attr( $alt_text ),
                        'loading' => 'lazy',
                    ) );
                    ?>
                  </a>
                  <?php
              } else {
                  $fallback_url = esc_url( get_template_directory_uri() . '/assets/images/fallback-product.png' );
                  $fallback_alt = esc_attr( get_bloginfo( 'name' ) . ' product image' );
                  ?>
                  <a href="<?php echo $permalink; ?>" class="d-block">
                    <img src="<?php echo $fallback_url; ?>" class="card-img-top img-fluid" alt="<?php echo $fallback_alt; ?>" loading="lazy" />
                  </a>
                  <?php
              }
              ?>

              <div class="card-body d-flex flex-column">
                <h5>
                  <a href="<?php echo $permalink; ?>">
                    <?php echo esc_html( $title ); ?>
                  </a>
                </h5>

                <?php if ( ! empty( $shortdesc ) ) : ?>
                  <p><?php echo wp_kses_post( wp_trim_words( $shortdesc, 30, '...' ) ); ?></p>
                <?php else : ?>
                  <p><?php echo wp_kses_post( wp_trim_words( get_the_excerpt(), 30, '...' ) ); ?></p>
                <?php endif; ?>

                <div class="mt-auto d-flex justify-content-between align-items-center">
                  <div class="price" aria-hidden="false">
                    <?php
                    // Normalize numeric prices for safe display
                    $regular_val = is_numeric( $regular ) ? floatval( $regular ) : null;
                    $sale_val    = is_numeric( $sale ) ? floatval( $sale ) : null;

                    if ( $regular_val !== null && $sale_val !== null && $sale_val < $regular_val ) : ?>
                      <del class="text-muted me-2"><?php echo esc_html( $symbol . number_format_i18n( $regular_val, 2 ) ); ?></del>
                      <ins class="fw-bold text-success"><?php echo esc_html( $symbol . number_format_i18n( $sale_val, 2 ) ); ?></ins>
                    <?php elseif ( $sale_val !== null ) : ?>
                      <ins class="fw-bold text-success"><?php echo esc_html( $symbol . number_format_i18n( $sale_val, 2 ) ); ?></ins>
                    <?php elseif ( $regular_val !== null ) : ?>
                      <span class="fw-bold"><?php echo esc_html( $symbol . number_format_i18n( $regular_val, 2 ) ); ?></span>
                    <?php endif; ?>
                  </div>

                  <?php if ( ! empty( $buy_url ) ) : ?>
                    <a href="<?php echo esc_url( $buy_url ); ?>"
                       class="btn btn-primary"
                       target="_blank"
                       rel="noopener noreferrer"
                       aria-label="<?php echo esc_attr( sprintf( esc_html__( 'Buy %s now', 'hiregen-recruitment' ), wp_strip_all_tags( $title ) ) ); ?>">
                       <?php esc_html_e( 'Buy Now', 'hiregen-recruitment' ); ?>
                    </a>
                  <?php else : ?>
                    <a href="<?php echo $permalink; ?>"
                       class="btn btn-outline-secondary btn-sm"
                       aria-label="<?php echo esc_attr( sprintf( esc_html__( 'View %s details', 'hiregen-recruitment' ), wp_strip_all_tags( $title ) ) ); ?>">
                       <?php esc_html_e( 'View', 'hiregen-recruitment' ); ?>
                    </a>
                  <?php endif; ?>

                </div>
              </div>
            </article>
          </div>

        <?php endwhile; ?>

        <?php
        // restore global post data
        wp_reset_postdata();
        ?>
      </div>

      <!-- Pagination -->
      <div class="mt-5">
        <?php
        the_posts_pagination( array(
            'mid_size'  => 2,
            'prev_text' => esc_html__( '← Prev', 'hiregen-recruitment' ),
            'next_text' => esc_html__( 'Next →', 'hiregen-recruitment' ),
            'screen_reader_text' => esc_html__( 'Product navigation', 'hiregen-recruitment' ),
        ) );
        ?>
      </div>

    <?php else : ?>

      <div class="alert alert-warning" role="status">
        <?php esc_html_e( 'No products found.', 'hiregen-recruitment' ); ?>
      </div>

    <?php endif; ?>

  </div>
</main>

<?php get_footer(); ?>
