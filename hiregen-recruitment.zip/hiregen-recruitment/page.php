<?php
/**
 * Default Page Template (safe & sanitized)
 * Place in: wp-content/themes/your-active-theme/page.php
 *
 * - Escapes page title output
 * - Avoids duplicating title in breadcrumb
 * - Sanitises page-based JobPosting JSON-LD (if used as job)
 * - Uses the_content() so filters/blocks run normally
 * - Adds roles/aria attributes for landmarks
 */

defined( 'ABSPATH' ) || exit;
get_header();
?>

<?php
// -----------------------------
// Sub Header / Breadcrumb area
// -----------------------------
$raw_title = get_the_title( get_queried_object_id() );
$safe_title = $raw_title ? wp_strip_all_tags( $raw_title ) : get_bloginfo( 'name' );

$breadcrumb_parts = array();
$breadcrumb_parts[] = '<a href="' . esc_url( home_url( '/' ) ) . '" rel="home">' . esc_html__( 'Home', 'hiregen-recruitment' ) . '</a>';

// We intentionally do not echo the page title inside the breadcrumb to avoid duplication with the H1.
// If you prefer to include it, append it here with esc_html().
$breadcrumb_html = implode( ' <span class="breadcrumb-sep" aria-hidden="true">→</span> ', $breadcrumb_parts );
?>

<div class="sub-header py-4">
  <div class="container">
    <h1 class="entry-title fw-bold"><?php echo esc_html( $safe_title ); ?></h1>

    <div class="breadcrumb mb-0" aria-label="<?php esc_attr_e( 'Breadcrumb', 'hiregen-recruitment' ); ?>">
      <?php echo wp_kses( $breadcrumb_html, array(
              'a' => array( 'href' => array(), 'rel' => array(), 'title' => array() ),
              'span' => array( 'class' => array(), 'aria-hidden' => array() ),
          ) );
      ?>
    </div>
  </div>
</div>

<main id="main" class="site-main page-default py-4" role="main" aria-labelledby="page-title">
  <div class="container">
    <?php
    if ( have_posts() ) :
      while ( have_posts() ) : the_post();

        // ----------------------------
        // JOBPOSTING JSON-LD for pages used as jobs
        // ----------------------------
        $post_id = get_the_ID();
        $is_job = ( 'job_listing' === get_post_type( $post_id ) ) || get_post_meta( $post_id, '_is_job_posting', true );

        if ( $is_job ) {
            $title_raw      = get_the_title( $post_id );
            $description_raw = get_the_excerpt() ? get_the_excerpt() : wp_trim_words( wp_strip_all_tags( get_the_content( null, false, $post_id ) ), 30, '...' );
            $date_posted    = get_the_date( 'c', $post_id );
            $valid_through  = get_post_meta( $post_id, '_job_expires', true );
            $employment     = get_post_meta( $post_id, '_job_type', true );
            $salary_amount  = get_post_meta( $post_id, '_job_salary', true );
            $salary_currency = get_post_meta( $post_id, '_job_salary_currency', true ) ?: 'INR';

            $org_name = get_post_meta( $post_id, '_hiring_organization', true );
            if ( empty( $org_name ) ) {
                $org_name = get_bloginfo( 'name' );
            }

            $job_location = get_post_meta( $post_id, '_job_location', true );
            $remote_flag  = get_post_meta( $post_id, '_job_remote', true );

            $job_posting = array(
                '@context' => 'https://schema.org/',
                '@type'    => 'JobPosting',
                'title'    => wp_strip_all_tags( $title_raw ),
                'description' => wp_strip_all_tags( $description_raw ),
                'datePosted'  => $date_posted,
                'hiringOrganization' => array(
                    '@type' => 'Organization',
                    'name'  => wp_strip_all_tags( $org_name ),
                    'sameAs'=> esc_url_raw( home_url() ),
                ),
                'identifier' => array(
                    '@type' => 'PropertyValue',
                    'name'  => wp_strip_all_tags( get_bloginfo( 'name' ) ),
                    'value' => (string) $post_id,
                ),
                'employmentType' => $employment ? sanitize_text_field( $employment ) : null,
                'validThrough'   => $valid_through ? sanitize_text_field( $valid_through ) : null,
                'jobLocation'    => null,
                'url'            => esc_url_raw( get_permalink( $post_id ) ),
            );

            if ( $salary_amount ) {
                if ( is_numeric( $salary_amount ) ) {
                    $job_posting['baseSalary'] = array(
                        '@type'    => 'MonetaryAmount',
                        'currency' => sanitize_text_field( $salary_currency ),
                        'value'    => array(
                            '@type' => 'QuantitativeValue',
                            'value' => (float) $salary_amount,
                            'unitText' => get_post_meta( $post_id, '_job_salary_unit', true ) ?: 'MONTH',
                        ),
                    );
                } else {
                    $job_posting['baseSalary'] = wp_strip_all_tags( $salary_amount );
                }
            }

            if ( $remote_flag ) {
                $job_posting['jobLocationType'] = 'TELECOMMUTE';
            } elseif ( $job_location ) {
                $job_posting['jobLocation'] = array(
                    '@type' => 'Place',
                    'address' => array(
                        '@type' => 'PostalAddress',
                        'addressLocality' => wp_strip_all_tags( $job_location ),
                    ),
                );
            }

            // Allow filter for modifications by plugins/themes
            $job_posting = apply_filters( 'hiregen_jobposting_json', $job_posting, get_post( $post_id ) );

            // Remove empty/null entries (recursive)
            $filter_empty = function ( $arr ) use ( &$filter_empty ) {
                if ( ! is_array( $arr ) ) {
                    return $arr;
                }
                foreach ( $arr as $k => $v ) {
                    if ( $v === null || $v === '' ) {
                        unset( $arr[ $k ] );
                        continue;
                    }
                    if ( is_array( $v ) ) {
                        $arr[ $k ] = $filter_empty( $v );
                        if ( empty( $arr[ $k ] ) ) {
                            unset( $arr[ $k ] );
                        }
                    }
                }
                return $arr;
            };

            $job_posting = $filter_empty( $job_posting );

            echo '<script type="application/ld+json">' . wp_json_encode( $job_posting, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
        }
        ?>

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
          <div class="entry-content">
            <?php
            // Use the_content() so blocks, shortcodes, and filters are applied.
            the_content();

            wp_link_pages( array(
              'before' => '<nav class="page-links"><span class="fw-semibold">' . esc_html__( 'Pages:', 'hiregen-recruitment' ) . '</span>',
              'after'  => '</nav>',
            ) );
            ?>
          </div>
        </article>

      <?php
      endwhile;
    endif;
    ?>
  </div>
</main>

<?php
get_footer();
