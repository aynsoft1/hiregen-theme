( function( $, api ) {
    'use strict';

    // helper to update CSS variable on :root
    function updateCSSVar( name, value ) {
        if ( document && document.documentElement ) {
            document.documentElement.style.setProperty( name, value );
        }
    }

    // helper to safely set a style rule inside the <style id="hiregen-badge-color"> if present
    function updateBadgeStyleTag( cssText ) {
        var styleEl = document.getElementById( 'hiregen-badge-color' );
        if ( styleEl ) {
            // replace contents
            styleEl.textContent = cssText;
            return true;
        }
        return false;
    }

    // helper to set inline max-width on a NodeList of images
    function setLogoMaxWidth( nodeList, pxValue ) {
        if ( ! nodeList || ! nodeList.length ) {
            return;
        }
        for ( var i = 0; i < nodeList.length; i++ ) {
            try {
                // prefer max-width with important so theme CSS less likely to override
                nodeList[ i ].style.setProperty( 'max-width', pxValue + 'px', 'important' );
                nodeList[ i ].style.setProperty( 'height', 'auto', 'important' );
                // ensure display isn't collapsed
                if ( ! nodeList[ i ].style.display ) {
                    nodeList[ i ].style.display = 'inline-block';
                }
            } catch ( e ) {
                // fallback: set plain values
                nodeList[ i ].style.maxWidth = pxValue + 'px';
                nodeList[ i ].style.height = 'auto';
                nodeList[ i ].style.display = nodeList[ i ].style.display || 'inline-block';
            }
        }
    }

    // main binding for badge color
    if ( typeof api === 'function' ) {
        api( 'hiregen_badge_color', function( value ) {
            value.bind( function( newval ) {
                if ( ! newval ) {
                    return;
                }

                // 1) Update style tag if present (this will honor !important)
                var cssRule = ".badge-custom{ background: " + newval + " !important; }";
                updateBadgeStyleTag( cssRule );

                // 2) Update CSS variable (optional)
                updateCSSVar( '--hiregen-badge', newval );

                // 3) Update existing .badge-custom elements directly and set priority important
                var els = document.querySelectorAll( '.badge-custom' );
                for ( var i = 0; i < els.length; i++ ) {
                    try {
                        els[ i ].style.setProperty( 'background', newval, 'important' );
                    } catch ( e ) {
                        // fallback to plain style if something odd happens
                        els[ i ].style.background = newval;
                    }
                }
            } );
        } );

        // live-update for header logo size (pixels)
        api( 'hiregen_header_logo_size', function( value ) {
            value.bind( function( newVal ) {
                if ( typeof newVal === 'undefined' || newVal === null || newVal === '' ) {
                    return;
                }
                // selectors: adjust to your theme's actual logo elements if needed
                var headerImgs = document.querySelectorAll( '.navbar-brand img, .header-logo img, .site-header img, .site-branding img' );
                setLogoMaxWidth( headerImgs, newVal );
            } );
        } );

        // live-update for footer logo size (pixels)
        api( 'hiregen_footer_logo_size', function( value ) {
            value.bind( function( newVal ) {
                if ( typeof newVal === 'undefined' || newVal === null || newVal === '' ) {
                    return;
                }
                // selectors: .footer-logo img is the wrapper we added in footer.php; include common fallbacks
                var footerImgs = document.querySelectorAll( '.footer-logo img, .site-footer img, .site-footer .footer-logo img' );
                setLogoMaxWidth( footerImgs, newVal );
            } );
        } );
    }

} )( jQuery, wp.customize );
