<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php echo esc_attr( get_bloginfo( 'charset' ) ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">

<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'hiregen-recruitment' ); ?></a>

<?php
$header_bg = get_theme_mod( 'hiregen_header_bg', '' );
$header_style = '';
if ( ! empty( $header_bg ) ) {
    $header_style = 'background-color: ' . esc_attr( $header_bg ) . ';';
}

/* Safe wrapper for custom theme mod helper: prefer theme function if present. */
if ( ! function_exists( 'hiregen_safe_theme_mod' ) ) {
    function hiregen_safe_theme_mod( $name, $fallback = '' ) {
        if ( function_exists( 'hiregen_get_theme_mod' ) ) {
            $val = hiregen_get_theme_mod( $name, $fallback );
        } else {
            $val = get_theme_mod( $name, $fallback );
        }
        return $val;
    }
}
?>

<header id="masthead" class="site-header py4" role="banner" <?php if ( $header_style ) : ?>style="<?php echo esc_attr( $header_style ); ?>"<?php endif; ?>>
  <nav class="navbar navbar-expand-lg" role="navigation" aria-label="<?php esc_attr_e( 'Primary navigation', 'hiregen-recruitment' ); ?>">
    <div class="container">
      <a class="navbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
        <?php
        $site_name   = get_bloginfo( 'name' );
        $is_home_h1  = is_front_page() || is_home();

        if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
            the_custom_logo();
        } else {
            $logo = get_theme_mod( 'hiregen_header_logo' );
            if ( $logo ) {
                $logo_size = absint( get_theme_mod( 'hiregen_header_logo_size', 180 ) );
                echo '<img src="' . esc_url( $logo ) . '" alt="' . esc_attr( $site_name ) . '" style="max-width:' . $logo_size . 'px; height:auto; display:block;">';
            } else {
                if ( $is_home_h1 ) {
                    echo '<h1 class="site-title m-0">' . esc_html( $site_name ) . '</h1>';
                } else {
                    echo '<span class="site-title">' . esc_html( $site_name ) . '</span>';
                }
            }
        }
        ?>
      </a>

      <button class="navbar-toggler" type="button"
              data-bs-toggle="collapse"
              data-bs-target="#hiregenPrimaryMenu"
              aria-controls="hiregenPrimaryMenu"
              aria-expanded="false"
              aria-label="<?php echo esc_attr( __( 'Toggle navigation', 'hiregen-recruitment' ) ); ?>">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="hiregenPrimaryMenu">
        <?php
        // Only call wp_nav_menu when a menu is assigned to 'primary' to satisfy Theme Check.
        if ( has_nav_menu( 'primary' ) ) {

            wp_nav_menu( array(
                'theme_location' => 'primary',
                'container'      => false,
                'menu_class'     => 'navbar-nav ms-auto',
                'depth'          => 2,
                'fallback_cb'    => 'wp_page_menu',
                // 'walker' => new WP_Bootstrap_Navwalker(), // add if you have a Bootstrap-5-ready walker
            ) );

        } else {
            // Fallback markup using wp_page_menu — kept minimal and with classes so CSS/JS can operate.
            wp_page_menu( array(
                'menu_class' => 'navbar-nav ms-auto',
                'show_home'  => true,
            ) );
        }
        ?>

        <?php
            // CTA button
            $cta_text = hiregen_safe_theme_mod( 'hiregen_header_cta_text', __( 'Get Started', 'hiregen-recruitment' ) );
            $cta_url  = hiregen_safe_theme_mod( 'hiregen_header_cta_url', home_url( '/' ) );

            $aria_context = is_singular() ? get_the_title( get_queried_object_id() ) : get_bloginfo( 'name' );
            $safe_aria_label = sprintf( esc_html__( '%1$s about %2$s', 'hiregen-recruitment' ), $cta_text, $aria_context );
        ?>
        <a href="<?php echo esc_url( $cta_url ); ?>"
           class="btn btn-primary ms-3"
           aria-label="<?php echo esc_attr( $safe_aria_label ); ?>">
           <?php echo esc_html( $cta_text ); ?> &rarr;
        </a>

      </div>
    </div>
  </nav>
</header>
