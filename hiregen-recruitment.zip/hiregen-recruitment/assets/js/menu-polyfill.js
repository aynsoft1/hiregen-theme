(function(){
  try {
    document.addEventListener('DOMContentLoaded', function () {
      var selectors = ['.navbar-nav .menu-item-has-children > a', '.navbar-nav .page_item_has_children > a'];
      var items = [];
      selectors.forEach(function(s){ document.querySelectorAll(s).forEach(function(e){ items.push(e); }); });
      items.forEach(function(a){
        if (!a) return;
        if (!a.hasAttribute('data-bs-toggle')) {
          a.setAttribute('data-bs-toggle', 'dropdown');
          a.classList.add('dropdown-toggle');
          a.setAttribute('aria-expanded', 'false');
        }
        if (!a.classList.contains('nav-link')) a.classList.add('nav-link');
        var li = a.closest('li');
        if ( li ) {
          if (!li.classList.contains('dropdown')) li.classList.add('dropdown');
          if (!li.classList.contains('nav-item')) li.classList.add('nav-item');
          var submenu = li.querySelector('.sub-menu, .children');
          if ( submenu && ! submenu.classList.contains('dropdown-menu') ) {
            submenu.classList.add('dropdown-menu');
            submenu.querySelectorAll('a').forEach(function(c){ if (!c.classList.contains('dropdown-item')) c.classList.add('dropdown-item'); });
          }
        }
      });
    });
  } catch(e) { if (window.console) console.error('Hiregen menu polyfill error:', e); }
})();
