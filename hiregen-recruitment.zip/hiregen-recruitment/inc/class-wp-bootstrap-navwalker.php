<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
/**
 * Minimal WP_Bootstrap_Navwalker for Bootstrap 5 (defensive version)
 * File: inc/class-wp-bootstrap-navwalker.php
 */

if ( ! class_exists( 'WP_Bootstrap_Navwalker' ) ) :

class WP_Bootstrap_Navwalker extends Walker_Nav_Menu {

    public function start_lvl( &$output, $depth = 0, $args = array() ) {
        $indent = str_repeat("\t", $depth);
        $submenu = ($depth > 0) ? ' sub-menu' : '';
        $output .= "\n$indent<ul class=\"dropdown-menu$submenu\" aria-labelledby=\"\">\n";
    }

    public function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
        $indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';
        $li_classes = array( 'nav-item' );
        $a_classes  = array( 'nav-link' );

        // Ensure $item->classes is an array before using it
        $item_classes = array();
        if ( isset( $item->classes ) && is_array( $item->classes ) ) {
            $item_classes = $item->classes;
        }

        if ( in_array( 'menu-item-has-children', $item_classes, true ) ) {
            $li_classes[] = 'dropdown';
            if ( 0 === (int) $depth ) {
                $a_classes[] = 'dropdown-toggle';
            }
        }

        if ( $depth > 0 ) {
            $a_classes = array( 'dropdown-item' );
        }

        $li_class_names = implode( ' ', array_filter( $li_classes ) );
        $a_class_names  = implode( ' ', array_filter( $a_classes ) );

        $output .= $indent . '<li class="' . esc_attr( $li_class_names ) . '">';

        $atts = array();
        $atts['title']  = ! empty( $item->attr_title ) ? $item->attr_title : '';
        $atts['target'] = ! empty( $item->target ) ? $item->target : '';
        $atts['rel']    = ! empty( $item->xfn ) ? $item->xfn : '';
        $atts['href']   = ! empty( $item->url ) ? $item->url : '';

        if ( in_array( 'menu-item-has-children', $item_classes, true ) && 0 === (int) $depth ) {
            $atts['role']            = 'button';
            $atts['data-bs-toggle']  = 'dropdown';
            $atts['aria-expanded']   = 'false';
        }

        $attributes = '';
        foreach ( $atts as $attr => $value ) {
            if ( ! empty( $value ) ) {
                $value = ( 'href' === $attr ) ? esc_url( $value ) : esc_attr( $value );
                $attributes .= ' ' . $attr . '="' . $value . '"';
            }
        }

        $title = apply_filters( 'the_title', $item->title, $item->ID );

        $item_output  = $args->before;
        $item_output .= '<a class="' . esc_attr( $a_class_names ) . '"' . $attributes . '>';
        $item_output .= $args->link_before . $title . $args->link_after;
        $item_output .= '</a>';
        $item_output .= $args->after;

        $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
    }

    public function end_el( &$output, $item, $depth = 0, $args = array() ) {
        $output .= "</li>\n";
    }
}

endif;
