<?php
/**
 * index.php - Default fallback template
 * Used when no more specific template (home.php, archive.php, etc.) matches a query.
 * Sanitized, escaped, and accessibility-ready.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

get_header();
?>

<main id="main" class="site-main container py-5" role="main">
  <?php if ( have_posts() ) : ?>
    <?php while ( have_posts() ) : the_post(); ?>
      <?php
      $post_id     = get_the_ID();
      $post_title  = get_the_title( $post_id );
      $permalink   = get_permalink( $post_id );
      $post_title  = $post_title ? $post_title : sprintf( __( 'Post #%d', 'hiregen-recruitment' ), $post_id );
      ?>

      <article id="post-<?php echo esc_attr( $post_id ); ?>" <?php post_class( 'mb-5 border-bottom pb-4' ); ?>>
        <header class="entry-header mb-3">
          <h2 class="entry-title fw-bold h4">
            <a href="<?php echo esc_url( $permalink ); ?>"
               class="text-decoration-none"
               aria-label="<?php echo esc_attr( sprintf( __( 'Read more about %s', 'hiregen-recruitment' ), $post_title ) ); ?>">
              <?php echo esc_html( $post_title ); ?>
            </a>
          </h2>
        </header>

        <div class="entry-summary mb-3 text-muted">
          <?php
          if ( has_excerpt( $post_id ) ) {
              echo wp_kses_post( wpautop( get_the_excerpt() ) );
          } else {
              echo wp_kses_post( wpautop( wp_trim_words( get_the_content(), 40, '...' ) ) );
          }
          ?>
        </div>

        <p>
          <a href="<?php echo esc_url( $permalink ); ?>" class="btn btn-outline-secondary btn-sm" role="button">
            <?php esc_html_e( 'Read More', 'hiregen-recruitment' ); ?>
          </a>
        </p>
      </article>

    <?php endwhile; ?>

    <div class="mt-5 d-flex justify-content-center">
      <?php
      the_posts_pagination( array(
          'mid_size'  => 2,
          'prev_text' => __( '← Prev', 'hiregen-recruitment' ),
          'next_text' => __( 'Next →', 'hiregen-recruitment' ),
      ) );
      ?>
    </div>

  <?php else : ?>
    <section class="no-results text-center py-5">
      <h2><?php esc_html_e( 'No posts found', 'hiregen-recruitment' ); ?></h2>
      <p><?php esc_html_e( 'Try searching with different keywords or browse the site navigation.', 'hiregen-recruitment' ); ?></p>
    </section>
  <?php endif; ?>
</main>

<?php get_footer(); ?>
