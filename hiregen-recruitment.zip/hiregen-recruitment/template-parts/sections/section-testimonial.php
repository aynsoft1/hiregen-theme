<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Testimonial section - displays hiregen_testimonial CPT
 * Shows responsive cards
 *
 * - sanitizes theme_mod values
 * - safe URL resolution for button
 * - escapes all outputs
 * - wraps helper functions to avoid redeclaration
 *
 * @package Hiregen
 */

// Theme mod values (sanitize)
$bg_raw      = get_theme_mod( 'hiregen_testimonial_bg', '#ffffff' );
$bg          = sanitize_hex_color( $bg_raw ) ?: esc_attr( $bg_raw );
$subtitle    = sanitize_text_field( get_theme_mod( 'hiregen_testimonial_subtitle', '' ) );
$title_raw   = get_theme_mod( 'hiregen_testimonial_title', __( 'Testimonials', 'hiregen-recruitment' ) );
$title       = $title_raw ? wp_kses_post( $title_raw ) : __( 'Testimonials', 'hiregen-recruitment' );
$desc        = wp_kses_post( get_theme_mod( 'hiregen_testimonial_description', '' ) );
$count       = absint( get_theme_mod( 'hiregen_testimonial_count', 3 ) );
$btn_text_raw = get_theme_mod( 'hiregen_testimonial_btn_text', __( 'Read more', 'hiregen-recruitment' ) );
$btn_text     = $btn_text_raw ? wp_kses_post( $btn_text_raw ) : __( 'Read more', 'hiregen-recruitment' );
$saved_btn_url = trim( (string) get_theme_mod( 'hiregen_testimonial_btn_url', '' ) );

// Default archive fallback
$default_archive = get_post_type_archive_link( 'hiregen_testimonial' );

// Helper: check for full URL / relative / anchor
if ( ! function_exists( 'hiregen_is_full_url' ) ) {
    function hiregen_is_full_url( $u ) {
        return ( strpos( $u, 'http://' ) === 0 || strpos( $u, 'https://' ) === 0 );
    }
}

if ( ! function_exists( 'hiregen_is_relative_slug' ) ) {
    function hiregen_is_relative_slug( $u ) {
        if ( empty( $u ) ) {
            return false;
        }
        $u = trim( $u );
        if ( strpos( $u, '#' ) === 0 || stripos( $u, 'mailto:' ) === 0 || stripos( $u, 'tel:' ) === 0 ) {
            return false;
        }
        if ( strpos( $u, '://' ) === false && stripos( $u, 'http' ) === false ) {
            return true;
        }
        return false;
    }
}

// Resolve button URL safely
$btn_url = '';

if ( $saved_btn_url && hiregen_is_full_url( $saved_btn_url ) ) {
    $btn_url = esc_url_raw( $saved_btn_url );
}

if ( empty( $btn_url ) && hiregen_is_relative_slug( $saved_btn_url ) ) {
    $slug = trim( $saved_btn_url, '/' );
    if ( $slug !== '' ) {
        $page = get_page_by_path( $slug, OBJECT, 'page' );
        if ( $page ) {
            $btn_url = get_permalink( $page->ID );
        }
    }
}

if ( empty( $btn_url ) && $saved_btn_url ) {
    if ( strpos( $saved_btn_url, '#' ) === 0 || stripos( $saved_btn_url, 'mailto:' ) === 0 || stripos( $saved_btn_url, 'tel:' ) === 0 ) {
        $btn_url = $saved_btn_url;
    }
}

if ( empty( $btn_url ) ) {
    $btn_url = $default_archive ? $default_archive : home_url( '/testimonials/' );
}

$btn_url = esc_url_raw( $btn_url ); // sanitized for output

// Query testimonials
$args = array(
    'post_type'      => 'hiregen_testimonial',
    'posts_per_page' => max( 1, $count ),
    'orderby'        => 'menu_order date',
    'order'          => 'DESC',
);

$testimonials = new WP_Query( $args );

/**
 * Render stars as inline spans (keeps markup simple).
 * Wrapped to avoid redeclare.
 */
if ( ! function_exists( 'hiregen_render_stars' ) ) {
    function hiregen_render_stars( $rating ) {
        $rating = intval( $rating );
        if ( $rating < 0 ) {
            $rating = 0;
        }
        if ( $rating > 5 ) {
            $rating = 5;
        }

        $out = '<div class="d-flex align-items-center mb-2" aria-hidden="true" style="gap:.35rem;">';
        for ( $i = 1; $i <= 5; $i++ ) {
            if ( $i <= $rating ) {
                $out .= '<span class="badge-custom" style="font-size: 1.0rem; display:inline-flex; align-items:center; justify-content:center; width:36px; height:36px; border-radius:7px;" aria-hidden="true"><i class="bi bi-star-fill" aria-hidden="true"></i></span>';
            } else {
                $out .= '<span style="font-size:1.05rem;color:#e6e6e6;" aria-hidden="true">★</span>';
            }
        }
        $out .= '</div>';
        return $out;
    }
}
?>

<section id="testimonials" class="custom-padding" style="background-color:<?php echo esc_attr( $bg ); ?>;">
  <div class="container">
    <div class="text-center mb-5">
      <?php if ( $subtitle ) : ?>
        <p class="badge-custom"><?php echo esc_html( $subtitle ); ?></p>
      <?php endif; ?>

      <?php if ( $title ) : ?>
        <h2 class="display-5 fw-bold section-title mb-3"><?php echo wp_kses_post( $title ); ?></h2>
      <?php endif; ?>

      <?php if ( $desc ) : ?>
        <p class="section-desc lead mx-auto" style="max-width:700px;"><?php echo wp_kses_post( $desc ); ?></p>
      <?php endif; ?>
    </div>

    <div class="row row-cols-1 row-cols-md-2 row-cols-lg-2 g-4">
      <?php if ( $testimonials->have_posts() ) : ?>
        <?php while ( $testimonials->have_posts() ) : $testimonials->the_post();
            $rating      = get_post_meta( get_the_ID(), 'hiregen_testimonial_rating', true );
            $designation = get_post_meta( get_the_ID(), 'hiregen_testimonial_designation', true );
            $thumb_id    = get_post_thumbnail_id( get_the_ID() );

            // Avatar markup
            $avatar_html = '';
            if ( $thumb_id ) {
                $alt = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true );
                $alt = $alt ? $alt : wp_strip_all_tags( get_the_title() );
                $avatar_html = wp_get_attachment_image(
                    $thumb_id,
                    'hiregen-product',
                    false,
                    array(
                        'class' => 'rounded-custom testimonial-avatar-img',
                        'alt'   => esc_attr( $alt ),
                        'style' => 'object-fit:cover;border-radius:8px;display:block;width:96px;height:96px;',
                    )
                );
            } else {
                // initials fallback (multibyte-safe)
                $initials = '';
                $name = get_the_title();
                if ( $name ) {
                    $parts = preg_split( '/\s+/u', trim( $name ) );
                    $first = isset( $parts[0] ) ? mb_substr( $parts[0], 0, 1, 'UTF-8' ) : '';
                    $second = isset( $parts[1] ) ? mb_substr( $parts[1], 0, 1, 'UTF-8' ) : '';
                    $initials = mb_strtoupper( $first . $second, 'UTF-8' );
                }
                $avatar_html = '<div class="testimonial-initials" role="img" aria-label="' . esc_attr( $name ) . '" style="width:96px;height:96px;border-radius:8px;background:#f1f5f9;color:#374151;display:flex;align-items:center;justify-content:center;font-weight:600;">' . esc_html( $initials ) . '</div>';
            }
        ?>
          <div class="col">
            <article id="post-<?php the_ID(); ?>" <?php post_class( 'card shadow-sm' ); ?> style="background:transparent;">
              <div class="card-body p-4" style="background:#f8fafc;border-radius:12px;position:relative;">
                <div class="d-flex align-items-start" style="gap:1rem;">
                  <div class="flex-grow-1" style="min-width:0;">
                    <?php
                    // stars
                    echo hiregen_render_stars( $rating );

                    // quote text — use content, trimmed and escaped
                    $raw_content = get_the_content();
                    $quote = wp_trim_words( wp_strip_all_tags( $raw_content ), 40 );
                    ?>
                    <blockquote class="mb-3" style="margin:0;font-style:normal;color:#374151;">
                      <p>“<?php echo esc_html( $quote ); ?>”</p>
                    </blockquote>

                    <div class="mt-4">
                      <h3 class="h5 mb-2"><?php the_title(); ?></h3>
                      <?php if ( $designation ) : ?>
                        <p class="mb-0"><?php echo esc_html( $designation ); ?></p>
                      <?php endif; ?>
                    </div>
                  </div>

                  <div class="ms-3 testimonial-avatar" style="flex:0 0 96px;">
                    <?php echo $avatar_html; // already escaped where needed ?>
                  </div>
                </div>
              </div>
            </article>
          </div>
        <?php endwhile; wp_reset_postdata(); ?>
      <?php else : ?>
        <div class="col">
          <p><?php esc_html_e( 'No testimonials found. Add testimonials in Admin → Testimonials.', 'hiregen-recruitment' ); ?></p>
        </div>
      <?php endif; ?>
    </div>

    <?php if ( $btn_text && $btn_url ) : ?>
      <div class="text-center mt-5">
        <a href="<?php echo esc_url( $btn_url ); ?>" class="btn btn-primary"<?php
            // add target/rel for external links
            $parsed = wp_parse_url( $btn_url );
            if ( ! empty( $parsed['host'] ) && $parsed['host'] !== wp_parse_url( home_url(), PHP_URL_HOST ) ) {
                echo ' target="_blank" rel="noopener noreferrer"';
            }
        ?>>
          <?php echo esc_html( wp_strip_all_tags( $btn_text ) ); ?> &rarr;
        </a>
      </div>
    <?php endif; ?>
  </div>
</section>

<style>
.testimonial-avatar-img { width:96px; height:96px; object-fit:cover; border-radius:8px; }
.testimonial-initials { font-size:1.25rem; }
</style>
