<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Register primary sidebar and footer widget areas.
 */
function hiregen_register_sidebars_and_footer() {
    // Default args used for footer widgets (small headings)
    $footer_args = array(
        'before_widget' => '<div id="%1$s" class="widget %2$s mb-4">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    );

    // Primary Sidebar (used by sidebar.php)
    register_sidebar(
        array(
            'name'          => __( 'Primary Sidebar', 'hiregen-recruitment' ),
            'id'            => 'sidebar-1',
            'description'   => __( 'Main sidebar that appears on blog and other pages.', 'hiregen-recruitment' ),
            'before_widget' => '<section id="%1$s" class="widget %2$s mb-4">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title h5">',
            'after_title'   => '</h2>',
        )
    );

    // Footer Column 1 (About / Contact)
    register_sidebar(
        array_merge( $footer_args, array(
            'name' => __( 'Footer Column 1 (About)', 'hiregen-recruitment' ),
            'id'   => 'footer-1',
        ) )
    );

    // Footer Column 2 (Latest Posts)
    register_sidebar(
        array_merge( $footer_args, array(
            'name' => __( 'Footer Column 2 (Latest Posts)', 'hiregen-recruitment' ),
            'id'   => 'footer-2',
        ) )
    );

    // Footer Column 3 (Latest Pages)
    register_sidebar(
        array_merge( $footer_args, array(
            'name' => __( 'Footer Column 3 (Latest Pages)', 'hiregen-recruitment' ),
            'id'   => 'footer-3',
        ) )
    );
}
add_action( 'widgets_init', 'hiregen_register_sidebars_and_footer' );
