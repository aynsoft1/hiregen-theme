<?php
/**
 * Search results template
 * Place: wp-content/themes/your-active-theme/search.php
 *
 * - Escapes search query output (get_search_query + esc_html)
 * - Does not use raw $_GET
 * - Uses semantic headings and roles
 * - Bootstrap-friendly layout with sidebar
 * - Accessible pagination and no-results fallback
 */

defined( 'ABSPATH' ) || exit;
get_header();
?>

<?php
// Safe, escaped user query for display (do NOT use raw $_GET)
$user_query = get_search_query( false ); // raw, unescaped
$safe_query = $user_query ? esc_html( $user_query ) : '';
?>

<div class="sub-header py-4">
  <div class="container">
    <h1 class="entry-title fw-bold">
      <?php
      /* translators: %s: search query */
      if ( $safe_query ) {
          printf( esc_html__( 'Search results for: %s', 'hiregen-recruitment' ), '<span class="text-break">' . $safe_query . '</span>' );
      } else {
          esc_html_e( 'Search results', 'hiregen-recruitment' );
      }
      ?>
    </h1>

    <div class="breadcrumb mb-0" aria-label="<?php esc_attr_e( 'Breadcrumb', 'hiregen-recruitment' ); ?>">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php esc_html_e( 'Home', 'hiregen-recruitment' ); ?></a>
      <span class="breadcrumb-sep" aria-hidden="true"> → </span>
      <span><?php echo $safe_query ? $safe_query : esc_html__( 'Search', 'hiregen-recruitment' ); ?></span>
    </div>
  </div>
</div>

<main id="content" class="site-main py-4" role="main" aria-labelledby="search-results-title">
  <div class="container">
    <div class="row gx-5">

      <!-- Primary -->
      <div class="col-12 col-md-8">

        <?php if ( have_posts() ) : ?>

          <div class="list-search">

            <?php
            while ( have_posts() ) :
                the_post();
                ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class( 'mb-4' ); ?>>

                  <div class="card">
                    <div class="row g-0 align-items-center">
                      <?php if ( has_post_thumbnail() ) : ?>
                        <div class="col-auto d-none d-md-block">
                          <a href="<?php the_permalink(); ?>" class="d-block">
                            <?php the_post_thumbnail( 'medium', array(
                              'class' => 'img-fluid rounded-start',
                              'loading' => 'lazy',
                              'alt' => the_title_attribute( array( 'echo' => false ) ),
                            ) ); ?>
                          </a>
                        </div>
                      <?php endif; ?>

                      <div class="col">
                        <div class="card-body">
                          <h2 class="h5 card-title mb-1">
                            <a href="<?php the_permalink(); ?>" class="text-decoration-none"><?php echo esc_html( get_the_title() ); ?></a>
                          </h2>

                          <div class="meta text-muted small mb-2" aria-hidden="true">
                            <span class="me-2"><?php echo esc_html( get_the_date() ); ?></span>
                            <?php if ( 'post' === get_post_type() ) : ?>
                              <span class="me-2"><?php echo esc_html( get_the_author_meta( 'display_name', get_post_field( 'post_author', get_the_ID() ) ) ); ?></span>
                            <?php endif; ?>
                          </div>

                          <div class="excerpt mb-2">
                            <?php
                            // Use the_excerpt(); WP filters will highlight search terms if desired via plugins
                            the_excerpt();
                            ?>
                          </div>

                          <a href="<?php the_permalink(); ?>" class="btn btn-sm btn-outline-primary" aria-label="<?php echo esc_attr( sprintf( __( 'Read more about %s', 'hiregen-recruitment' ), wp_strip_all_tags( get_the_title() ) ) ); ?>">
                            <?php esc_html_e( 'Read more', 'hiregen-recruitment' ); ?> &rarr;
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>

                </article>
            <?php
            endwhile;
            ?>

          </div>

          <nav class="pagination-wrapper mt-4" aria-label="<?php esc_attr_e( 'Search results navigation', 'hiregen-recruitment' ); ?>">
            <?php
            the_posts_pagination( array(
                'mid_size'  => 2,
                'prev_text' => __( '&larr; Previous', 'hiregen-recruitment' ),
                'next_text' => __( 'Next &rarr;', 'hiregen-recruitment' ),
                'screen_reader_text' => __( 'Search results navigation', 'hiregen-recruitment' ),
            ) );
            ?>
          </nav>

        <?php else : ?>

          <div class="card card-body">
            <h2><?php esc_html_e( 'No results found', 'hiregen-recruitment' ); ?></h2>

            <?php if ( $safe_query ) : ?>
              <p><?php printf( esc_html__( 'We couldn’t find any results for "%s". Try different keywords or broaden your search.', 'hiregen-recruitment' ), $safe_query ); ?></p>
            <?php else : ?>
              <p><?php esc_html_e( 'Please enter a search term and try again.', 'hiregen-recruitment' ); ?></p>
            <?php endif; ?>

            <div class="search-form-wrapper mt-3">
              <?php get_search_form(); ?>
            </div>

            <div class="mt-4">
              <h3 class="h6"><?php esc_html_e( 'Browse recent posts', 'hiregen-recruitment' ); ?></h3>
              <ul class="list-unstyled mb-0">
                <?php
                $recent = new WP_Query( array(
                    'posts_per_page' => 5,
                    'post_status'    => 'publish',
                    'ignore_sticky_posts' => true,
                ) );
                if ( $recent->have_posts() ) :
                    while ( $recent->have_posts() ) : $recent->the_post(); ?>
                        <li class="mb-2"><a href="<?php the_permalink(); ?>"><?php echo esc_html( get_the_title() ); ?></a></li>
                    <?php endwhile;
                    wp_reset_postdata();
                endif;
                ?>
              </ul>
            </div>

          </div>

        <?php endif; ?>

      </div><!-- /.col -->

      <!-- Sidebar -->
      <aside class="col-12 col-md-4" role="complementary" aria-label="<?php esc_attr_e( 'Sidebar', 'hiregen-recruitment' ); ?>">
        <?php
        if ( is_active_sidebar( 'sidebar-1' ) ) {
            dynamic_sidebar( 'sidebar-1' );
        } else {
            // fallback widgets
            ?>
            <div class="card mb-4">
              <div class="card-body p-4">
                <?php get_search_form(); ?>
              </div>
            </div>

            <div class="card mb-4">
              <div class="card-body p-4">
                <h3 class="h6 mb-3"><?php esc_html_e( 'Categories', 'hiregen-recruitment' ); ?></h3>
                <ul class="list-unstyled mb-0 ps-0">
                  <?php wp_list_categories( array( 'title_li' => '', 'show_count' => true ) ); ?>
                </ul>
              </div>
            </div>
            <?php
        }
        ?>
      </aside><!-- /.col -->

    </div><!-- /.row -->
  </div><!-- /.container -->
</main>

<?php
get_footer();
