<?php
/**
 * Job listing preview when submitting job listings.
 *
 * This template can be overridden by copying it to yourtheme/job_manager/job-preview.php.
 *
 * @see         https://wpjobmanager.com/document/template-overrides/
 * @author      Automattic
 * @package     wp-job-manager
 * @category    Template
 * @version     1.41.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Defensive: ensure $form object exists and has expected methods.
 * Most of this template depends on the $form provided by the submit handler.
 */
if ( ! isset( $form ) || ! is_object( $form ) ) {
	// Fail gracefully.
	return;
}

$action_url = method_exists( $form, 'get_action' ) ? $form->get_action() : '';
$action_url = esc_url( $action_url );

$job_id = method_exists( $form, 'get_job_id' ) ? absint( $form->get_job_id() ) : 0;
$step   = method_exists( $form, 'get_step' ) ? sanitize_text_field( $form->get_step() ) : '';
$form_name = method_exists( $form, 'get_form_name' ) ? sanitize_text_field( $form->get_form_name() ) : '';

/**
 * Authorisation:
 * - If previewing an existing job, require capability to edit that post.
 * - For a new listing preview, require the standard job submission capability.
 */
$can_submit = false;
if ( $job_id ) {
	$can_submit = current_user_can( 'edit_post', $job_id );
} else {
	// For new job preview, rely on plugin helper (if available)
	if ( function_exists( 'job_manager_user_can_submit_job_listing' ) ) {
		$can_submit = job_manager_user_can_submit_job_listing();
	} else {
		$can_submit = is_user_logged_in();
	}
}
?>
<form method="post" id="job_preview" action="<?php echo $action_url; ?>">
	<?php
	/**
	 * Fires at the top of the preview job form.
	 *
	 * @since 1.32.2
	 */
	do_action( 'preview_job_form_start' );
	?>

	<div class="job_listing_preview_title">
		<?php if ( $can_submit ) : ?>
			<input
				type="submit"
				name="continue"
				id="job_preview_submit_button"
				class="button job-manager-button-submit-listing mb-3"
				value="<?php echo esc_attr( apply_filters( 'submit_job_step_preview_submit_text', __( 'Submit Listing', 'hiregen-recruitment' ) ) ); ?>" />
		<?php else : ?>
			<!-- Non-authorized users should not see a submit button -->
			<span class="job-preview-notice"><?php echo esc_html__( 'You are not authorized to submit this listing.', 'hiregen-recruitment' ); ?></span>
		<?php endif; ?>

		<?php if ( ! defined( 'WP_Job_Manager_Helper_Renewals' ) || ! class_exists( 'WP_Job_Manager_Helper_Renewals' ) || ! WP_Job_Manager_Helper_Renewals::is_renew_action() ) : ?>
			<?php
			// Show edit button only if user is allowed to edit the job (existing job)
			if ( $job_id && current_user_can( 'edit_post', $job_id ) ) :
				?>
				<input
					type="submit"
					name="edit_job"
					class="btn btn-outline-secondary w-100"
					value="<?php echo esc_attr_x( 'Edit listing', 'button', 'hiregen-recruitment' ); ?>" />
			<?php
			endif;
			?>
		<?php endif; ?>

		<h2><?php echo esc_html_x( 'Preview', 'heading', 'hiregen-recruitment' ); ?></h2>
	</div>

	<div class="job_listing_preview single_job_listing">
		<?php
		// Job title: get safely and escape
		$job_title = '';
		if ( $job_id ) {
			$job_title = get_the_title( $job_id );
		} else {
			// fallback: if the form exposes a title method or prop, use it defensively
			if ( method_exists( $form, 'get_job_title' ) ) {
				$job_title = sanitize_text_field( $form->get_job_title() );
			}
		}
		echo '<h1>' . esc_html( $job_title ) . '</h1>';
		?>

		<?php
		/*
		 * Render the single-job content template part into a buffer so we can sanitize it.
		 * Many theme/plugin template parts will echo HTML (company logo, description etc.).
		 * We allow safe post HTML (wp_kses_post) but strip dangerous tags.
		 */
		ob_start();
		get_job_manager_template_part( 'content-single', \WP_Job_Manager_Post_Types::PT_LISTING );
		$single_content = ob_get_clean();

		// Sanitize allowed post-like HTML before output.
		echo wp_kses_post( $single_content );
		?>

		<input type="hidden" name="job_id" value="<?php echo esc_attr( $job_id ); ?>" />
		<input type="hidden" name="step" value="<?php echo esc_attr( $step ); ?>" />
		<input type="hidden" name="job_manager_form" value="<?php echo esc_attr( $form_name ); ?>" />
	</div>

	<?php
	/**
	 * Fires at the bottom of the preview job form.
	 *
	 * @since 1.32.2
	 */
	do_action( 'preview_job_form_end' );
	?>
</form>

<?php
/**
 * Notes & recommendations (do not remove):
 * - Ensure any scripts/styles needed by the preview content are enqueued properly via wp_enqueue_script/style
 *   (e.g. in an action callback hooked to `wp_enqueue_scripts` or the plugin's enqueue hooks), rather than printing
 *   <script> or <link> tags directly inside template parts.
 * - If form submission expects a nonce, ensure the surrounding form handler prints/validates it. Don't add uncoordinated
 *   nonces here unless you also modify the processing code.
 * - For remote images (company logos that point to external hosts), consider validating hostnames or proxying/fetching
 *   images to your own domain to avoid third-party content risks.
 */
