<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Team section - reads from Customizer + hiregen_team CPT
 * Shows responsive 3-card grid, photo, name (title), designation (meta) and excerpt/bio.
 *
 * Improvements:
 * - sanitize theme mods
 * - robust URL handling for button
 * - escape outputs correctly
 * - safer image alt fallback
 * - fixed avatar classname in inline CSS
 *
 * @package Hiregen
 */

// Theme mod values (sanitize)
$bg_raw     = get_theme_mod( 'hiregen_team_bg', '#ffffff' );
$bg         = sanitize_hex_color( $bg_raw ) ?: esc_attr( $bg_raw ); // safe-escaped later in output
$subtitle   = sanitize_text_field( get_theme_mod( 'hiregen_team_subtitle', '' ) );
$title_raw  = get_theme_mod( 'hiregen_team_title', __( 'Our Team', 'hiregen-recruitment' ) );
$title      = $title_raw ? wp_kses_post( $title_raw ) : __( 'Our Team', 'hiregen-recruitment' );
$desc       = wp_kses_post( get_theme_mod( 'hiregen_team_description', '' ) );
$count      = absint( get_theme_mod( 'hiregen_team_count', 3 ) );
$btn_text_raw = get_theme_mod( 'hiregen_team_btn_text', __( 'Read more', 'hiregen-recruitment' ) );
$btn_text     = $btn_text_raw ? wp_kses_post( $btn_text_raw ) : __( 'Read more', 'hiregen-recruitment' );
$saved_btn_url = trim( (string) get_theme_mod( 'hiregen_team_btn_url', '' ) );

// Default archive link fallback (if no custom URL)
$default_archive = get_post_type_archive_link( 'hiregen_team' );

// Helper functions (avoid redeclaring)
if ( ! function_exists( 'hiregen_is_full_url' ) ) {
    function hiregen_is_full_url( $u ) {
        return ( strpos( $u, 'http://' ) === 0 || strpos( $u, 'https://' ) === 0 );
    }
}

if ( ! function_exists( 'hiregen_is_relative_slug' ) ) {
    function hiregen_is_relative_slug( $u ) {
        if ( empty( $u ) ) {
            return false;
        }
        $u = trim( $u );
        if ( strpos( $u, '#' ) === 0 || stripos( $u, 'mailto:' ) === 0 || stripos( $u, 'tel:' ) === 0 ) {
            return false;
        }
        if ( strpos( $u, '://' ) === false && stripos( $u, 'http' ) === false ) {
            return true;
        }
        return false;
    }
}

// Resolve button URL safely
$btn_url = '';

if ( $saved_btn_url && hiregen_is_full_url( $saved_btn_url ) ) {
    $btn_url = esc_url_raw( $saved_btn_url );
}

if ( empty( $btn_url ) && hiregen_is_relative_slug( $saved_btn_url ) ) {
    $slug = trim( $saved_btn_url, '/' );
    if ( $slug !== '' ) {
        $page = get_page_by_path( $slug, OBJECT, 'page' );
        if ( $page ) {
            $btn_url = get_permalink( $page->ID );
        }
    }
}

if ( empty( $btn_url ) && $saved_btn_url ) {
    if ( strpos( $saved_btn_url, '#' ) === 0 || stripos( $saved_btn_url, 'mailto:' ) === 0 || stripos( $saved_btn_url, 'tel:' ) === 0 ) {
        $btn_url = $saved_btn_url;
    }
}

// final fallbacks
if ( empty( $btn_url ) ) {
    $btn_url = $default_archive ? $default_archive : home_url( '/team/' );
}

$btn_url = esc_url_raw( $btn_url ); // sanitized for output

// Query args
$args = array(
    'post_type'      => 'hiregen_team',
    'posts_per_page' => max( 1, $count ),
    'orderby'        => 'menu_order date',
    'order'          => 'DESC',
);

$team = new WP_Query( $args );
?>

<section id="team" class="custom-padding" style="background-color:<?php echo esc_attr( $bg ); ?>;">
  <div class="container">
    <div class="text-center mb-5">
      <?php if ( $subtitle ) : ?>
        <p class="badge-custom"><?php echo esc_html( $subtitle ); ?></p>
      <?php endif; ?>

      <?php if ( $title ) : ?>
        <h2 class="display-5 fw-bold section-title mb-3"><?php echo wp_kses_post( $title ); ?></h2>
      <?php endif; ?>

      <?php if ( $desc ) : ?>
        <p class="section-desc lead mx-auto" style="max-width:700px;"><?php echo wp_kses_post( $desc ); ?></p>
      <?php endif; ?>
    </div>

    <div class="row row-cols-1 row-cols-md-3 g-4">
      <?php if ( $team->have_posts() ) :
        while ( $team->have_posts() ) : $team->the_post();
          $designation = get_post_meta( get_the_ID(), 'hiregen_team_designation', true );
          $thumb_id = get_post_thumbnail_id( get_the_ID() );
      ?>
        <div class="col">
          <article id="post-<?php the_ID(); ?>" <?php post_class( 'card p-3 shadow-sm text-center' ); ?>>
            <?php if ( $thumb_id ) :
              $alt = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true );
              $alt = $alt ? $alt : wp_strip_all_tags( get_the_title() );
            ?>
              <div class="pt-4">
                <?php
                // Use wp_get_attachment_image for responsive srcset and attributes
                echo wp_get_attachment_image(
                    $thumb_id,
                    'hiregen-product',
                    false,
                    array(
                        'class' => 'img-fluid roundedcustom team-avatar mb-3',
                        'alt'   => esc_attr( $alt ),
                    )
                );
                ?>
              </div>
            <?php endif; ?>

            <div class="card-body d-flex flex-column">
              <h3 class="h5 mb-1"><?php the_title(); ?></h3>

              <?php if ( $designation ) : ?>
                <small class="text-muted mb-3"><?php echo esc_html( $designation ); ?></small>
              <?php endif; ?>

              <p class="team-bio flex-grow-1 mb-0">
                <?php
                $excerpt_source = get_the_excerpt();
                if ( empty( $excerpt_source ) ) {
                    $excerpt_source = wp_strip_all_tags( get_the_content() );
                }
                echo wp_kses_post( wp_trim_words( $excerpt_source, 30 ) );
                ?>
              </p>
            </div>
          </article>
        </div>
      <?php endwhile; wp_reset_postdata();
      else : ?>
        <div class="col">
          <p><?php esc_html_e( 'No team members found. Add team members in Admin → Our Team.', 'hiregen-recruitment' ); ?></p>
        </div>
      <?php endif; ?>
    </div>

    <?php if ( $btn_text && $btn_url ) : ?>
      <div class="text-center mt-5">
        <a href="<?php echo esc_url( $btn_url ); ?>" class="btn btn-primary"<?php
            // add target/rel for external links
            $parsed = wp_parse_url( $btn_url );
            if ( ! empty( $parsed['host'] ) && $parsed['host'] !== wp_parse_url( home_url(), PHP_URL_HOST ) ) {
                echo ' target="_blank" rel="noopener noreferrer"';
            }
        ?>>
          <?php echo esc_html( wp_strip_all_tags( $btn_text ) ); ?> &rarr;
        </a>
      </div>
    <?php endif; ?>
  </div>
</section>

<style>
.team-avatar { width: 140px; height: 140px; object-fit: cover; box-shadow: 0 8px 18px rgba(0,0,0,0.06); border-radius: 50%; }
</style>
