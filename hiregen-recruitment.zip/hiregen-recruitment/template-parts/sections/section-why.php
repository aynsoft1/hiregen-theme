<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Why section - visual + list items
 *
 * - sanitize theme_mod values
 * - robust image handling (attachment ID or URL)
 * - sanitize/escape outputs
 * - safe button URL resolution
 *
 * @package Hiregen
 */

// Raw theme mod values
$img_raw    = get_theme_mod( 'hiregen_why_image' );
$subtitle   = sanitize_text_field( get_theme_mod( 'hiregen_why_subtitle', '' ) );
$title_raw  = get_theme_mod( 'hiregen_why_title', '' );
$title      = $title_raw ? wp_kses_post( $title_raw ) : '';
$desc_raw   = get_theme_mod( 'hiregen_why_description', '' );
$desc       = $desc_raw ? wp_kses_post( $desc_raw ) : '';

// list items (sanitize as plain text)
$li = array();
for ( $i = 1; $i <= 4; $i++ ) {
    $li_val = get_theme_mod( 'hiregen_why_li_' . $i );
    if ( $li_val !== null && $li_val !== '' ) {
        $li[] = sanitize_text_field( $li_val );
    } else {
        $li[] = '';
    }
}

// background color (allow hex colors only)
$why_bg_raw = get_theme_mod( 'hiregen_why_bg', '' );
$why_bg     = sanitize_hex_color( $why_bg_raw );
$why_style  = $why_bg ? 'background-color: ' . esc_attr( $why_bg ) . ';' : '';

// Button text and saved url
$btn_text_raw = get_theme_mod( 'hiregen_why_btn_text', __( 'About Us', 'hiregen-recruitment' ) );
$btn_text     = $btn_text_raw ? wp_kses_post( $btn_text_raw ) : __( 'About Us', 'hiregen-recruitment' );
$saved_url_raw = trim( (string) get_theme_mod( 'hiregen_why_btn_url', '' ) );
$saved_url_raw = $saved_url_raw === '' ? '' : $saved_url_raw;

/**
 * Helpers to detect URL types
 */
if ( ! function_exists( 'hiregen_is_full_url' ) ) {
    function hiregen_is_full_url( $u ) {
        return ( strpos( $u, 'http://' ) === 0 || strpos( $u, 'https://' ) === 0 );
    }
}

if ( ! function_exists( 'hiregen_is_relative_slug' ) ) {
    function hiregen_is_relative_slug( $u ) {
        if ( empty( $u ) ) {
            return false;
        }
        $u = trim( $u );
        if ( strpos( $u, '#' ) === 0 || stripos( $u, 'mailto:' ) === 0 || stripos( $u, 'tel:' ) === 0 ) {
            return false;
        }
        if ( strpos( $u, '://' ) === false && stripos( $u, 'http' ) === false ) {
            return true;
        }
        return false;
    }
}

// Resolve the About button URL safely
$why_btn_url = '';

if ( $saved_url_raw && hiregen_is_full_url( $saved_url_raw ) ) {
    $why_btn_url = esc_url_raw( $saved_url_raw );
}

if ( empty( $why_btn_url ) && hiregen_is_relative_slug( $saved_url_raw ) ) {
    $slug = trim( $saved_url_raw, '/' );
    if ( $slug !== '' ) {
        $page = get_page_by_path( $slug, OBJECT, 'page' );
        if ( $page ) {
            $why_btn_url = get_permalink( $page->ID );
        } else {
            // try without specifying post type
            $maybe = get_page_by_path( $slug );
            if ( $maybe ) {
                $why_btn_url = get_permalink( $maybe->ID );
            }
        }
    }
}

if ( empty( $why_btn_url ) && $saved_url_raw ) {
    if ( strpos( $saved_url_raw, '#' ) === 0 || stripos( $saved_url_raw, 'mailto:' ) === 0 || stripos( $saved_url_raw, 'tel:' ) === 0 ) {
        $why_btn_url = $saved_url_raw;
    }
}

// try common about slugs
if ( empty( $why_btn_url ) ) {
    $candidates = array( 'about-us', 'about', 'who-we-are' );
    foreach ( $candidates as $c ) {
        $page = get_page_by_path( $c, OBJECT, 'page' );
        if ( $page ) {
            $why_btn_url = get_permalink( $page->ID );
            break;
        }
    }
}

// final fallback
if ( empty( $why_btn_url ) ) {
    $why_btn_url = home_url( '/about-us/' );
}
$why_btn_url = esc_url_raw( $why_btn_url );

// Image handling: theme mod might store attachment ID or URL
$img_html = '';
if ( ! empty( $img_raw ) ) {
    // numeric -> assume attachment ID
    if ( is_numeric( $img_raw ) ) {
        $attachment_id = absint( $img_raw );
    } else {
        // try to resolve URL to attachment ID
        $attachment_id = attachment_url_to_postid( $img_raw );
    }

    if ( ! empty( $attachment_id ) ) {
        $alt = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
        if ( ! $alt ) {
            $alt = $title ? wp_strip_all_tags( $title ) : get_bloginfo( 'name' );
        }
        $img_html = wp_get_attachment_image( $attachment_id, 'large', false, array(
            'class' => 'img-fluid rounded-custom',
            'alt'   => esc_attr( $alt ),
        ) );
    } else {
        // treat as URL fallback
        $img_url = esc_url_raw( $img_raw );
        if ( $img_url ) {
            $alt = $title ? wp_strip_all_tags( $title ) : get_bloginfo( 'name' );
            $img_html = '<img src="' . esc_url( $img_url ) . '" alt="' . esc_attr( $alt ) . '" class="img-fluid rounded-custom">';
        }
    }
}
?>

<section id="why" class="custom-padding" <?php if ( $why_style ) : ?>style="<?php echo esc_attr( $why_style ); ?>"<?php endif; ?>>

  <div class="container">
    <div class="row align-items-center gx-5">
      <div class="col-md-5">
        <?php
        // Print image (already escaped)
        if ( $img_html ) {
            echo $img_html;
        }
        ?>
      </div>

      <div class="col-md-7">
        <?php if ( $subtitle ) : ?>
          <p class="badge-custom"><?php echo esc_html( $subtitle ); ?></p>
        <?php endif; ?>

        <?php if ( $title ) : ?>
          <h2 class="display-5 fw-bold"><?php echo wp_kses_post( $title ); ?></h2>
        <?php endif; ?>

        <?php if ( $desc ) : ?>
          <p><?php echo wp_kses_post( $desc ); ?></p>
        <?php endif; ?>

        <div class="row mt-3">
          <?php for ( $i = 0; $i < 4; $i++ ) : 
            if ( ! empty( $li[ $i ] ) ) : ?>
              <div class="col-md-6">
                <p class="mb-2">✓ <?php echo esc_html( $li[ $i ] ); ?></p>
              </div>
            <?php endif;
          endfor; ?>
        </div>

        <p class="mt-3">
          <a href="<?php echo esc_url( $why_btn_url ); ?>" class="btn btn-primary"<?php
            $parsed = wp_parse_url( $why_btn_url );
            if ( ! empty( $parsed['host'] ) && $parsed['host'] !== wp_parse_url( home_url(), PHP_URL_HOST ) ) {
                echo ' target="_blank" rel="noopener noreferrer"';
            }
          ?>>
            <?php echo esc_html( wp_strip_all_tags( $btn_text ) ); ?> &rarr;
          </a>
        </p>

      </div>
    </div>
  </div>
</section>
