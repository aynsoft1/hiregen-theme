<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Contact section - sanitized, accessible and backward compatible
 */

// helper to read theme mod (prefer hiregen_get_theme_mod if available)
if ( ! function_exists( 'hiregen_mod' ) ) {
    function hiregen_mod( $key, $default = '' ) {
        if ( function_exists( 'hiregen_get_theme_mod' ) ) {
            return hiregen_get_theme_mod( $key, $default );
        }
        return get_theme_mod( $key, $default );
    }
}

/* --- Collect and sanitize settings --- */
$bg_raw       = hiregen_mod( 'hiregen_contact_bg', '#093a83' );
$bg           = sanitize_hex_color( $bg_raw ) ?: '#093a83';

$subtitle_raw = hiregen_mod( 'hiregen_contact_subtitle', __( 'Contact Us', 'hiregen-recruitment' ) );
$subtitle     = sanitize_text_field( $subtitle_raw );

$title_raw    = hiregen_mod( 'hiregen_contact_title', __( 'Get in Touch Lets Start the Conversation', 'hiregen-recruitment' ) );
$title        = wp_kses( $title_raw, array( 'strong' => array(), 'em' => array(), 'br' => array() ) );

$desc_raw     = hiregen_mod( 'hiregen_contact_description', __( 'We are here to help you find the right staffing solutions for your needs. Whether you are a company looking to hire top talent or a candidate seeking your next career opportunity', 'hiregen-recruitment' ) );
$desc         = $desc_raw ? wp_kses_post( $desc_raw ) : '';

$form_raw     = hiregen_mod( 'hiregen_contact_form_shortcode', '' ); // expected to be a shortcode string
$form         = $form_raw ? trim( $form_raw ) : '';

/* Contact boxes (new keys) */
$box1_title_raw = hiregen_mod( 'hiregen_contact_box1_title', '' );
$box1_info_raw  = hiregen_mod( 'hiregen_contact_box1_info', '' );
$box1_icon_raw  = hiregen_mod( 'hiregen_contact_box1_icon', 'bi-telephone' );

$box2_title_raw = hiregen_mod( 'hiregen_contact_box2_title', '' );
$box2_info_raw  = hiregen_mod( 'hiregen_contact_box2_info', '' );
$box2_icon_raw  = hiregen_mod( 'hiregen_contact_box2_icon', 'bi-envelope' );

/* Backwards compatibility: fall back to footer settings if new ones empty */
if ( empty( $box1_info_raw ) ) {
    $box1_info_raw = get_theme_mod( 'hiregen_footer_phone', '' );
}
if ( empty( $box2_info_raw ) ) {
    $box2_info_raw = get_theme_mod( 'hiregen_footer_email', '' );
}

/* sanitize contact box fields */
$box1_title = $box1_title_raw ? sanitize_text_field( $box1_title_raw ) : '';
$box1_info  = $box1_info_raw ? sanitize_text_field( $box1_info_raw ) : '';
$box1_icon  = $box1_icon_raw ? sanitize_text_field( $box1_icon_raw ) : 'bi-telephone';

$box2_title = $box2_title_raw ? sanitize_text_field( $box2_title_raw ) : '';
$box2_info  = $box2_info_raw ? sanitize_text_field( $box2_info_raw ) : '';
$box2_icon  = $box2_icon_raw ? sanitize_text_field( $box2_icon_raw ) : 'bi-envelope';

/* final escaped bg style */
$bg_attr = esc_attr( $bg );
?>

<section id="contact" class="custom-padding" style="background-color:<?php echo $bg_attr; ?>;">
  <div class="container">
    <div class="row gx-5 align-items-center">

      <!-- LEFT COLUMN -->
      <div class="col-lg-6 text-white d-flex flex-column justify-content-center">
        <?php if ( $subtitle ) : ?>
          <p class="subtitle text-white mb-4"><?php echo esc_html( $subtitle ); ?></p>
        <?php endif; ?>

        <?php if ( $title ) : ?>
          <h2 class="display-5 fw-bold section-title text-white mb-5"><?php echo $title; /* sanitized with wp_kses */ ?></h2>
        <?php endif; ?>

        <?php if ( $desc ) : ?>
          <p class="mb-5 text-white" style="max-width:600px;line-height:1.8;"><?php echo $desc; /* sanitized with wp_kses_post */ ?></p>
        <?php endif; ?>

        <!-- Phone Card -->
        <div class="d-flex align-items-center p-4 mb-4 rounded" style="color:#3f2b62;background-color: rgba(255,255,255,0.05);">
          <div class="me-4 badge-custo" style="font-size:2.1rem;width:64px;height:64px;border-radius:100%;text-align:center;color:#fff;background-color: rgba(255,255,255,0.05);line-height: 64px;">
            <i class="<?php echo esc_attr( $box1_icon ); ?>" aria-hidden="true"></i>
          </div>
          <div>
            <p class="lead mb-2 fw-medium text-white"><?php echo esc_html( $box1_title ? $box1_title : __( 'Gives us a Call', 'hiregen-recruitment' ) ); ?></p>
            <h3 class="h5 widget-title fw-bold text-white">
              <?php
              if ( $box1_info ) :
                  // create tel href: allow + and digits
                  $tel_href = preg_replace( '/[^0-9+]/', '', $box1_info );
                  if ( ! empty( $tel_href ) ) :
                      printf(
                          '<a href="tel:%1$s">%2$s</a>',
                          esc_attr( $tel_href ),
                          esc_html( $box1_info )
                      );
                  else :
                      echo esc_html( $box1_info );
                  endif;
              else :
                  echo esc_html__( '123-456-7890', 'hiregen-recruitment' );
              endif;
              ?>
            </h3>
          </div>
        </div>

        <!-- Email Card -->
        <div class="d-flex align-items-center p-4 rounded" style="color:#3f2b62;background-color: rgba(255,255,255,0.05);">
          <div class="me-4 badge-custo" style="font-size:2.1rem;width:64px;height:64px;border-radius:100%;text-align:center;color:#fff;background-color: rgba(255,255,255,0.05);line-height: 64px;">
            <i class="<?php echo esc_attr( $box2_icon ); ?>" aria-hidden="true"></i>
          </div>
          <div>
            <p class="lead mb-2 fw-medium text-white"><?php echo esc_html( $box2_title ? $box2_title : __( 'Send me Mail', 'hiregen-recruitment' ) ); ?></p>
            <h3 class="h5 widget-title fw-bold text-white">
              <?php
              if ( $box2_info ) :
                  if ( is_email( $box2_info ) ) {
                      printf(
                          '<a href="mailto:%1$s">%2$s</a>',
                          esc_attr( $box2_info ),
                          esc_html( antispambot( $box2_info ) )
                      );
                  } else {
                      echo esc_html( $box2_info );
                  }
              else :
                  echo esc_html__( 'support@wpjobnova.com', 'hiregen-recruitment' );
              endif;
              ?>
            </h3>
          </div>
        </div>
      </div>

      <!-- RIGHT COLUMN -->
      <div class="col-lg-6">
        <div class="rounded px-5 py-4" style="background-color: rgba(255,255,255,0.05);">
          <h3 class="h5 fw-bold mb-4 text-white"><?php esc_html_e( 'Send Your Application', 'hiregen-recruitment' ); ?></h3>
          <p class="mb-4 text-white"><?php esc_html_e( 'Feel free to contact us anytime with questions, support requests, or hiring needs you may have.', 'hiregen-recruitment' ); ?></p>

          <?php
          // Show form if shortcode present; otherwise show helpful notices
          if ( $form && function_exists( 'do_shortcode' ) ) {
              echo '<div class="hiregen-contact-form">';
              // allow shortcode execution but sanitize the provided shortcode string minimally (strip tags)
              // do_shortcode outputs HTML produced by plugin; we trust shortcodes but still avoid raw unfiltered echo
              $safe_form = wp_strip_all_tags( $form, true );
              // run shortcode and echo result (shortcode output should be trusted as plugins sanitize output)
              echo do_shortcode( $safe_form );
              echo '</div>';
          } else {
              if ( ! class_exists( 'WPCF7' ) ) {
                  echo '<div class="alert alert-warning text-center" role="status">';
                  esc_html_e( 'Please install and activate Contact Form 7 plugin, then set a form shortcode in the Customizer.', 'hiregen-recruitment' );
                  echo '</div>';
              } else {
                  echo '<div class="alert alert-info text-center" role="status">';
                  esc_html_e( 'No contact form selected. Add a shortcode in the Customizer.', 'hiregen-recruitment' );
                  echo '</div>';
              }
          }
          ?>
        </div>
      </div>

    </div>
  </div>
</section>
