<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Products section
 */

// bail if disabled in Customizer
if ( ! get_theme_mod( 'hiregen_products_enable', true ) ) {
    return;
}

/* --- sanitize theme mod inputs --- */
$bg_color  = sanitize_hex_color( get_theme_mod( 'hiregen_products_bg_color', '#ffffff' ) );
$subtitle  = sanitize_text_field( get_theme_mod( 'hiregen_products_subtitle', '' ) );
$title     = sanitize_text_field( get_theme_mod( 'hiregen_products_title', __( 'Our Products', 'hiregen-recruitment' ) ) );
$desc      = get_theme_mod( 'hiregen_products_desc', '' ); // may contain limited HTML — sanitize on output
$btn_text  = sanitize_text_field( get_theme_mod( 'hiregen_products_btn_text', __( 'View All Products →', 'hiregen-recruitment' ) ) );
$btn_url   = esc_url_raw( get_theme_mod( 'hiregen_products_btn_url', home_url( '/products/' ) ) );
$number    = absint( get_theme_mod( 'hiregen_products_number', 3 ) );

$query = new WP_Query( array(
    'post_type'      => 'hiregen_product',
    'posts_per_page' => $number,
) );

/* Allowed tags for description output (safe subset) */
$allowed_tags = array(
    'ul'     => array(),
    'ol'     => array(),
    'li'     => array(),
    'p'      => array(),
    'br'     => array(),
    'strong' => array(),
    'em'     => array(),
    'a'      => array(
        'href'   => array(),
        'title'  => array(),
        'target' => array(),
        'rel'    => array(),
    ),
);

// currency symbols map
$symbols = array(
    'INR' => '₹',
    'USD' => '$',
    'EUR' => '€',
    'GBP' => '£',
    'JPY' => '¥',
);
?>

<section id="products" class="our-products custom-padding" style="background-color:<?php echo esc_attr( $bg_color ? $bg_color : '#ffffff' ); ?>">
  <div class="container">
    <div class="section-header text-center mb-5">
      <?php if ( $subtitle ) : ?>
        <p class="badge-custom"><?php echo esc_html( $subtitle ); ?></p>
      <?php endif; ?>

      <h2 class="display-5 fw-bold section-title mb-3"><?php echo esc_html( $title ); ?></h2>

      <?php if ( $desc ) : ?>
        <p class="section-desc lead mx-auto" style="max-width:700px;">
          <?php echo wp_kses( wp_kses_post( $desc ), $allowed_tags ); ?>
        </p>
      <?php endif; ?>
    </div>

    <div class="row row-cols-1 row-cols-md-3 g-4">
      <?php if ( $query->have_posts() ) : ?>
        <?php while ( $query->have_posts() ) : $query->the_post(); ?>
          <?php
          $post_id   = get_the_ID();
          $permalink = get_permalink( $post_id );

          $currency  = get_post_meta( $post_id, 'product_currency', true );
          $regular   = get_post_meta( $post_id, 'product_regular_price', true );
          $sale      = get_post_meta( $post_id, 'product_sale_price', true );
          $buy_url   = get_post_meta( $post_id, 'product_button_url', true );
          $shortdesc = get_post_meta( $post_id, 'product_desc', true );

          $product_title = get_the_title( $post_id );

          $symbol = '';
          if ( $currency && isset( $symbols[ $currency ] ) ) {
              $symbol = $symbols[ $currency ];
          }

          // description source priority
          if ( ! empty( $shortdesc ) ) {
              $source_desc = $shortdesc;
          } elseif ( has_excerpt( $post_id ) ) {
              $source_desc = get_the_excerpt( $post_id );
          } else {
              $source_desc = get_the_content( null, false, $post_id );
          }

          // --- CLEAN UP HTML / REMOVE script-style-pre-code ---
          $source_desc = preg_replace( '#<script[^>]*>.*?</script>#is', '', $source_desc );
          $source_desc = preg_replace( '#<style[^>]*>.*?</style>#is', '', $source_desc );
          $source_desc = preg_replace( '#<pre[^>]*>.*?</pre>#is', '', $source_desc );
          $source_desc = preg_replace( '#<code[^>]*>.*?</code>#is', '', $source_desc );
          $source_desc = strip_shortcodes( $source_desc );

          // detect list markup
          $has_list_markup = ( stripos( $source_desc, '<ul' ) !== false || stripos( $source_desc, '<ol' ) !== false );

          // thumbnail handling
          $thumb_url = '';
          $thumb_alt = $product_title;
          if ( has_post_thumbnail( $post_id ) ) {
              $thumb_id  = get_post_thumbnail_id( $post_id );
              $thumb_url = wp_get_attachment_image_url( $thumb_id, 'hiregen-product' );
              $alt_meta  = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true );
              if ( $alt_meta ) {
                  $thumb_alt = $alt_meta;
              }
          }

          // excerpt settings
          $word_limit     = 30;
          $max_list_items = 4;

          // If list exists → shorten it
          if ( $has_list_markup ) {
              $source_desc = preg_replace_callback(
                  '#<(ul|ol)([^>]*)>(.*?)</\1>#is',
                  function( $m ) use ( $max_list_items ) {
                      preg_match_all( '#<li\b[^>]*>.*?</li>#is', $m[3], $lis );

                      if ( empty( $lis[0] ) ) {
                          return '<' . $m[1] . $m[2] . '></' . $m[1] . '>';
                      }

                      $keep = array_slice( $lis[0], 0, $max_list_items );

                      if ( count( $lis[0] ) > $max_list_items ) {
                          $keep[] = '<li>…</li>';
                      }

                      return '<' . $m[1] . $m[2] . '>' . implode( '', $keep ) . '</' . $m[1] . '>';
                  },
                  $source_desc
              );
          }

          // sanitize & prepare trimmed version
          $safe_html = wp_kses( $source_desc, $allowed_tags );
          $plain     = wp_strip_all_tags( $safe_html );
          $trimmed   = wp_trim_words( $plain, $word_limit, ' &hellip;' );
          ?>

          <div class="col">
            <div class="card p-3 shadow-sm">

              <?php if ( $thumb_url ) : ?>
                <a href="<?php echo esc_url( $permalink ); ?>" class="card-img-top d-block" aria-label="<?php echo esc_attr( $product_title ); ?>">
                  <img src="<?php echo esc_url( $thumb_url ); ?>"
                       alt="<?php echo esc_attr( $thumb_alt ); ?>"
                       class="img-fluid card-img rounded overflow-hidden border-bottom"
                       style="width:100%; height:185px; object-fit:cover;">
                </a>
              <?php endif; ?>

              <div class="card-body d-flex flex-column">
                <h3 class="h5">
                  <a href="<?php echo esc_url( $permalink ); ?>">
                    <?php echo esc_html( $product_title ); ?>
                  </a>
                </h3>

                <?php
                // show trimmed plain text if long; otherwise show safe HTML
                if ( wp_trim_words( $plain, $word_limit, '' ) !== $plain ) : ?>
                    <p class="card-text" style="margin-bottom:0.7rem;">
                        <a href="<?php echo esc_url( $permalink ); ?>" class="text-muted" style="text-decoration:none; color:inherit;">
                            <?php echo esc_html( $trimmed ); ?>
                        </a>
                    </p>
                <?php else : ?>
                    <div class="card-text" style="margin-bottom:0.7rem;">
                        <?php echo $safe_html; ?>
                    </div>
                <?php endif; ?>

                <div class="mt-auto d-flex justify-content-between align-items-center">
                  <div class="price d-flex">
                    <?php
                    $regular_safe = $regular !== '' ? esc_html( $regular ) : '';
                    $sale_safe    = $sale !== '' ? esc_html( $sale ) : '';

                    if ( $regular_safe && $sale_safe && floatval( $sale ) < floatval( $regular ) ) : ?>
                        <del class="text-muted me-3"><?php echo esc_html( $symbol . $regular_safe ); ?></del>
                        <p class="fw-bold mb-0"><?php echo esc_html( $symbol . $sale_safe ); ?></p>
                    <?php elseif ( $sale_safe ) : ?>
                        <ins class="fw-bold text-success"><?php echo esc_html( $symbol . $sale_safe ); ?></ins>
                    <?php elseif ( $regular_safe ) : ?>
                        <span class="fw-bold"><?php echo esc_html( $symbol . $regular_safe ); ?></span>
                    <?php endif; ?>
                  </div>

                  <?php if ( $buy_url ) : ?>
                    <a href="<?php echo esc_url( $buy_url ); ?>"
                       class="btn btn-outline-secondary btn-sm"
                       target="_blank"
                       rel="noopener noreferrer">
                       <?php esc_html_e( 'Buy Now', 'hiregen-recruitment' ); ?>
                    </a>
                  <?php else : ?>
                    <a href="<?php echo esc_url( $permalink ); ?> "
                       class="btn btn-outline-secondary btn-sm">
                       <?php esc_html_e( 'View Details', 'hiregen-recruitment' ); ?>
                    </a>
                  <?php endif; ?>
                </div>
              </div>
            </div>
          </div>

        <?php endwhile; wp_reset_postdata(); ?>
      <?php endif; ?>
    </div>

    <div class="text-center mt-5">
      <a href="<?php echo esc_url( $btn_url ); ?>" class="btn btn-primary">
        <?php echo esc_html( $btn_text ); ?>
      </a>
    </div>
  </div>
</section>
