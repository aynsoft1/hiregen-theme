<?php
/**
 * Homepage Jobs Section - robust & sanitized version
 * Save path: wp-content/themes/your-active-theme/template-parts/sections/section-jobs.php
 *
 * This file attempts to find values across theme_mods/options while ensuring
 * sanitization, escaping and i18n.
 */

defined( 'ABSPATH' ) || exit;

/**
 * Robust getter: try many places and key names to find a non-empty value.
 *
 * @param array|string $keys    One key or an array of possible keys.
 * @param mixed        $default Default if nothing found.
 * @return mixed
 */
if ( ! function_exists( 'hiregen_get_flexible_setting' ) ) {
    function hiregen_get_flexible_setting( $keys, $default = '' ) {
        if ( is_string( $keys ) ) {
            $keys = array( $keys );
        }

        // 1) Try hiregen_get_theme_mod() then get_theme_mod()
        foreach ( $keys as $k ) {
            if ( function_exists( 'hiregen_get_theme_mod' ) ) {
                $val = hiregen_get_theme_mod( $k, null );
            } else {
                $val = get_theme_mod( $k, null );
            }
            if ( ! empty( $val ) ) {
                return $val;
            }
        }

        // 2) Try get_option for each key
        foreach ( $keys as $k ) {
            $val = get_option( $k );
            if ( ! empty( $val ) ) {
                return $val;
            }
        }

        // 3) Check theme_mods_{stylesheet} array directly
        $stylesheet = get_option( 'stylesheet' );
        if ( $stylesheet ) {
            $theme_mods_key = 'theme_mods_' . $stylesheet;
            $theme_mods = get_option( $theme_mods_key, array() );
            if ( is_array( $theme_mods ) && ! empty( $theme_mods ) ) {
                foreach ( $keys as $k ) {
                    if ( isset( $theme_mods[ $k ] ) && ! empty( $theme_mods[ $k ] ) ) {
                        return $theme_mods[ $k ];
                    }
                }
            }
        }

        // 4) Try common grouped option names
        $option_groups = array( 'hiregen_options', 'theme_options', 'job_section', 'jobs_section', 'hiregen_settings' );
        foreach ( $option_groups as $group ) {
            $opts = get_option( $group, array() );
            if ( is_array( $opts ) && ! empty( $opts ) ) {
                foreach ( $keys as $k ) {
                    if ( isset( $opts[ $k ] ) && ! empty( $opts[ $k ] ) ) {
                        return $opts[ $k ];
                    }
                }
            }
        }

        // 5) No result -> return default
        return $default;
    }
}

/* -- possible keys to search for -- */
$subtitle_keys = array(
    'hiregen_jobs_subtitle',
    'hiregen_job_subtitle',
    'jobs_subtitle',
    'job_section_subtitle',
    'section_jobs_subtitle',
    'section-job-subtitle',
    'jobs_section_subtitle',
);
$title_keys = array(
    'hiregen_jobs_title',
    'hiregen_job_title',
    'jobs_title',
    'job_section_title',
    'section_jobs_title',
    'section-job-title',
    'jobs_section_title',
);
$desc_keys = array(
    'hiregen_jobs_description',
    'hiregen_job_description',
    'jobs_description',
    'job_section_description',
    'section_jobs_description',
    'section-job-description',
    'jobs_section_description',
);

/* -- read values flexibly -- */
$subtitle_raw = hiregen_get_flexible_setting( $subtitle_keys, '' );
$title_raw    = hiregen_get_flexible_setting( $title_keys, '' );
$desc_raw     = hiregen_get_flexible_setting( $desc_keys, '' );

/* -- legacy fallbacks (keeps compatibility) -- */
if ( empty( $subtitle_raw ) ) {
    $subtitle_raw = get_theme_mod( 'hiregen_jobs_subtitle', '' );
}
if ( empty( $title_raw ) ) {
    $title_raw = get_theme_mod( 'hiregen_jobs_title', '' );
}
if ( empty( $desc_raw ) ) {
    $desc_raw = get_theme_mod( 'hiregen_jobs_description', '' );
}

/* -- sanitize theme_mods that are plain text -- */
$subtitle = sanitize_text_field( $subtitle_raw );
$title    = sanitize_text_field( $title_raw );
// $desc may contain simple HTML — sanitize on output using wp_kses_post
$desc     = $desc_raw;

/* -- button text / url / items -- */
$btn_text_raw = get_theme_mod( 'hiregen_jobs_button_text', __( 'See all jobs', 'hiregen-recruitment' ) );
$btn_text     = sanitize_text_field( $btn_text_raw );
$btn_url_raw  = get_theme_mod( 'hiregen_jobs_button_url', '' );
$btn_url      = $btn_url_raw ? esc_url_raw( $btn_url_raw ) : '';
$items_raw    = get_theme_mod( 'hiregen_jobs_count', 3 );
$items        = absint( $items_raw );
if ( $items <= 0 ) {
    $items = 3;
}

/* -- determine fallback URL for jobs archive (WP Job Manager uses 'job_listing') -- */
$job_archive = '';
if ( function_exists( 'get_post_type_archive_link' ) && post_type_exists( 'job_listing' ) ) {
    $job_archive = get_post_type_archive_link( 'job_listing' );
}
if ( ! $btn_url ) {
    $btn_url = $job_archive ? $job_archive : home_url( '/jobs/' );
}

/* -- background color (sanitized) -- */
$jobs_bg_raw = get_theme_mod( 'hiregen_jobs_bg', '' );
$jobs_bg     = sanitize_hex_color( $jobs_bg_raw );
$jobs_style  = '';
if ( ! empty( $jobs_bg ) ) {
    $jobs_style = 'background-color: ' . esc_attr( $jobs_bg ) . ';';
}
?>

<section id="jobs" class="custom-padding" <?php if ( $jobs_style ) : ?>style="<?php echo esc_attr( $jobs_style ); ?>"<?php endif; ?>>

  <div class="container">

    <!-- HEADINGS -->
    <div class="text-center mb-4">
      <?php if ( ! empty( $subtitle ) ) : ?>
        <p class="badge-custom"><?php echo esc_html( $subtitle ); ?></p>
      <?php endif; ?>

      <?php if ( ! empty( $title ) ) : ?>
        <h2 class="display-5 fw-bold mb-3"><?php echo esc_html( $title ); ?></h2>
      <?php endif; ?>

      <?php if ( ! empty( $desc ) ) : ?>
        <p class="section-desc lead mx-auto" style="max-width:700px;">
            <?php
            /**
             * Allow safe post content for description (keeps simple markup).
             * wpautop adds <p> where appropriate — then sanitize with wp_kses_post.
             */
            echo wp_kses_post( wpautop( $desc ) );
            ?>
        </p>
      <?php else : ?>
        <p class="section-desc lead mx-auto" style="max-width:700px;"><?php /* intentionally left blank when no description */ ?></p>
      <?php endif; ?>
    </div>

    <?php
    // Show job listings only if plugin or shortcode exists
    if ( class_exists( 'WP_Job_Manager' ) || shortcode_exists( 'jobs' ) ) {
        $items = max( 1, intval( $items ) );
        // Use do_shortcode with sanitized attributes
        $shortcode = sprintf( '[jobs per_page="%d"]', $items );
        echo do_shortcode( wp_kses_post( $shortcode ) );
    } else {
        // plugin not active - show a safe info message linking to plugin installer
        ?>
        <div class="alert alert-info" role="status">
            <?php
            /* translators: 1: install URL */
            printf(
                /* translators: Use safe HTML only (we keep <strong> and <a>) */
                wp_kses(
                    __( 'For Job listings install and activate <strong>WP Job Manager</strong>. <a href="%s">Install now</a>.', 'hiregen-recruitment' ),
                    array(
                        'strong' => array(),
                        'a'      => array( 'href' => array() ),
                    )
                ),
                esc_url( admin_url( 'plugin-install.php?s=wp+job+manager&tab=search&type=term' ) )
            );
            ?>
        </div>
        <?php
    }
    ?>

    <div class="text-center mt-4">
      <a class="btn btn-primary" href="<?php echo esc_url( $btn_url ); ?>">
        <?php echo esc_html( $btn_text ); ?>
      </a>
    </div>

  </div>
</section>
