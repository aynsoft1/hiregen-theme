<?php
/**
 * inc/enqueue.php
 *
 * Secure, best-practice enqueues for Hiregen theme
 *
 * - Enqueues only on proper hooks
 * - Prefixes handles with hiregen-
 * - Uses get_stylesheet_directory* so child themes override assets
 * - Versions assets with filemtime when present
 * - Uses wp_localize_script() for passing any PHP->JS data (sanitize first)
 * - Adds resource hints via wp_resource_hints instead of echoing in head
 *
 * Updated: ensure Bootstrap (CSS + bundle with Popper) is always enqueued
 * (prefer local theme copy, fall back to CDN). This prevents dropdown/collapse
 * JS failures caused by missing bootstrap bundle or Popper.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Return a version string based on filemtime for cache-busting, fallback to theme version.
 *
 * @param string $relative_path Path relative to stylesheet directory e.g. '/assets/js/main.js'
 * @return false|string
 */
if ( ! function_exists( 'hiregen_asset_version' ) ) {
    function hiregen_asset_version( $relative_path ) {
        $full_path = get_stylesheet_directory() . '/' . ltrim( $relative_path, '/' );
        if ( file_exists( $full_path ) ) {
            return (string) filemtime( $full_path );
        }

        $theme = wp_get_theme();
        return $theme->get( 'Version' ) ?: false;
    }
}

if ( ! function_exists( 'hiregen_enqueue_popup_script' ) ) :
function hiregen_enqueue_popup_script() {
    if ( is_admin() ) {
        return;
    }

    // Only on homepage (adjust if you want everywhere)
    if ( ! is_front_page() && ! is_home() ) {
        return;
    }

    $handle = 'hiregen-popup';
    $script_path = get_template_directory() . '/assets/js/hiregen-popup.js';
    $script_url  = get_template_directory_uri() . '/assets/js/hiregen-popup.js';

    if ( file_exists( $script_path ) ) {
        wp_enqueue_script( $handle, $script_url, array( 'jquery' ), filemtime( $script_path ), true );
    } else {
        wp_enqueue_script( $handle, $script_url, array( 'jquery' ), false, true );
    }

    $storage = get_theme_mod( 'hiregen_popup_storage', 'cookie' );
    $cookie_subdomain = get_theme_mod( 'hiregen_popup_cookie_subdomain', false );

    $cookie_domain = '';
    if ( $cookie_subdomain ) {
        $host = wp_parse_url( home_url(), PHP_URL_HOST );
        $host = preg_replace( '/:\d+$/', '', $host );
        if ( substr_count( $host, '.' ) >= 1 ) {
            $cookie_domain = '.' . preg_replace( '/^www\./', '', $host );
        }
    }

    wp_localize_script( $handle, 'hiregenPopup', array(
        'ajax_url'      => admin_url( 'admin-ajax.php' ),
        'nonce'         => wp_create_nonce( 'hiregen-popup-nonce' ),
        'storage'       => $storage,
        'cookie_domain' => $cookie_domain,
        'cookie_name'   => 'hiregen_popup_closed',
        'cookie_ttl'    => 24 * 60 * 60, // seconds
        'enabled'       => get_theme_mod( 'hiregen_popup_enable', false ),
        'title'         => get_theme_mod( 'hiregen_popup_title', '' ),
        'desc'          => get_theme_mod( 'hiregen_popup_desc', '' ),
        'button_text'   => get_theme_mod( 'hiregen_popup_button_text', __( 'Subscribe', 'hiregen-recruitment' ) ),
    ) );
}
add_action( 'wp_enqueue_scripts', 'hiregen_enqueue_popup_script', 30 );
endif;

// enqueue hiregen popup css
wp_enqueue_style(
  'hiregen-popup-css',
  get_template_directory_uri() . '/assets/css/hiregen-popup.css',
  array(),
  filemtime( get_template_directory() . '/assets/css/hiregen-popup.css' )
);


/**
 * Enqueue front-end styles and scripts
 */
if ( ! function_exists( 'hiregen_enqueue_assets' ) ) {
    function hiregen_enqueue_assets() {
        $dir_uri  = get_stylesheet_directory_uri();
        $dir_path = get_stylesheet_directory();

        // -------------------------
        // Styles
        // -------------------------

        // Primary stylesheet (style.css)
        wp_register_style( 'hiregen-style', get_stylesheet_uri(), array(), hiregen_asset_version( '' ) );
        wp_enqueue_style( 'hiregen-style' );

        // Bootstrap CSS (prefer local theme copy, else CDN)
        $bootstrap_css_rel = '/assets/css/bootstrap.min.css';
        if ( file_exists( $dir_path . $bootstrap_css_rel ) ) {
            wp_register_style(
                'hiregen-bootstrap',
                $dir_uri . $bootstrap_css_rel,
                array(),
                hiregen_asset_version( $bootstrap_css_rel )
            );
        } else {
            // CDN fallback (Bootstrap 5 bundle compatible)
            wp_register_style(
                'hiregen-bootstrap',
                'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css',
                array(),
                '5.3.2'
            );
        }
        wp_enqueue_style( 'hiregen-bootstrap' );

        // Bootstrap Icons: prefer local, otherwise load from CDN with versioning
        $bootstrap_icons_rel = '/assets/css/bootstrap-icons.css';
        if ( file_exists( $dir_path . $bootstrap_icons_rel ) ) {
            wp_register_style( 'hiregen-bootstrap-icons', $dir_uri . $bootstrap_icons_rel, array(), hiregen_asset_version( $bootstrap_icons_rel ) );
        } else {
            wp_register_style( 'hiregen-bootstrap-icons', 'https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css', array(), '1.10.5' );
        }
        wp_enqueue_style( 'hiregen-bootstrap-icons' );

        // Theme custom CSS (hiregen-style override)
        $custom_css_rel = '/assets/css/hiregen-style.css';
        if ( file_exists( $dir_path . $custom_css_rel ) ) {
            // depend on bootstrap if it's registered/enqueued to ensure order
            $deps = array();
            if ( wp_style_is( 'hiregen-bootstrap', 'registered' ) ) {
                $deps[] = 'hiregen-bootstrap';
            }
            $deps[] = 'hiregen-style';
            wp_register_style( 'hiregen-custom', $dir_uri . $custom_css_rel, $deps, hiregen_asset_version( $custom_css_rel ) );
            wp_enqueue_style( 'hiregen-custom' );
        }

        // -------------------------
        // Scripts
        // -------------------------

        // Vendor JS (bootstrap bundle) - prefer local, else CDN bootstrap bundle
        // The bundle includes Popper which is required by Bootstrap's dropdowns/collapse.
        $bootstrap_js_rel = '/assets/js/bootstrap.bundle.min.js';
        if ( file_exists( $dir_path . $bootstrap_js_rel ) ) {
            wp_register_script(
                'hiregen-bootstrap-js',
                $dir_uri . $bootstrap_js_rel,
                array(),
                hiregen_asset_version( $bootstrap_js_rel ),
                true
            );
        } else {
            // CDN fallback for bootstrap bundle (includes Popper)
            wp_register_script(
                'hiregen-bootstrap-js',
                'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js',
                array(),
                '5.3.2',
                true
            );
            // Optional: add SRI/integrity/crossorigin if you have the hash:
            // wp_script_add_data( 'hiregen-bootstrap-js', 'integrity', 'sha384-...' );
            // wp_script_add_data( 'hiregen-bootstrap-js', 'crossorigin', 'anonymous' );
        }
        wp_enqueue_script( 'hiregen-bootstrap-js' );

        // Main theme JS
        // NOTE: keep dependencies minimal. If your main.js uses jQuery, keep it; otherwise you can remove 'jquery'.
        $main_js_rel = '/assets/js/main.js';
        $main_deps   = array();

        // If your main theme code expects jQuery, add it as dependency; otherwise leave it out.
        // To be defensive, only add jquery if a local main.js exists and you want jquery support.
        if ( file_exists( $dir_path . $main_js_rel ) ) {
            // Prefer the bootstrap bundle to be loaded before main script
            $main_deps[] = 'hiregen-bootstrap-js';
            // If you require jQuery in your main.js, uncomment the next line:
            // $main_deps[] = 'jquery';

            wp_register_script(
                'hiregen-main',
                $dir_uri . $main_js_rel,
                $main_deps,
                hiregen_asset_version( $main_js_rel ),
                true
            );
            wp_enqueue_script( 'hiregen-main' );
        }

        // Localize safe data to hiregen-main (do NOT pass raw superglobals)
        if ( wp_script_is( 'hiregen-main', 'enqueued' ) ) {
            $localize = array(
                'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
                'siteUrl'  => esc_url( home_url() ),
                'themeDir' => esc_url( $dir_uri ),
                'nonce'    => wp_create_nonce( 'hiregen_main' ),
            );

            // Example: sanitized query param (if you legitimately need it)
            if ( isset( $_GET['ref'] ) ) {
                $localize['ref'] = sanitize_text_field( wp_unslash( $_GET['ref'] ) );
            }

            wp_localize_script( 'hiregen-main', 'Hiregen', $localize );
        }

        // Live preview JS for Customizer (postMessage support)
        if ( is_customize_preview() ) {
            $customizer_js_rel = '/assets/js/customizer-live.js';
            if ( file_exists( $dir_path . $customizer_js_rel ) ) {
                wp_enqueue_script( 'hiregen-customizer-live', $dir_uri . $customizer_js_rel, array( 'customize-preview' ), hiregen_asset_version( $customizer_js_rel ), true );
            }
        }

        // Add generated CSS from Customizer to the last loaded stylesheet so it overrides defaults.
        if ( function_exists( 'hiregen_customizer_generated_css' ) ) {
            $css = hiregen_customizer_generated_css();
            if ( $css ) {
                // Prefer to attach inline CSS to the 'hiregen-custom' handle if present
                $inline_target = wp_style_is( 'hiregen-custom', 'enqueued' ) ? 'hiregen-custom' : 'hiregen-style';
                wp_add_inline_style( $inline_target, $css );
            }
        }
    }
}

// enqueue menu polyfill file (after bootstrap bundle)
add_action( 'wp_enqueue_scripts', 'hiregen_enqueue_menu_polyfill', 25 );
function hiregen_enqueue_menu_polyfill() {
    $dir_uri = get_stylesheet_directory_uri();
    // Version by filemtime if present
    $poly_rel = '/assets/js/menu-polyfill.js';
    $poly_path = get_stylesheet_directory() . $poly_rel;
    $ver = file_exists( $poly_path ) ? filemtime( $poly_path ) : false;

    // Ensure bootstrap bundle is dependency so bootstrap is loaded first
    wp_enqueue_script( 'hiregen-menu-polyfill', $dir_uri . $poly_rel, array( 'hiregen-bootstrap-js' ), $ver, true );
}

add_action( 'wp_enqueue_scripts', 'hiregen_enqueue_assets', 20 );


/**
 * Add resource hints (preconnect) in a safe way via wp_resource_hints filter.
 *
 * @param array  $urls URLs to print for resource hints.
 * @param string $relation_type Type of hint: 'preconnect', 'dns-prefetch', etc.
 * @return array
 */
if ( ! function_exists( 'hiregen_resource_hints' ) ) {
    function hiregen_resource_hints( $urls, $relation_type ) {
        if ( 'preconnect' === $relation_type ) {
            // Add Google Fonts hosts if fonts are used. Change or remove as needed.
            $hosts = array(
                'https://fonts.gstatic.com',
                'https://fonts.googleapis.com',
                // CDN host for bootstrap/jsdelivr (helps performance if you're using CDN fallbacks)
                'https://cdn.jsdelivr.net',
            );

            foreach ( $hosts as $host ) {
                // Avoid duplicates
                if ( ! in_array( $host, $urls, true ) ) {
                    $urls[] = $host;
                }
            }
        }

        return $urls;
    }
}
add_filter( 'wp_resource_hints', 'hiregen_resource_hints', 10, 2 );

