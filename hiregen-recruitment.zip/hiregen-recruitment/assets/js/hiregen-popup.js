(function($){
    'use strict';

    if ( typeof window.hiregenPopup === 'undefined' ) {
        return;
    }

    var storage = window.hiregenPopup.storage || 'cookie'; // 'cookie' or 'localStorage'
    var cookieName = window.hiregenPopup.cookie_name || 'hiregen_popup_closed';
    var cookieTtl = parseInt(window.hiregenPopup.cookie_ttl || (24*60*60), 10);
    var cookieDomain = window.hiregenPopup.cookie_domain || '';
    var enabled = !!window.hiregenPopup.enabled;

    function setCookie(name, value, seconds) {
        var expires = '';
        if ( seconds ) {
            var d = new Date();
            d.setTime(d.getTime() + (seconds*1000));
            expires = '; expires=' + d.toUTCString();
        }
        var domainStr = cookieDomain ? '; domain=' + cookieDomain : '';
        document.cookie = name + '=' + encodeURIComponent(value) + expires + '; path=/' + domainStr + '; SameSite=Lax';
    }
    function getCookie(name) {
        var nameEQ = name + '=';
        var ca = document.cookie.split(';');
        for ( var i = 0; i < ca.length; i++ ) {
            var c = ca[i];
            while ( c.charAt(0) === ' ' ) c = c.substring(1,c.length);
            if ( c.indexOf(nameEQ) === 0 ) return decodeURIComponent(c.substring(nameEQ.length,c.length));
        }
        return null;
    }
    function setClosed24h() {
        if ( storage === 'localStorage' ) {
            try {
                var item = { closed_until: Date.now() + (cookieTtl * 1000) };
                localStorage.setItem( cookieName, JSON.stringify(item) );
            } catch(e) {}
        } else {
            setCookie( cookieName, 'closed', cookieTtl );
        }
    }
    function setSubmittedNever() {
        if ( storage === 'localStorage' ) {
            try {
                localStorage.setItem( cookieName + '_submitted', '1' );
            } catch(e) {}
        } else {
            setCookie( cookieName + '_submitted', '1', 10 * 365 * 24 * 60 * 60 );
        }
    }
    function isClosedOrSubmitted() {
        if ( storage === 'localStorage' ) {
            try {
                var sub = localStorage.getItem( cookieName + '_submitted' );
                if ( sub === '1' ) return true;
                var raw = localStorage.getItem( cookieName );
                if ( raw ) {
                    var o = JSON.parse(raw);
                    if ( o && o.closed_until && Date.now() < o.closed_until ) {
                        return true;
                    }
                }
            } catch(e){}
            return false;
        } else {
            if ( getCookie( cookieName + '_submitted' ) ) return true;
            if ( getCookie( cookieName ) ) return true;
            return false;
        }
    }

    // map server error codes to friendly messages
    function friendlyMessageFromErrorCode(code) {
        var map = {
            'invalid_nonce': 'Security check failed. Please refresh the page and try again.',
            'spam_detected': 'Submission blocked (spam).',
            'missing_fields': 'Please fill both name and email.',
            'invalid_email': 'Please enter a valid email address.',
            'disposable_email': 'Disposable email addresses are not allowed. Use a real email address.',
            'rate_limited': 'Too many attempts. Please wait a few minutes and try again.',
            'db_error': 'Server error storing subscription. Please try later.',
            'unknown_error': 'An unknown error occurred. Please try again.'
        };
        return map[code] || 'An error occurred. Please try again.';
    }

    $(function(){
        if ( ! enabled ) return;

        if ( isClosedOrSubmitted() ) {
            return;
        }

        var $modal = $('#hiregen-popup-modal');
        if ( ! $modal.length ) return;

        var modal = new bootstrap.Modal( $modal[0], { keyboard: true, backdrop: true } );
        modal.show();

        $modal.on('hidden.bs.modal', function(){
            setClosed24h();
        });

        $modal.on('submit', 'form.hiregen-popup-form', function(e){
            e.preventDefault();
            var $form = $(this);

            // read visible inputs
            var name = $.trim( $form.find('input[name="name"]').val() );
            var email = $.trim( $form.find('input[name="email"]').val() );
            var description = $.trim( $form.find('textarea[name="description"]').val() );

            // honeypot (hidden field) - bots typically fill this
            var hp = $form.find('input[name="hp_name"]').length ? $.trim( $form.find('input[name="hp_name"]').val() ) : '';

            $form.find('.hiregen-popup-message').remove();

            if ( ! name || ! email || ! description ) {
                $form.prepend('<div class="hiregen-popup-message alert alert-danger">Please enter name, email and description.</div>');
                return;
            }

            var $btn = $form.find('button[type="submit"]');
            var orig = $btn.html();
            $btn.prop('disabled', true).text('Saving...');

            // send hp_name as part of payload so server can check honeypot
            $.post( hiregenPopup.ajax_url, {
                action: 'hiregen_save_subscriber',
                nonce: hiregenPopup.nonce,
                name: name,
                email: email,
                hp_name: hp,
                description: description
            }, function( resp ){
                $btn.prop('disabled', false).html(orig);

                // success from server
                if ( resp && resp.success ) {

                    // If double opt-in: server may return message 'confirmation_sent'
                    if ( resp.message && resp.message === 'confirmation_sent' ) {
                        $form.prepend('<div class="hiregen-popup-message alert alert-info">Please check your email and click the confirmation link to complete subscription.</div>');
                        // we may choose to not show popup again — set submitted flag
                        setSubmittedNever();
                        setTimeout(function(){ modal.hide(); }, 1400);
                        return;
                    }

                    // existing subscriber
                    if ( resp.existing ) {
                        $form.prepend('<div class="hiregen-popup-message alert alert-info">Looks like you are already subscribed — thank you!</div>');
                        setSubmittedNever();
                        setTimeout(function(){ modal.hide(); }, 900);
                        return;
                    }

                    // new successful subscription (no double opt-in)
                    $form.prepend('<div class="hiregen-popup-message alert alert-success">Thank you — subscription saved!</div>');
                    setSubmittedNever();
                    setTimeout(function(){ modal.hide(); }, 900);
                    return;
                }

                // not success — show friendly server-provided error if any
                var errCode = (resp && resp.error) ? resp.error : 'unknown_error';
                var friendly = friendlyMessageFromErrorCode(errCode);
                $form.prepend('<div class="hiregen-popup-message alert alert-danger">' + friendly + '</div>');

            }, 'json').fail(function(jqXHR, textStatus){
                $btn.prop('disabled', false).html(orig);

                // Try extracting an error message from JSON if present
                var friendly = 'Request failed. Please try again later.';
                if ( jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.error ) {
                    friendly = friendlyMessageFromErrorCode( jqXHR.responseJSON.error );
                }
                $form.prepend('<div class="hiregen-popup-message alert alert-danger">' + friendly + '</div>');
            });
        });

        // If the user clicks native close button set 24h closed flag
        $modal.on('click', '.btn-close', function(){
            setClosed24h();
        });
    });
})(jQuery);
