<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
/**
 * Filter in `[jobs]` shortcode for job types.
 *
 * This template can be overridden by copying it to yourtheme/job_manager/job-filter-job-types.php.
 *
 * @see         https://wpjobmanager.com/document/template-overrides/
 * @author      Automattic
 * @package     wp-job-manager
 * @category    Template
 * @version     1.31.1
 */

/**
 * Defensive sanitization of inputs that may be passed into this template.
 * $selected_job_types and $job_types are usually supplied by the shortcode handler;
 * sanitize them here to avoid trusting upstream data.
 */
$selected_job_types = isset( $selected_job_types ) ? (array) $selected_job_types : array();
$selected_job_types = array_map( 'sanitize_text_field', $selected_job_types );

$job_types = isset( $job_types ) ? (array) $job_types : array();
$job_types = array_map( 'sanitize_text_field', $job_types );
?>

<?php if ( ! is_tax( \WP_Job_Manager_Post_Types::TAX_LISTING_TYPE ) && empty( $job_types ) ) : ?>
	<ul class="job_types">
		<?php
		$all_types = get_job_listing_types();
		if ( ! empty( $all_types ) && is_array( $all_types ) ) :
			foreach ( $all_types as $type ) :
				// Defensive checks
				if ( ! is_object( $type ) ) {
					continue;
				}

				$slug = isset( $type->slug ) ? sanitize_text_field( $type->slug ) : '';
				$name = isset( $type->name ) ? sanitize_text_field( $type->name ) : '';

				// If slug or name is empty, skip this entry.
				if ( empty( $slug ) || empty( $name ) ) {
					continue;
				}

				$input_id   = 'job_type_' . $slug;
				$label_class = sanitize_html_class( sanitize_title( $type->name ) );
				$is_checked = in_array( $slug, $selected_job_types, true );
				?>
				<li>
					<label for="<?php echo esc_attr( $input_id ); ?>" class="<?php echo esc_attr( $label_class ); ?>">
						<input
							type="checkbox"
							name="filter_job_type[]"
							value="<?php echo esc_attr( $slug ); ?>"
							id="<?php echo esc_attr( $input_id ); ?>"
							<?php checked( $is_checked ); ?> />
						<?php echo esc_html( $name ); ?>
					</label>
				</li>
			<?php
			endforeach;
		endif;
		?>
	</ul>
	<input type="hidden" name="filter_job_type[]" value="" />
<?php elseif ( ! empty( $job_types ) ) : ?>
	<?php foreach ( $job_types as $job_type ) : 
		$job_type_sanitized = sanitize_text_field( $job_type );
		if ( '' === $job_type_sanitized ) {
			continue;
		}
		?>
		<input type="hidden" name="filter_job_type[]" value="<?php echo esc_attr( sanitize_title( $job_type_sanitized ) ); ?>" />
	<?php endforeach; ?>
<?php endif; ?>
