<?php
// footer.php - updated: safer escaping, ARIA roles, and function guards
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

$footer_bg = get_theme_mod( 'hiregen_footer_bg', '#092a5b' );
$footer_style = '';
if ( ! empty( $footer_bg ) ) {
    $footer_style = 'background-color: ' . esc_attr( $footer_bg ) . ';';
}
?>
<footer id="colophon" class="site-footer pt-5" role="contentinfo" <?php if ( $footer_style ) : ?>style="<?php echo esc_attr( $footer_style ); ?>"<?php endif; ?>>
  <div class="container">
    <div class="row">

      <?php
      /**
       * Render functions for each footer column block
       * Column keys: about, widget2, widget3, contact
       *
       * Guard functions with function_exists to avoid redeclare errors.
       */

      if ( ! function_exists( 'hiregen_footer_render_about' ) ) {
          function hiregen_footer_render_about() {
              ?>
              <div class="col-md-3">
                <div class="footer-about">
<?php
$footer_logo = get_theme_mod( 'hiregen_footer_logo' );
$footer_logo_size = absint( get_theme_mod( 'hiregen_footer_logo_size', 160 ) );
$home_url = esc_url( home_url( '/' ) );

if ( $footer_logo ) {
    echo '<div class="footer-logo mb-4" aria-hidden="false">';
    echo '<a href="' . $home_url . '" rel="home" title="' . esc_attr( get_bloginfo( 'name' ) ) . '">';
    echo '<img src="' . esc_url( $footer_logo ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" class="img-fluid" style="max-width:' . $footer_logo_size . 'px; height:auto; display:inline-block;">';
    echo '</a>';
    echo '</div>';
} else {
    echo '<h2 class="site-title mb-3">';
    echo '<a href="' . $home_url . '" rel="home">' . esc_html( get_bloginfo( 'name' ) ) . '</a>';
    echo '</h2>';
}

                  $about = get_theme_mod( 'hiregen_footer_about' );
                  if ( $about ) {
                      // Allow limited HTML via wp_kses_post
                      echo '<div class="footer-about-text">' . wp_kses_post( wpautop( $about ) ) . '</div>';
                  }

                  // Social icons - sanitize class and url
                  $socials = array( 'facebook','twitter','linkedin','instagram','youtube' );
                  echo '<div class="footer-socials my-4" aria-label="' . esc_attr__( 'Social links', 'hiregen-recruitment' ) . '">';
                  foreach ( $socials as $s ) {
                      $url = get_theme_mod( 'hiregen_footer_social_' . $s );
                      if ( $url ) {
                          // Only allow safe URLs
                          $safe_url = esc_url( $url );
                          $label = sprintf( /* translators: %s: social name */ esc_html__( 'Visit our %s profile', 'hiregen-recruitment' ), ucfirst( $s ) );
                          // Sanitize icon class (only alphanum, space, dash, underscore allowed)
                          $icon_class = preg_replace( '/[^A-Za-z0-9_\- ]/', '', $s );
                          printf(
                              '<a class="me-2" href="%1$s" target="_blank" rel="noopener noreferrer" aria-label="%2$s"><i class="bi bi-%3$s bi-custom" aria-hidden="true"></i></a>',
                              $safe_url,
                              esc_attr( $label ),
                              esc_attr( $icon_class )
                          );
                      }
                  }
                  echo '</div>';
                  ?>
                </div>
              </div>
              <?php
          }
      }

      if ( ! function_exists( 'hiregen_footer_render_widget2' ) ) {
          function hiregen_footer_render_widget2() {
              ?>
              <div class="col-md-3">
                <h4 class="widget-title text-white mb-4"><?php esc_html_e( 'Latest Posts', 'hiregen-recruitment' ); ?></h4>

                <?php if ( is_active_sidebar( 'footer-2' ) ) : ?>
                  <?php dynamic_sidebar( 'footer-2' ); ?>
                <?php else : ?>
                  <?php
                  $recent = wp_get_recent_posts( array( 'numberposts' => 5, 'post_status' => 'publish' ) );
                  if ( ! empty( $recent ) ) {
                      echo '<ul class="list-unstyled mb-0 ps-0">';
                      foreach ( $recent as $r ) {
                          printf(
                              '<li><a href="%1$s">%2$s</a></li>',
                              esc_url( get_permalink( $r['ID'] ) ),
                              esc_html( wp_trim_words( $r['post_title'], 12, '...' ) )
                          );
                      }
                      echo '</ul>';
                  } else {
                      echo '<p class="text-muted">' . esc_html__( 'No posts yet.', 'hiregen-recruitment' ) . '</p>';
                  }
                  ?>
                <?php endif; ?>
              </div>
              <?php
          }
      }

      if ( ! function_exists( 'hiregen_footer_render_widget3' ) ) {
          function hiregen_footer_render_widget3() {
              ?>
              <div class="col-md-3">
                <h4 class="widget-title text-white mb-4"><?php esc_html_e( 'Latest Pages', 'hiregen-recruitment' ); ?></h4>

                <?php if ( is_active_sidebar( 'footer-3' ) ) : ?>
                  <?php dynamic_sidebar( 'footer-3' ); ?>
                <?php else : ?>
                  <?php
                  $pages = get_posts( array( 'post_type' => 'page', 'posts_per_page' => 5, 'orderby' => 'date', 'order' => 'DESC' ) );
                  if ( ! empty( $pages ) ) {
                      echo '<ul class="list-unstyled mb-0">';
                      foreach ( $pages as $p ) {
                          printf(
                              '<li><a href="%1$s">%2$s</a></li>',
                              esc_url( get_permalink( $p->ID ) ),
                              esc_html( wp_trim_words( $p->post_title, 12, '...' ) )
                          );
                      }
                      echo '</ul>';
                  } else {
                      echo '<p class="text-muted">' . esc_html__( 'No pages found.', 'hiregen-recruitment' ) . '</p>';
                  }
                  ?>
                <?php endif; ?>
              </div>
              <?php
          }
      }

      if ( ! function_exists( 'hiregen_footer_render_contact' ) ) {
          function hiregen_footer_render_contact() {
              ?>
              <div class="col-md-3">
                <h4 class="widget-title text-white mb-4">
                  <?php echo esc_html( get_theme_mod( 'hiregen_footer_contact_title', __( 'Get in touch', 'hiregen-recruitment' ) ) ); ?>
                </h4>
                <ul class="list-unstyled mb-0 footer-contact-list">
                  <?php if ( $addr = get_theme_mod( 'hiregen_footer_address' ) ) : ?>
                    <li class="d-flex align-items-start mb-2">
                      <i class="bi bi-geo-alt flex-shrink-0 me-3 h4 mb-0" aria-hidden="true"></i>
                      <span><?php echo wp_kses( nl2br( esc_html( $addr ) ), array( 'br' => array() ) ); ?></span>
                    </li>
                  <?php endif; ?>

                  <?php if ( $email = get_theme_mod( 'hiregen_footer_email' ) ) : 
                      $safe_email = antispambot( sanitize_email( $email ) );
                      if ( $safe_email ) : ?>
                        <li class="d-flex align-items-start mb-2">
                          <i class="bi bi-envelope flex-shrink-0 me-3 h4 mb-0" aria-hidden="true"></i>
                          <a href="mailto:<?php echo esc_attr( $safe_email ); ?>" class="text-decoration-none">
                            <?php echo esc_html( $safe_email ); ?>
                          </a>
                        </li>
                      <?php endif;
                  endif; ?>

                  <?php if ( $phone = get_theme_mod( 'hiregen_footer_phone' ) ) : ?>
                    <li class="d-flex align-items-start mb-2">
                      <i class="bi bi-telephone flex-shrink-0 me-3 h4 mb-0" aria-hidden="true"></i>
                      <span><?php echo esc_html( $phone ); ?></span>
                    </li>
                  <?php endif; ?>
                </ul>
              </div>
              <?php
          }
      }

      // Determine order based on Customizer choice
      $footer_order = get_theme_mod( 'hiregen_footer_order', 'default' );

      // Map keys to render callbacks
      $map = array(
          'about'   => 'hiregen_footer_render_about',
          'widget2' => 'hiregen_footer_render_widget2',
          'widget3' => 'hiregen_footer_render_widget3',
          'contact' => 'hiregen_footer_render_contact',
      );

      // default sequence
      $sequence = array( 'about', 'widget2', 'widget3', 'contact' );

      if ( $footer_order === 'swap' ) {
          $sequence = array( 'contact', 'widget2', 'widget3', 'about' );
      } elseif ( $footer_order === 'reverse' ) {
          $sequence = array( 'contact', 'widget3', 'widget2', 'about' );
      }

      // Render the columns in sequence
      foreach ( $sequence as $key ) {
          if ( isset( $map[ $key ] ) && is_callable( $map[ $key ] ) ) {
              call_user_func( $map[ $key ] );
          }
      }
      ?>

    </div>
  </div>

  <!-- Full-width Footer Bottom Links -->
  <div>
    <div class="col-12 mt-4 text-center">
      <?php if ( is_active_sidebar( 'footer-bottom' ) ) : ?>
        <?php dynamic_sidebar( 'footer-bottom' ); ?>
      <?php else : ?>
        <p class="text-muted small mb-0">
          <?php esc_html_e( 'Add your footer links (Terms, Privacy, Sitemap) in Appearance → Widgets → Footer Bottom Links.', 'hiregen-recruitment' ); ?>
        </p>
      <?php endif; ?>
    </div>
  </div>

</footer>

<!-- Go to Top Button -->
<button id="goTopBtn" title="<?php echo esc_attr__( 'Go to top', 'hiregen-recruitment' ); ?>" aria-label="<?php echo esc_attr__( 'Scroll to top', 'hiregen-recruitment' ); ?>">
  <span aria-hidden="true">
    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" fill="currentColor" viewBox="0 0 16 16" role="img" aria-hidden="true">
      <path fill-rule="evenodd" d="M8 12a.5.5 0 0 0 .5-.5V4.707l3.147 3.147a.5.5 0 0 0 .707-.707l-4-4-.007-.007a.5.5 0 0 0-.693.014l-4 4a.5.5 0 1 0 .707.707L7.5 4.707V11.5A.5.5 0 0 0 8 12z"/>
    </svg>
  </span>
</button>

<?php
// WhatsApp floating button
$whatsapp_icon = get_theme_mod( 'hiregen_whatsapp_icon', 'bi bi-whatsapp' );
$whatsapp_link = get_theme_mod( 'hiregen_whatsapp_link', '' );

if ( ! empty( $whatsapp_link ) ) :
    // sanitize icon class and url
    $safe_whatsapp_icon = preg_replace( '/[^A-Za-z0-9_\- ]/', '', $whatsapp_icon );
    $safe_whatsapp_url  = esc_url( $whatsapp_link );
    ?>
    <a
      href="<?php echo $safe_whatsapp_url; ?>"
      class="whatsapp-float"
      target="_blank"
      rel="nofollow noopener noreferrer"
      title="<?php echo esc_attr__( 'Chat on WhatsApp', 'hiregen-recruitment' ); ?>"
      aria-label="<?php echo esc_attr__( 'Chat on WhatsApp', 'hiregen-recruitment' ); ?>"
    >
      <i class="<?php echo esc_attr( $safe_whatsapp_icon ); ?>" aria-hidden="true"></i>
      <span class="screen-reader-text"><?php echo esc_html__( 'Chat on WhatsApp', 'hiregen-recruitment' ); ?></span>
    </a>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>
