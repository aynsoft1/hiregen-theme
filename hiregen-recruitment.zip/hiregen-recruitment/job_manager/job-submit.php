<?php
/**
 * Content for job submission (`[submit_job_form]`) shortcode.
 *
 * This template can be overridden by copying it to yourtheme/job_manager/job-submit.php.
 *
 * @see         https://wpjobmanager.com/document/template-overrides/
 * @author      Automattic
 * @package     wp-job-manager
 * @category    Template
 * @version     1.34.3
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

global $job_manager;

// Defensive defaults and sanitization for variables expected by this template.
$action             = isset( $action ) ? esc_url( $action ) : esc_url( home_url() );
$resume_edit        = isset( $resume_edit ) ? sanitize_text_field( wp_unslash( $resume_edit ) ) : '';
$job_fields         = isset( $job_fields ) && is_array( $job_fields ) ? $job_fields : array();
$company_fields     = isset( $company_fields ) && is_array( $company_fields ) ? $company_fields : array();
$job_id             = isset( $job_id ) ? absint( $job_id ) : 0;
$step               = isset( $step ) ? sanitize_text_field( $step ) : '';
$form               = isset( $form ) ? sanitize_text_field( $form ) : '';
$submit_button_text = isset( $submit_button_text ) ? sanitize_text_field( $submit_button_text ) : esc_html__( 'Submit', 'hiregen-recruitment' );
$can_continue_later  = isset( $can_continue_later ) ? (bool) $can_continue_later : false;

// Captcha version (defensive)
$captcha_version = '';
if ( class_exists( 'WP_Job_Manager\\WP_Job_Manager_Recaptcha' ) ) {
	$captcha_instance = WP_Job_Manager\WP_Job_Manager_Recaptcha::instance();
	if ( is_object( $captcha_instance ) && method_exists( $captcha_instance, 'get_recaptcha_version' ) ) {
		$captcha_version = sanitize_text_field( $captcha_instance->get_recaptcha_version() );
	}
}

// Helper: safe include of a form-field template based on type.
// Only allow alphanumeric, dashes and underscores for type names to avoid directory traversal.
function hiregen_safe_field_template( $type, $args = array() ) {
	$type_safe = preg_match( '/^[a-z0-9_-]+$/i', $type ) ? $type : '';
	if ( empty( $type_safe ) ) {
		return;
	}

	$template = 'form-fields/' . $type_safe . '-field.php';
	get_job_manager_template( $template, $args );
}
?>
<form action="<?php echo $action; ?>" method="post" id="submit-job-form" class="job-manager-form" enctype="multipart/form-data" novalidate>
	<?php
	// Add a nonce for safer processing; verify this nonce in the form handler.
	wp_nonce_field( 'submit_job_form_action', 'submit_job_form_nonce' );

	// Inform user if editing existing job (sanitized).
	if ( ! empty( $resume_edit ) ) {
		/* translators: %s: link to create a new job */
		$create_new_url = esc_url( add_query_arg( array( 'job_manager_form' => 'submit-job', 'new' => '1', 'key' => $resume_edit ), '' ) );
		printf(
			'<p><strong>%s</strong></p>',
			// Use wp_kses_post for allowed markup (<a>) in the message.
			wp_kses_post(
				sprintf(
					/* translators: %s: create new job link */
					__( "You are editing an existing job. %s", 'hiregen-recruitment' ),
					'<a href="' . $create_new_url . '">' . esc_html__( 'Create A New Job', 'hiregen-recruitment' ) . '</a>'
				)
			)
		);
	}
	?>

	<?php do_action( 'submit_job_form_start' ); ?>

	<?php if ( apply_filters( 'submit_job_form_show_signin', true ) ) : ?>
		<?php get_job_manager_template( 'account-signin.php' ); ?>
	<?php endif; ?>

	<?php
	// Ensure capability checks are explicit and defensive.
	$can_post = ( function_exists( 'job_manager_user_can_post_job' ) && job_manager_user_can_post_job() ) || ( function_exists( 'job_manager_user_can_edit_job' ) && job_manager_user_can_edit_job( $job_id ) );

	if ( $can_post ) : 
		?>

		<!-- Job Information Fields -->
		<?php do_action( 'submit_job_form_job_fields_start' ); ?>

		<?php if ( ! empty( $job_fields ) && is_array( $job_fields ) ) : ?>
			<?php foreach ( $job_fields as $key => $field ) : 
				// Defensive: validate field structure
				$field_key = isset( $key ) ? sanitize_key( $key ) : '';
				if ( empty( $field_key ) || ! is_array( $field ) ) {
					continue;
				}

				$field_label = isset( $field['label'] ) ? wp_kses_post( $field['label'] ) : '';
				$field_required = ! empty( $field['required'] );
				$field_type = isset( $field['type'] ) ? sanitize_text_field( $field['type'] ) : 'text';
				?>
				<fieldset class="fieldset-<?php echo esc_attr( $field_key ); ?> fieldset-type-<?php echo esc_attr( $field_type ); ?>">
					<label for="<?php echo esc_attr( $field_key ); ?>">
						<?php
						// Allow safe label HTML (basic tags) but strip scripts etc.
						echo wp_kses( $field_label, array(
							'strong' => array(),
							'em'     => array(),
							'span'   => array( 'class' => array() ),
							'a'      => array( 'href' => array(), 'title' => array() ),
						) );
						// Optional marker (escaped)
						$required_label = $field_required ? '' : ' <small>' . esc_html__( '(optional)', 'hiregen-recruitment' ) . '</small>';
						echo wp_kses( apply_filters( 'submit_job_form_required_label', $required_label, $field ), array( 'small' => array(), 'span' => array() ) );
						?>
					</label>

					<div class="field <?php echo $field_required ? 'required-field' : ''; ?>">
						<?php
						// Use the safe helper to include the appropriate field template.
						hiregen_safe_field_template( $field_type, array( 'key' => $field_key, 'field' => $field ) );
						?>
					</div>
				</fieldset>
			<?php endforeach; ?>
		<?php endif; ?>

		<?php do_action( 'submit_job_form_job_fields_end' ); ?>

		<!-- Company Information Fields -->
		<?php if ( ! empty( $company_fields ) && is_array( $company_fields ) ) : ?>
			<h2 class="text-center my-4 badge-custom"><?php echo esc_html__( 'Company Details', 'hiregen-recruitment' ); ?></h2>

			<?php do_action( 'submit_job_form_company_fields_start' ); ?>

			<?php foreach ( $company_fields as $key => $field ) : 
				$field_key = isset( $key ) ? sanitize_key( $key ) : '';
				if ( empty( $field_key ) || ! is_array( $field ) ) {
					continue;
				}
				$field_label = isset( $field['label'] ) ? wp_kses_post( $field['label'] ) : '';
				$field_required = ! empty( $field['required'] );
				$field_type = isset( $field['type'] ) ? sanitize_text_field( $field['type'] ) : 'text';
				?>
				<fieldset class="fieldset-<?php echo esc_attr( $field_key ); ?> fieldset-type-<?php echo esc_attr( $field_type ); ?>">
					<label for="<?php echo esc_attr( $field_key ); ?>">
						<?php
						echo wp_kses( $field_label, array(
							'strong' => array(),
							'em'     => array(),
							'span'   => array( 'class' => array() ),
							'a'      => array( 'href' => array(), 'title' => array() ),
						) );
						$required_label = $field_required ? '' : ' <small>' . esc_html__( '(optional)', 'hiregen-recruitment' ) . '</small>';
						echo wp_kses( apply_filters( 'submit_job_form_required_label', $required_label, $field ), array( 'small' => array(), 'span' => array() ) );
						?>
					</label>

					<div class="field <?php echo $field_required ? 'required-field' : ''; ?>">
						<?php hiregen_safe_field_template( $field_type, array( 'key' => $field_key, 'field' => $field ) ); ?>
					</div>
				</fieldset>
			<?php endforeach; ?>

			<?php do_action( 'submit_job_form_company_fields_end' ); ?>
		<?php endif; ?>

		<?php do_action( 'submit_job_form_end' ); ?>

		<p>
			<input type="hidden" name="job_manager_form" value="<?php echo esc_attr( $form ); ?>" />
			<input type="hidden" name="job_id" value="<?php echo esc_attr( $job_id ); ?>" />
			<input type="hidden" name="step" value="<?php echo esc_attr( $step ); ?>" />

			<?php
			// Build submit button attributes safely.
			$submit_attrs = array(
				'name'  => 'submit_job',
				'class' => 'button btn btn-primary w-100 mb-4',
				'value' => $submit_button_text,
			);

			// If captcha v3 requires a JS click hook, output the onclick attribute safely.
			$onclick_attr = '';
			if ( 'v3' === $captcha_version ) {
				// Use esc_js for inline JS and esc_attr to output it as an attribute value.
				$onclick_attr = 'jm_job_submit_click(event)';
			}
			?>

			<input
				type="submit"
				name="<?php echo esc_attr( $submit_attrs['name'] ); ?>"
				class="<?php echo esc_attr( $submit_attrs['class'] ); ?>"
				<?php if ( $onclick_attr ) : ?>
					onclick="<?php echo esc_attr( $onclick_attr ); ?>"
				<?php endif; ?>
				value="<?php echo esc_attr( $submit_attrs['value'] ); ?>" />

			<?php if ( $can_continue_later ) : ?>
				<input type="submit" name="save_draft" class="btn btn-outline-secondary w-100 save_draft" value="<?php echo esc_attr__( 'Save Draft', 'hiregen-recruitment' ); ?>" formnovalidate />
			<?php endif; ?>

			<?php
			$spinner_url = esc_url( includes_url( 'images/spinner.gif' ) );
			?>
			<span class="spinner" style="background-image: url(<?php echo $spinner_url; ?>);"></span>
		</p>

	<?php else : ?>

		<?php do_action( 'submit_job_form_disabled' ); ?>

	<?php endif; ?>
</form>
