<?php
/**
 * Archive template for Team CPT (hiregen_team)
 * Place this file in your theme / child theme root as:
 *   wp-content/themes/your-theme/archive-hiregen_team.php
 *
 * Uses Bootstrap 5 markup. Adjust classes to match your theme.
 */

defined( 'ABSPATH' ) || exit;
get_header();
?>

<?php
// Sub Header Section
?>
<div class="sub-header py-4">
  <div class="container">
    <?php
    // Get the "Team" section title from Customizer
    $team_title = get_theme_mod( 'hiregen_team_title', '' );

    if ( ! empty( $team_title ) ) {
        $title_to_show = $team_title;
    } else {
        // fallback: normal post type archive title (string)
        $title_to_show = (string) post_type_archive_title( '', false );
    }
    ?>

    <h1 class="entry-title fw-bold"><?php echo wp_kses_post( $title_to_show ); ?></h1>

    <div class="breadcrumb mb-0" aria-label="<?php echo esc_attr__( 'Breadcrumb', 'hiregen-recruitment' ); ?>">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color:inherit;"><?php esc_html_e( 'Home', 'hiregen-recruitment' ); ?></a>
        &nbsp;→&nbsp;
        <?php echo esc_html( wp_strip_all_tags( $title_to_show ) ); ?>
    </div>
  </div>
</div>


<main id="main" class="site-main py-4" role="main">
  <div class="container">

    <?php if ( have_posts() ) : ?>
      <div class="row g-4">
        <?php
        $i = 0;
        while ( have_posts() ) : the_post();
          $i++;
          $post_id = get_the_ID();
          $card_id = 'teamCard' . (int) $i;
        ?>
          <div class="col-12 col-md-6 col-lg-4">
            <article id="post-<?php echo (int) $post_id; ?>" <?php post_class( 'card p-3 shadow-sm team-card' ); ?> aria-labelledby="<?php echo esc_attr( $card_id ); ?>-title">

              <?php if ( has_post_thumbnail( $post_id ) ) : ?>
                <div class="card-img-top d-flex align-items-center justify-content-center pt-4" aria-hidden="false">
                  <?php
                  // Prefer attachment alt text; fallback to post title.
                  $thumb_id = get_post_thumbnail_id( $post_id );
                  $img_alt = '';
                  if ( $thumb_id ) {
                      $img_alt = trim( get_post_meta( $thumb_id, '_wp_attachment_image_alt', true ) );
                  }
                  if ( empty( $img_alt ) ) {
                      $img_alt = get_the_title( $post_id );
                  }

                  the_post_thumbnail(
                      'hiregen-product',
                      array(
                          'class'   => 'rounded-circle img-fluid',
                          'style'   => 'width:120px;height:120px;object-fit:cover;display:block;',
                          'alt'     => esc_attr( $img_alt ),
                          'loading' => 'lazy',
                      )
                  );
                  ?>
                </div>
              <?php endif; ?>

              <div class="card-body d-flex flex-column text-center">
                <h3 id="<?php echo esc_attr( $card_id ); ?>-title" class="card-title h5 mb-1"><?php echo esc_html( get_the_title( $post_id ) ); ?></h3>

                <?php
                // Role/position: prefer excerpt (often used for role), else try a sanitized meta or first line.
                $role = get_the_excerpt( $post_id );
                if ( ! empty( $role ) ) : ?>
                  <div class="text-muted small mb-3"><?php echo wp_kses_post( wp_trim_words( $role, 16, '...' ) ); ?></div>
                <?php endif; ?>

                <p class="mb-3">
                  <?php
                  // Show a short bio: prefer explicit excerpt, otherwise trimmed content (sanitized).
                  if ( has_excerpt( $post_id ) ) {
                      echo wp_kses_post( wp_trim_words( get_the_excerpt( $post_id ), 20, '...' ) );
                  } else {
                      $raw_content = apply_filters( 'the_content', get_post_field( 'post_content', $post_id ) );
                      // strip tags and trim so we don't output long or unsafe HTML
                      echo wp_kses_post( wp_trim_words( wp_strip_all_tags( $raw_content ), 20, '...' ) );
                  }
                  ?>
                </p>

                <div class="mt-auto">
                  <a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" class="btn btn-sm btn-outline-secondary" aria-label="<?php echo esc_attr( sprintf( esc_html__( 'View profile of %s', 'hiregen-recruitment' ), wp_strip_all_tags( get_the_title( $post_id ) ) ) ); ?>">
                    <?php esc_html_e( 'View Profile', 'hiregen-recruitment' ); ?>
                  </a>
                </div>
              </div><!-- .card-body -->

            </article><!-- .card -->
          </div><!-- .col -->
        <?php endwhile; ?>

        <?php
        // restore global post data
        wp_reset_postdata();
        ?>
      </div><!-- .row -->

      <div class="mt-5 d-flex justify-content-center" role="navigation" aria-label="<?php echo esc_attr__( 'Team navigation', 'hiregen-recruitment' ); ?>">
        <?php
        the_posts_pagination( array(
          'mid_size'           => 2,
          'prev_text'          => esc_html__( '← Prev', 'hiregen-recruitment' ),
          'next_text'          => esc_html__( 'Next →', 'hiregen-recruitment' ),
          'screen_reader_text' => esc_html__( 'Team navigation', 'hiregen-recruitment' ),
        ) );
        ?>
      </div>

    <?php else : ?>

      <div class="no-results py-5 text-center" role="status" aria-live="polite">
        <h2><?php esc_html_e( 'No team members found', 'hiregen-recruitment' ); ?></h2>
        <p class="text-muted"><?php esc_html_e( 'There are no team members to display yet. Please check back later.', 'hiregen-recruitment' ); ?></p>
      </div>

    <?php endif; ?>
  </div><!-- .container -->
</main>

<?php
get_footer();
