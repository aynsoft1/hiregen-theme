<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Projects section - reads from Customizer and hiregen_project CPT
 *
 * Improvements:
 * - sanitize theme_mod values
 * - safe image alt handling and srcset via wp_get_attachment_image
 * - robust button URL resolution with sensible fallbacks
 * - escape all outputs
 *
 * @package Hiregen
 */

// Theme mod values (sanitize)
$bg_raw      = get_theme_mod( 'hiregen_projects_bg', '#ffffff' );
$bg          = sanitize_hex_color( $bg_raw ) ?: esc_attr( $bg_raw );
$subtitle    = sanitize_text_field( get_theme_mod( 'hiregen_projects_subtitle', '' ) );
$title_raw   = get_theme_mod( 'hiregen_projects_title', __( 'Our Projects', 'hiregen-recruitment' ) );
$title       = $title_raw ? wp_kses_post( $title_raw ) : __( 'Our Projects', 'hiregen-recruitment' );
$desc_raw    = get_theme_mod( 'hiregen_projects_description', '' );
$desc        = $desc_raw ? wp_kses_post( $desc_raw ) : '';
$count       = absint( get_theme_mod( 'hiregen_projects_count', 3 ) );
$btn_text_raw = get_theme_mod( 'hiregen_projects_btn_text', __( 'Read more', 'hiregen-recruitment' ) );
$btn_text     = $btn_text_raw ? wp_kses_post( $btn_text_raw ) : __( 'Read more', 'hiregen-recruitment' );

// Saved button URL (may be empty, relative slug, or full URL)
$saved_btn_raw = trim( (string) get_theme_mod( 'hiregen_projects_btn_url', '' ) );
$saved_btn_raw = $saved_btn_raw === '' ? '' : $saved_btn_raw;

// Default archive link - prefer correct post type archive if registered
$default_archive = get_post_type_archive_link( 'hiregen_project' ) ?: home_url( '/projects/' );

/**
 * Helpers to detect URL types (wrapped to avoid redeclare).
 */
if ( ! function_exists( 'hiregen_is_full_url' ) ) {
    function hiregen_is_full_url( $u ) {
        return ( strpos( $u, 'http://' ) === 0 || strpos( $u, 'https://' ) === 0 );
    }
}

if ( ! function_exists( 'hiregen_is_relative_slug' ) ) {
    function hiregen_is_relative_slug( $u ) {
        if ( empty( $u ) ) {
            return false;
        }
        $u = trim( $u );
        if ( strpos( $u, '#' ) === 0 || stripos( $u, 'mailto:' ) === 0 || stripos( $u, 'tel:' ) === 0 ) {
            return false;
        }
        if ( strpos( $u, '://' ) === false && stripos( $u, 'http' ) === false ) {
            return true;
        }
        return false;
    }
}

// Resolve button URL safely
$btn_url = '';

if ( $saved_btn_raw && hiregen_is_full_url( $saved_btn_raw ) ) {
    $btn_url = esc_url_raw( $saved_btn_raw );
}

if ( empty( $btn_url ) && hiregen_is_relative_slug( $saved_btn_raw ) ) {
    $slug = trim( $saved_btn_raw, '/' );
    if ( $slug !== '' ) {
        $page = get_page_by_path( $slug, OBJECT, 'page' );
        if ( $page ) {
            $btn_url = get_permalink( $page->ID );
        } else {
            $maybe = get_page_by_path( $slug );
            if ( $maybe ) {
                $btn_url = get_permalink( $maybe->ID );
            }
        }
    }
}

if ( empty( $btn_url ) && $saved_btn_raw ) {
    if ( strpos( $saved_btn_raw, '#' ) === 0 || stripos( $saved_btn_raw, 'mailto:' ) === 0 || stripos( $saved_btn_raw, 'tel:' ) === 0 ) {
        $btn_url = $saved_btn_raw;
    }
}

if ( empty( $btn_url ) ) {
    $btn_url = $default_archive;
}

$btn_url = esc_url_raw( $btn_url ); // sanitized for output

// Query projects
$args = array(
    'post_type'      => 'hiregen_project',
    'posts_per_page' => max( 1, $count ),
    'orderby'        => 'menu_order date',
    'order'          => 'DESC',
);

$projects = new WP_Query( $args );
?>

<section id="projects" class="custom-padding" style="background-color:<?php echo esc_attr( $bg ); ?>;">
  <div class="container">
    <div class="text-center mb-5">
      <?php if ( $subtitle ) : ?>
        <p class="badge-custom"><?php echo esc_html( $subtitle ); ?></p>
      <?php endif; ?>

      <?php if ( $title ) : ?>
        <h2 class="display-5 fw-bold section-title mb-3"><?php echo wp_kses_post( $title ); ?></h2>
      <?php endif; ?>

      <?php if ( $desc ) : ?>
        <p class="section-desc lead mx-auto" style="max-width:700px;"><?php echo wp_kses_post( $desc ); ?></p>
      <?php endif; ?>
    </div>

    <div class="row row-cols-1 row-cols-md-2 g-4">
      <?php if ( $projects->have_posts() ) : 
        while ( $projects->have_posts() ) : $projects->the_post(); ?>
          <div class="col">
            <article id="post-<?php the_ID(); ?>" <?php post_class( 'card p-3 shadow-sm' ); ?>>
              <?php if ( has_post_thumbnail() ) :
                $thumb_id = get_post_thumbnail_id( get_the_ID() );
                $alt = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true );
                $alt = $alt ? $alt : wp_strip_all_tags( get_the_title() );
                // use wp_get_attachment_image for srcset/responsive attributes
                echo wp_get_attachment_image(
                    $thumb_id,
                    'hiregen-product',
                    false,
                    array(
                        'class' => 'img-fluid card-img rounded overflow-hidden',
                        'alt'   => esc_attr( $alt ),
                    )
                );
              endif; ?>

              <div class="card-body d-flex flex-column">
                <h3 class="h5">
                  <a href="<?php echo esc_url( get_permalink() ); ?>" class="stretched-link">
                    <?php the_title(); ?>
                  </a>
                </h3>

                <p class="card-text flex-grow-1 mb-0">
                  <?php
                    $excerpt = get_the_excerpt();
                    if ( empty( $excerpt ) ) {
                        $excerpt = wp_strip_all_tags( get_the_content() );
                    }
                    echo wp_kses_post( wp_trim_words( $excerpt, 15 ) );
                  ?>
                </p>
              </div>
            </article>
          </div>
        <?php endwhile;
        wp_reset_postdata();
      else : ?>
        <div class="col">
          <p><?php esc_html_e( 'No projects found. Add projects in Admin → Projects.', 'hiregen-recruitment' ); ?></p>
        </div>
      <?php endif; ?>
    </div>

    <?php if ( $btn_text && $btn_url ) : ?>
      <div class="text-center mt-5">
        <a href="<?php echo esc_url( $btn_url ); ?>" class="btn btn-primary"<?php
            // add security attributes for external links
            $parsed = wp_parse_url( $btn_url );
            if ( ! empty( $parsed['host'] ) && $parsed['host'] !== wp_parse_url( home_url(), PHP_URL_HOST ) ) {
                echo ' target="_blank" rel="noopener noreferrer"';
            }
        ?>>
          <?php echo esc_html( wp_strip_all_tags( $btn_text ) ); ?> &rarr;
        </a>
      </div>
    <?php endif; ?>
  </div>
</section>
