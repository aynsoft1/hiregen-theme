<?php
/**
 * Blog section for homepage - sanitized & i18n-ready
 * Place / replace: wp-content/themes/your-theme/template-parts/sections/section-blog.php
 */

defined( 'ABSPATH' ) || exit;

/* --- Helper to prefer hiregen_get_theme_mod when available --- */
if ( ! function_exists( 'hiregen_mod' ) ) {
    function hiregen_mod( $key, $default = '' ) {
        if ( function_exists( 'hiregen_get_theme_mod' ) ) {
            return hiregen_get_theme_mod( $key, $default );
        }
        return get_theme_mod( $key, $default );
    }
}

/* --- Customizer keys --- */
$subtitle_key = 'hiregen_blog_subtitle';
$title_key    = 'hiregen_blog_title';
$desc_key     = 'hiregen_blog_description';
$btn_text_key = 'hiregen_blog_btn_text';
$btn_url_key  = 'hiregen_blog_btn_url';
$items_key    = 'hiregen_blog_items';

/* --- Read and sanitize values --- */
$subtitle_raw = hiregen_mod( $subtitle_key, '' );
$subtitle     = $subtitle_raw ? sanitize_text_field( $subtitle_raw ) : '';

$title_raw = hiregen_mod( $title_key, '' );
$title     = $title_raw ? sanitize_text_field( $title_raw ) : __( 'Our Blog', 'hiregen-recruitment' );

$desc_raw = hiregen_mod( $desc_key, '' );
$desc     = $desc_raw ? wp_kses_post( $desc_raw ) : __( 'Our blog serves as a valuable resource for both job seekers and employers, offering', 'hiregen-recruitment' );

$btn_text_raw = hiregen_mod( $btn_text_key, __( 'Read more →', 'hiregen-recruitment' ) );
$btn_text     = sanitize_text_field( $btn_text_raw );

$btn_url_raw = trim( (string) hiregen_mod( $btn_url_key, '' ) );

$items_raw = hiregen_mod( $items_key, 3 );
$items     = absint( $items_raw );
if ( $items <= 0 ) {
    $items = 3;
}

/* --- Query posts --- */
$args = array(
    'post_type'      => 'post',
    'posts_per_page' => $items,
    'post_status'    => 'publish',
);
$blog = new WP_Query( $args );

/* --- Background color (sanitize) --- */
$blog_bg_raw = hiregen_mod( 'hiregen_blog_bg', '' );
$blog_bg     = sanitize_hex_color( $blog_bg_raw );
$blog_style  = $blog_bg ? 'background-color: ' . esc_attr( $blog_bg ) . ';' : '';

if ( $blog->have_posts() ) :
?>
<section id="blog" class="custom-padding" <?php if ( $blog_style ) : ?>style="<?php echo esc_attr( $blog_style ); ?>"<?php endif; ?>>
  <div class="container">

    <?php if ( $subtitle || $title || $desc ) : ?>
      <header class="section-header text-center mb-5">
        <?php if ( $subtitle ) : ?>
          <p class="badge-custom"><?php echo esc_html( $subtitle ); ?></p>
        <?php endif; ?>

        <?php if ( $title ) : ?>
          <h2 class="display-5 fw-bold section-title h1 mb-3"><?php echo esc_html( $title ); ?></h2>
        <?php endif; ?>

        <?php if ( $desc ) : ?>
          <p class="section-desc lead mx-auto" style="max-width:900px;"><?php echo wp_kses_post( wpautop( $desc ) ); ?></p>
        <?php endif; ?>
      </header>
    <?php endif; ?>

    <div class="row gx-4">
      <?php while ( $blog->have_posts() ) : $blog->the_post(); ?>
        <?php
        $post_id = get_the_ID();
        $post_title = get_the_title( $post_id );
        ?>
        <div class="col-12 col-md-6 col-lg-4">
          <article id="post-<?php echo esc_attr( $post_id ); ?>" <?php post_class( 'card p-3 shadow-sm' ); ?>>
            <?php if ( has_post_thumbnail( $post_id ) ) : ?>
              <a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" class="d-block">
                <div class="img-fluid card-img rounded overflow-hidden" style="height:190px;">
                  <?php
                  $thumb_id = get_post_thumbnail_id( $post_id );
                  $alt_meta = $thumb_id ? get_post_meta( $thumb_id, '_wp_attachment_image_alt', true ) : '';
                  $alt_text = $alt_meta ? $alt_meta : ( $post_title ? $post_title : sprintf( __( 'Post %d', 'hiregen-recruitment' ), $post_id ) );

                  // the_post_thumbnail prints img tag with proper srcset; pass alt via attr array
                  the_post_thumbnail( 'large', array(
                      'class' => 'img-fluid w-100 h-100',
                      'style' => 'object-fit:cover; display:block;',
                      'alt'   => esc_attr( $alt_text ),
                      'loading' => 'lazy',
                  ) );
                  ?>
                </div>
              </a>
            <?php endif; ?>

            <div class="card-body d-flex flex-column p-4">
              <h3 class="h5 mb-2">
                <a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>"
                   class="stretched-link"
                   aria-label="<?php echo esc_attr( sprintf( __( 'Read more about %s', 'hiregen-recruitment' ), $post_title ) ); ?>">
                  <?php
                  if ( $post_title ) {
                      echo esc_html( $post_title );
                  } else {
                      printf( esc_html__( 'View post #%d', 'hiregen-recruitment' ), $post_id );
                  }
                  ?>
                </a>
              </h3>

              <p class="mb-3">
                <?php
                if ( has_excerpt( $post_id ) ) {
                    echo wp_kses_post( wp_trim_words( get_the_excerpt(), 12, '...' ) );
                } else {
                    echo wp_kses_post( wp_trim_words( get_the_content(), 12, '...' ) );
                }
                ?>
              </p>

              <div class="mt-auto">
                <a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" class="btn btn-outline-secondary btn-sm">
                    <?php esc_html_e( 'Read More', 'hiregen-recruitment' ); ?>
                    <span class="screen-reader-text">
                        <?php
                        /* translators: %s: post title */
                        printf( ' ' . esc_html__( 'about %s', 'hiregen-recruitment' ), esc_html( $post_title ) );
                        ?>
                    </span>
                </a>
              </div>
            </div><!-- .card-body -->
          </article><!-- .card -->
        </div><!-- .col -->
      <?php endwhile; wp_reset_postdata(); ?>
    </div><!-- .row -->

    <?php
    // Resolve the "all posts" URL in a safe order:
    // 1) Customizer value if it's a non-placeholder
    // 2) /blog/ virtual route
    // 3) home_url('/')
    $all_posts_url = '';

    $btn_raw_trim = is_string( $btn_url_raw ) ? trim( $btn_url_raw ) : '';
    $is_placeholder = ( $btn_raw_trim === '' || $btn_raw_trim === '#' );

    if ( ! $is_placeholder ) {
        // If fully-qualified URL
        if ( 0 === strpos( $btn_raw_trim, 'http://' ) || 0 === strpos( $btn_raw_trim, 'https://' ) ) {
            $all_posts_url = esc_url_raw( $btn_raw_trim );
        } else {
            // treat as relative slug or path; build full URL
            $slug = trim( $btn_raw_trim, '/' );
            if ( $slug !== '' ) {
                $all_posts_url = home_url( '/' . $slug . '/' );
            }
        }
    }

    if ( empty( $all_posts_url ) ) {
        $all_posts_url = home_url( '/blog/' );
    }

    if ( empty( $all_posts_url ) ) {
        $all_posts_url = home_url( '/' );
    }

    $all_posts_url = esc_url( $all_posts_url );
    ?>

    <p class="text-center mt-5">
      <a href="<?php echo $all_posts_url; ?>" class="btn btn-primary" role="button">
        <?php echo esc_html( $btn_text ); ?> &rarr;
      </a>
    </p>

  </div><!-- .container -->
</section>
<?php
endif; // have_posts
?>
