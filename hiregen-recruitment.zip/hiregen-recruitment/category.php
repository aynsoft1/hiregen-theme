<?php
/**
 * Category archive template (uses same page-title + card layout as archive-hiregen_project.php)
 *
 * @package Hiregen
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header(); // loads head, styles, scripts, bootstrap, etc.
?>

<?php
// Sub Header Section (same style as Projects archive)
$cat_title = single_cat_title( '', false );
$cat_title_escaped = esc_html( $cat_title );
?>
<div class="sub-header py-4">
	<div class="container">
		<h1 class="entry-title fw-bold"><?php echo $cat_title_escaped; ?></h1>

		<div class="breadcrumb mb-0" aria-label="<?php echo esc_attr__( 'Breadcrumb', 'hiregen-recruitment' ); ?>">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color:inherit;"><?php echo esc_html__( 'Home', 'hiregen-recruitment' ); ?></a>
			&thinsp;→&thinsp;
			<span><?php echo $cat_title_escaped; ?></span>
		</div>
	</div>
</div>

<main id="main" class="site-main py-4" role="main" aria-label="<?php echo esc_attr__( 'Category Archive', 'hiregen-recruitment' ); ?>">
	<div class="container">

		<?php if ( have_posts() ) : ?>
			<div class="row g-4"> <!-- grid of cards -->
				<?php
				while ( have_posts() ) :
					the_post();

					$post_id   = get_the_ID();
					$permalink = get_permalink( $post_id );
					$title     = get_the_title( $post_id );
					if ( '' === $title ) {
						/* translators: %s: post ID */
						$title = sprintf( esc_html__( 'Post #%s', 'hiregen-recruitment' ), $post_id );
					}
					$title_escaped = esc_html( $title );
					?>
					<div class="col-12 col-md-6 col-lg-4">
						<article id="post-<?php echo esc_attr( $post_id ); ?>" <?php post_class( 'card p-3 shadow-sm' ); ?>>

							<?php if ( has_post_thumbnail( $post_id ) ) : ?>
								<a href="<?php echo esc_url( $permalink ); ?>" class="d-block" aria-labelledby="post-title-<?php echo esc_attr( $post_id ); ?>">
									<div class="img-fluid card-img rounded overflow-hidden" style="height: 190px;">
										<?php
										// Use get_the_post_thumbnail to return the image HTML and let WP output it.
										echo get_the_post_thumbnail(
											$post_id,
											'large',
											array(
												'class' => 'img-fluid w-100 h-100',
												'style' => 'object-fit:cover; display:block;',
												'alt'   => esc_attr( get_the_title( $post_id ) ),
											)
										);
										?>
									</div>
								</a>
							<?php endif; ?>

							<div class="card-body d-flex flex-column">
								<h5 id="post-title-<?php echo esc_attr( $post_id ); ?>" class="mb-2">
									<a href="<?php echo esc_url( $permalink ); ?>" class="stretched-link">
										<?php echo $title_escaped; ?>
									</a>
								</h5>

								<p class="mb-3">
									<?php
									if ( has_excerpt( $post_id ) ) {
										$excerpt = get_the_excerpt( $post_id );
									} else {
										$excerpt = wp_trim_words( wp_strip_all_tags( get_the_content( null, false, $post_id ) ), 28, '...' );
									}
									echo wp_kses_post( wpautop( $excerpt ) );
									?>
								</p>

								<div class="mt-auto">
									<a href="<?php echo esc_url( $permalink ); ?>" class="btn btn-sm btn-outline-secondary">
										<?php echo esc_html__( 'Read More', 'hiregen-recruitment' ); ?>
									</a>
								</div>
							</div><!-- .card-body -->

						</article><!-- .card -->
					</div><!-- .col -->
				<?php endwhile; ?>

			</div><!-- .row -->

			<div class="mt-5 d-flex justify-content-center" role="navigation" aria-label="<?php echo esc_attr__( 'Posts navigation', 'hiregen-recruitment' ); ?>">
				<?php
				// the_posts_pagination echoes markup; capture and sanitize before output.
				ob_start();
				the_posts_pagination(
					array(
						'mid_size'            => 2,
						'prev_text'           => __( '← Prev', 'hiregen-recruitment' ),
						'next_text'           => __( 'Next →', 'hiregen-recruitment' ),
						'screen_reader_text'  => __( 'Posts navigation', 'hiregen-recruitment' ),
					)
				);
				$pagination = ob_get_clean();
				echo wp_kses_post( $pagination );
				?>
			</div>

			<?php
			// Reset the postdata to avoid interfering with other loops.
			wp_reset_postdata();
			?>

		<?php else : ?>

			<div class="no-results py-5 text-center">
				<h2><?php echo esc_html__( 'No posts found', 'hiregen-recruitment' ); ?></h2>
				<p class="text-muted"><?php echo esc_html__( 'There are no posts to display in this category yet. Please check back later.', 'hiregen-recruitment' ); ?></p>
			</div>

		<?php endif; ?>
	</div><!-- .container -->
</main>

<?php
get_footer();
