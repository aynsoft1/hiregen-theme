/* hiregen-scripts.js - small helpers */
document.addEventListener('DOMContentLoaded', function () {
  // Enable touch-friendly horizontal dragging for logo scroller
  var scrollers = document.querySelectorAll('#featured-logos .d-flex');
  scrollers.forEach(function(scroller){
    var isDown = false, startX, scrollLeft;
    scroller.addEventListener('mousedown', function(e){
      isDown = true;
      scroller.classList.add('active');
      startX = e.pageX - scroller.offsetLeft;
      scrollLeft = scroller.scrollLeft;
    });
    scroller.addEventListener('mouseleave', function(){ isDown = false; scroller.classList.remove('active'); });
    scroller.addEventListener('mouseup', function(){ isDown = false; scroller.classList.remove('active'); });
    scroller.addEventListener('mousemove', function(e){
      if(!isDown) return;
      e.preventDefault();
      var x = e.pageX - scroller.offsetLeft;
      var walk = (x - startX) * 1; // scroll-fast multiplier
      scroller.scrollLeft = scrollLeft - walk;
    });
  });
});


