<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * FAQs section - sanitized & deduplicated
 */

// bail if disabled in Customizer
if ( ! get_theme_mod( 'hiregen_faqs_enable', true ) ) {
    return;
}

/* --- Collect and sanitize settings --- */
$bg_raw    = get_theme_mod( 'hiregen_faqs_bg', '#f7f7f7' );
$bg        = sanitize_hex_color( $bg_raw ) ?: '#f7f7f7';

$subtitle  = sanitize_text_field( get_theme_mod( 'hiregen_faqs_subtitle', '' ) );
$title_raw = get_theme_mod( 'hiregen_faqs_title', __( 'Frequently Asked Questions', 'hiregen-recruitment' ) );
$title     = wp_kses( $title_raw, array( 'strong' => array(), 'em' => array(), 'br' => array() ) );

$desc_raw  = get_theme_mod( 'hiregen_faqs_desc', '' );
$desc      = $desc_raw ? wp_kses_post( $desc_raw ) : '';

$count_raw = get_theme_mod( 'hiregen_faqs_count', 6 );
$count     = absint( $count_raw );
$count     = max( 1, $count );

$btn_text  = sanitize_text_field( get_theme_mod( 'hiregen_faqs_btn_text', '' ) );
$btn_url   = get_theme_mod( 'hiregen_faqs_btn_url', '' );
$btn_url   = $btn_url ? esc_url_raw( $btn_url ) : '';

/* --- Query FAQs --- */
$args = array(
    'post_type'      => 'hiregen_faq',
    'posts_per_page' => $count,
    'orderby'        => 'menu_order date',
    'order'          => 'ASC',
);
$faqs = new WP_Query( $args );

/* --- Determine fallback for button URL if needed --- */
if ( empty( $btn_url ) ) {
    $archive = get_post_type_archive_link( 'hiregen_faq' );
    if ( $archive ) {
        $btn_url = esc_url_raw( $archive );
    } else {
        $btn_url = home_url( '/faq/' );
    }
}
$btn_url = esc_url( $btn_url ); // final escaped URL
?>

<section id="faqs" class="custom-padding" style="background-color:<?php echo esc_attr( $bg ); ?>;">
  <div class="container">
    <div class="text-center mb-5">
      <?php if ( $subtitle ) : ?>
        <p class="badge-custom"><?php echo esc_html( $subtitle ); ?></p>
      <?php endif; ?>

      <?php if ( $title ) : ?>
        <h2 class="display-5 fw-bold section-title mb-3"><?php echo $title; /* sanitized with wp_kses */ ?></h2>
      <?php endif; ?>

      <?php if ( $desc ) : ?>
        <p class="section-desc lead mx-auto" style="max-width:700px;"><?php echo $desc; /* sanitized with wp_kses_post */ ?></p>
      <?php endif; ?>
    </div>

    <div class="row justify-content-center">
      <div class="col-lg-10">
        <!-- Removed role="tablist": this is a Bootstrap accordion (collapse), not tabs.
             Keeping collapse semantics and adding accessible panel roles instead. -->
        <div class="accordion" id="faqAccordion">
          <?php if ( $faqs->have_posts() ) : ?>
            <?php
            // Ensure first item is open (optional). If you want all collapsed by default set $first = false.
            $first = true;
            while ( $faqs->have_posts() ) : $faqs->the_post();
              $post_id      = get_the_ID();
              $collapse_id  = 'faq-' . $post_id;
              $heading_id   = 'heading-' . $post_id;
              // Create a button id for aria relationships (unique)
              $button_id    = $heading_id . '-btn';

              // Title and content sanitized for output
              $faq_title_raw    = get_the_title( $post_id );
              $faq_title        = $faq_title_raw ? wp_kses_post( $faq_title_raw ) : '';
              $faq_content_raw  = get_post_field( 'post_content', $post_id );
              $faq_content      = $faq_content_raw ? wp_kses_post( wpautop( $faq_content_raw ) ) : '';

              // Determine classes / attributes for first vs subsequent items
              $button_collapsed_class = $first ? '' : 'collapsed';
              $aria_expanded = $first ? 'true' : 'false';
              $collapse_show_class = $first ? ' show' : '';
            ?>
              <div class="accordion-item mb-3 border rounded shadow-sm">
                <h3 class="accordion-header" id="<?php echo esc_attr( $heading_id ); ?>">
                  <button
  id="<?php echo esc_attr( $button_id ); ?>"
  class="accordion-button rounded lead p-4 <?php echo esc_attr( $button_collapsed_class ); ?>"
  type="button"
  data-bs-toggle="collapse"
  data-bs-target="#<?php echo esc_attr( $collapse_id ); ?>"
  aria-expanded="<?php echo esc_attr( $aria_expanded ); ?>"
  aria-controls="<?php echo esc_attr( $collapse_id ); ?>"
>
  <span class="faq-question-text"><?php echo esc_html( $faq_title ); ?></span>

  <!-- explicit icon element — do NOT put raw fancy unicode here -->
  <span class="faq-toggle-icon" aria-hidden="true">+</span>
</button>
                </h3>

                <div
                  id="<?php echo esc_attr( $collapse_id ); ?>"
                  class="accordion-collapse collapse<?php echo esc_attr( $collapse_show_class ); ?>"
                  aria-labelledby="<?php echo esc_attr( $button_id ); ?>"
                  data-bs-parent="#faqAccordion"
                >
                  <div class="accordion-body" role="region" aria-labelledby="<?php echo esc_attr( $button_id ); ?>">
                    <?php echo $faq_content; ?>
                  </div>
                </div>
              </div>

            <?php
              $first = false;
            endwhile;
            wp_reset_postdata();
            ?>
          <?php else : ?>
            <p class="text-center"><?php esc_html_e( 'No FAQs found. Add some in Admin → FAQs.', 'hiregen-recruitment' ); ?></p>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <?php if ( $btn_text ) : ?>
      <div class="text-center mt-5">
        <a href="<?php echo esc_url( $btn_url ); ?>" class="btn btn-primary" role="button">
          <?php echo esc_html( $btn_text ); ?> &rarr;
        </a>
      </div>
    <?php endif; ?>

  </div>
</section>
