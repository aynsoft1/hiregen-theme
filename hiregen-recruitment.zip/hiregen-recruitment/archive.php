<?php
/**
 * Archive template
 *
 * - Escapes archive titles & descriptions
 * - Uses semantic headings and roles
 * - Bootstrap-friendly layout (main + sidebar)
 * - Accessible breadcrumb-ish heading and pagination
 * - Safe output and fallbacks
 *
 * @package Hiregen
 */

defined( 'ABSPATH' ) || exit;
get_header();
?>

<?php
// Archive title and description (keep safe).
$archive_title = get_the_archive_title();
$archive_desc  = get_the_archive_description();
$archive_title_plain = wp_strip_all_tags( $archive_title );
?>

<div class="sub-header py-4">
	<div class="container">
		<h1 id="archive-title" class="entry-title fw-bold"><?php echo esc_html( $archive_title_plain ); ?></h1>

		<?php if ( $archive_desc ) : ?>
			<div class="archive-description mb-0">
				<?php echo wp_kses_post( wpautop( $archive_desc ) ); ?>
			</div>
		<?php endif; ?>
	</div>
</div>

<main id="content" class="site-main py-4" role="main" aria-labelledby="archive-title">
	<div class="container">
		<div class="row gx-5">

			<!-- Primary column -->
			<div class="col-12 col-md-8">

				<?php if ( have_posts() ) : ?>

					<div class="list-archive">

						<?php
						/* Start the Loop */
						while ( have_posts() ) :
							the_post();

							$post_id   = get_the_ID();
							$permalink = get_permalink( $post_id );
							$title     = get_the_title( $post_id );
							if ( '' === $title ) {
								/* translators: %s: post ID */
								$title = sprintf( esc_html__( 'Post #%s', 'hiregen-recruitment' ), $post_id );
							}
							?>
							<article id="post-<?php echo esc_attr( $post_id ); ?>" <?php post_class( 'mb-4' ); ?>>

								<div class="card">
									<div class="row g-0 align-items-center">
										<?php if ( has_post_thumbnail( $post_id ) ) : ?>
											<div class="col-auto d-none d-md-block">
												<a href="<?php echo esc_url( $permalink ); ?>" class="d-block" aria-labelledby="post-title-<?php echo esc_attr( $post_id ); ?>">
													<div class="d-inline-block">
														<?php
														echo get_the_post_thumbnail(
															$post_id,
															'medium',
															array(
																'class'   => 'img-fluid rounded-start',
																'loading' => 'lazy',
																'alt'     => esc_attr( get_the_title( $post_id ) ),
															)
														);
														?>
													</div>
												</a>
											</div>
										<?php endif; ?>

										<div class="<?php echo has_post_thumbnail( $post_id ) ? 'col' : 'col-12'; ?>">
											<div class="card-body">
												<h2 id="post-title-<?php echo esc_attr( $post_id ); ?>" class="h5 card-title mb-1">
													<a href="<?php echo esc_url( $permalink ); ?>" class="text-decoration-none"><?php echo esc_html( $title ); ?></a>
												</h2>

												<div class="meta text-muted small mb-2" aria-hidden="true">
													<span class="me-2"><?php echo esc_html( get_the_date( '', $post_id ) ); ?></span>
													<?php if ( 'post' === get_post_type( $post_id ) ) : ?>
														<span class="me-2"><?php echo esc_html( get_the_author_meta( 'display_name', get_post_field( 'post_author', $post_id ) ) ); ?></span>
													<?php endif; ?>
												</div>

												<div class="excerpt mb-2">
													<?php
													// Use get_the_excerpt and sanitize for output.
													$excerpt = get_the_excerpt( $post_id );
													if ( ! $excerpt ) {
														$excerpt = wp_trim_words( wp_strip_all_tags( get_the_content( null, false, $post_id ) ), 40, '...' );
													}
													echo wp_kses_post( wpautop( $excerpt ) );
													?>
												</div>

												<a href="<?php echo esc_url( $permalink ); ?>" class="btn btn-sm btn-outline-primary" aria-label="<?php echo esc_attr( sprintf( __( 'Read more about %s', 'hiregen-recruitment' ), wp_strip_all_tags( $title ) ) ); ?>">
													<?php echo esc_html__( 'Read more', 'hiregen-recruitment' ); ?> &rarr;
												</a>
											</div>
										</div>
									</div>
								</div>

							</article>
						<?php
						endwhile;
						?>
					</div>

					<nav class="pagination-wrapper mt-4" aria-label="<?php echo esc_attr__( 'Posts navigation', 'hiregen-recruitment' ); ?>">
						<?php
						// Capture pagination markup and sanitize.
						ob_start();
						the_posts_pagination(
							array(
								'mid_size'           => 2,
								'prev_text'          => __( '&larr; Previous', 'hiregen-recruitment' ),
								'next_text'          => __( 'Next &rarr;', 'hiregen-recruitment' ),
								'screen_reader_text' => __( 'Posts navigation', 'hiregen-recruitment' ),
							)
						);
						$pagination = ob_get_clean();
						echo wp_kses_post( $pagination );
						?>
					</nav>

				<?php else : ?>

					<div class="card card-body">
						<h2><?php echo esc_html__( 'Nothing Found', 'hiregen-recruitment' ); ?></h2>
						<p><?php echo esc_html__( 'It seems we can’t find what you’re looking for. Try a search or browse the latest posts.', 'hiregen-recruitment' ); ?></p>
						<?php get_search_form(); ?>
					</div>

				<?php endif; ?>

			</div><!-- /.col -->

			<!-- Sidebar -->
			<aside class="col-12 col-md-4" role="complementary" aria-label="<?php echo esc_attr__( 'Sidebar', 'hiregen-recruitment' ); ?>">
				<?php
				if ( is_active_sidebar( 'sidebar-1' ) ) {
					dynamic_sidebar( 'sidebar-1' );
				} else {
					// Simple fallback widgets matching theme style.
					?>
					<div class="card mb-4">
						<div class="card-body p-4">
							<?php get_search_form(); ?>
						</div>
					</div>

					<div class="card mb-4">
						<div class="card-body p-4">
							<h3 class="h6 mb-3"><?php echo esc_html__( 'Categories', 'hiregen-recruitment' ); ?></h3>
							<ul class="list-unstyled mb-0 ps-0">
								<?php
								// wp_list_categories outputs safe markup; pass args to limit output.
								wp_list_categories(
									array(
										'title_li'   => '',
										'show_count' => true,
									)
								);
								?>
							</ul>
						</div>
					</div>
					<?php
				}
				?>
			</aside><!-- /.col -->

		</div><!-- /.row -->
	</div><!-- /.container -->
</main>

<?php
// Reset global post data in case of custom loops elsewhere.
wp_reset_postdata();
get_footer();
