<?php
/**
 * single-job_listing.php
 * Place this file in your active theme root.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

get_header();
global $post;

/**
 * hiregen: return safe company logo HTML from various inputs
 * - accepts <img> HTML, attachment ID, or URL
 * - prefers local attachments to provide width/height/srcset
 */
/**
 * Return safe company logo HTML from various inputs.
 *
 * Accepts:
 *  - HTML markup that contains an <img> (will be sanitized)
 *  - numeric attachment ID
 *  - local or remote URL (local URLs will be converted to attachment IDs whenever possible
 *    to leverage wp_get_attachment_image() which outputs srcset, sizes, width/height)
 *  - arbitrary HTML/text (sanitized and returned)
 *
 * Returns: sanitized HTML string (or empty string)
 */
if ( ! function_exists( 'hiregen_get_company_logo_html' ) ) {
    function hiregen_get_company_logo_html( $logo_value = '', $fallback_alt = '' ) {
        // Normalize input to string for safe checks
        $logo_value = is_null( $logo_value ) ? '' : (string) $logo_value;

        if ( '' === trim( $logo_value ) ) {
            return '';
        }

        // If it already contains an <img> tag (e.g., stored HTML), allow only safe tags/attrs
        if ( strpos( $logo_value, '<img' ) !== false ) {
            return wp_kses_post( $logo_value );
        }

        // If numeric, treat as attachment ID and use WP image helper (best output: srcset, sizes, width/height)
        if ( is_numeric( $logo_value ) ) {
            $attachment_id = (int) $logo_value;
            $img = wp_get_attachment_image(
                $attachment_id,
                'full',
                false,
                array(
                    'class' => 'company_logo',
                    'alt'   => esc_attr( $fallback_alt ),
                )
            );
            return $img ? wp_kses_post( $img ) : '';
        }

        // If it looks like a URL, try resolve to local attachment first
        if ( filter_var( $logo_value, FILTER_VALIDATE_URL ) ) {
            // Prefer attachment_id when possible for better responsive markup
            $attachment_id = attachment_url_to_postid( $logo_value );
            if ( $attachment_id ) {
                $img = wp_get_attachment_image(
                    $attachment_id,
                    'full',
                    false,
                    array(
                        'class' => 'company_logo',
                        'alt'   => esc_attr( $fallback_alt ),
                    )
                );
                return $img ? wp_kses_post( $img ) : '';
            }

            // Remote URL fallback — provide attributes to limit CLS and improve performance
            $img_html = '<img src="' . esc_url( $logo_value ) . '"'
                      . ' class="company_logo"'
                      . ' alt="' . esc_attr( $fallback_alt ) . '"'
                      . ' loading="lazy" decoding="async"'
                      . ' style="max-width:100%;height:auto;display:block;"'
                      . ' />';
            return wp_kses_post( $img_html );
        }

        // Maybe it's an attachment URL without scheme variation; try to convert anyway
        $attachment_id = attachment_url_to_postid( $logo_value );
        if ( $attachment_id ) {
            $img = wp_get_attachment_image(
                $attachment_id,
                'full',
                false,
                array(
                    'class' => 'company_logo',
                    'alt'   => esc_attr( $fallback_alt ),
                )
            );
            return $img ? wp_kses_post( $img ) : '';
        }

        // Finally, if it's plain HTML or text (e.g., a fragment), sanitize and return
        return wp_kses_post( $logo_value );
    }
}

/**
 * Backward-compat wrapper (older code may call hiregen_normalize_logo)
 */
if ( ! function_exists( 'hiregen_normalize_logo' ) ) {
    function hiregen_normalize_logo( $logo_value = '', $fallback_alt = '' ) {
        return hiregen_get_company_logo_html( $logo_value, $fallback_alt );
    }
}


/* --- Job meta (used in sub-header) --- */
$job_location = function_exists( 'get_the_job_location' ) ? get_the_job_location( $post ) : get_post_meta( $post->ID, '_job_location', true );
$posted_date  = get_the_date( '', $post );
$posted_by    = get_the_author_meta( 'display_name', $post->post_author );

$types = get_the_terms( $post->ID, 'job_listing_type' );
$job_types_text = '';
if ( ! empty( $types ) && ! is_wp_error( $types ) ) {
    $names = wp_list_pluck( $types, 'name' );
    $job_types_text = implode( ', ', $names );
}

/* --- Listing expiry (compute early so it can be shown in top bar) --- */
// try multiple possible meta keys
$listing_expires = get_post_meta( $post->ID, '_job_expires', true );
if ( empty( $listing_expires ) ) {
    $listing_expires = get_post_meta( $post->ID, '_listing_expires', true );
}
if ( empty( $listing_expires ) ) {
    $listing_expires = get_post_meta( $post->ID, 'listing_expiry_date', true );
}
// format expiry if possible
$expiry_output = '';
if ( ! empty( $listing_expires ) ) {
    $time = strtotime( $listing_expires );
    if ( $time !== false ) {
        $expiry_output = date_i18n( get_option( 'date_format' ), $time );
    } else {
        $expiry_output = esc_html( $listing_expires );
    }
}

/**
 * ----------------------------
 * JobPosting JSON-LD (validator-friendly)
 * Inserted here so it appears early on the single page.
 * ----------------------------
 */
if ( is_singular( 'job_listing' ) ) {

    // Basic fields
    $job_id   = $post->ID;
    $title    = get_the_title( $job_id );
    $date_posted = get_the_date( 'c', $job_id );
    $raw_description = get_post_field( 'post_content', $job_id );
    $description = wp_strip_all_tags( apply_filters( 'the_content', $raw_description ) );

    // validThrough: prefer raw meta (unformatted) if present
    $valid_through = '';
    if ( ! empty( $listing_expires ) ) {
        // if it's parsable to date, convert to ISO 8601
        $t = strtotime( $listing_expires );
        if ( $t !== false ) {
            $valid_through = date( 'c', $t );
        } else {
            // try other meta keys
            $meta_expires = get_post_meta( $job_id, 'application_deadline', true );
            if ( $meta_expires ) {
                $t2 = strtotime( $meta_expires );
                if ( $t2 !== false ) {
                    $valid_through = date( 'c', $t2 );
                }
            }
        }
    } else {
        $meta_expires = get_post_meta( $job_id, 'application_deadline', true );
        if ( $meta_expires ) {
            $t2 = strtotime( $meta_expires );
            if ( $t2 !== false ) {
                $valid_through = date( 'c', $t2 );
            }
        }
    }

    // Employment type (try taxonomy / meta)
    $employment_type = '';
    if ( ! empty( $types ) && ! is_wp_error( $types ) ) {
        // normalize to array of names or single string
        $emp_names = wp_list_pluck( $types, 'name' );
        $employment_type = implode( ', ', $emp_names );
    } else {
        $employment_type = get_post_meta( $job_id, 'employment_type', true );
        if ( empty( $employment_type ) ) {
            $employment_type = get_post_meta( $job_id, '_job_type', true );
        }
    }

    // Salary (try various meta keys)
    $salary_value = '';
    $salary_currency = '';
    $salary_min = get_post_meta( $job_id, '_job_salary_min', true );
    if ( $salary_min === '' ) {
        $salary_min = get_post_meta( $job_id, '_salary_min', true );
    }
    $salary_max = get_post_meta( $job_id, '_job_salary_max', true );
    if ( $salary_max === '' ) {
        $salary_max = get_post_meta( $job_id, '_salary_max', true );
    }
    $salary_free = get_post_meta( $job_id, '_job_salary', true );
    if ( empty( $salary_free ) ) {
        $salary_free = get_post_meta( $job_id, '_salary', true );
    }
    $salary_currency_meta = get_post_meta( $job_id, '_job_salary_currency', true );
    if ( empty( $salary_currency_meta ) ) {
        $salary_currency_meta = get_post_meta( $job_id, '_salary_currency', true );
    }
    // prefer structured min/max if present
    if ( $salary_min !== '' || $salary_max !== '' ) {
        $salary_currency = $salary_currency_meta ? strtoupper( sanitize_text_field( $salary_currency_meta ) ) : '';
        if ( $salary_min !== '' && $salary_max !== '' ) {
            $salary_value = array(
                "@type" => "MonetaryAmount",
                "currency" => $salary_currency ? $salary_currency : 'INR',
                "value" => array(
                    "@type" => "QuantitativeValue",
                    "minValue" => floatval( $salary_min ),
                    "maxValue" => floatval( $salary_max )
                )
            );
        } else {
            $salary_value = array(
                "@type" => "MonetaryAmount",
                "currency" => $salary_currency ? $salary_currency : 'INR',
                "value" => floatval( $salary_min ?: $salary_max )
            );
        }
    } elseif ( ! empty( $salary_free ) ) {
        // freeform salary -> put as text under baseSalary.value (allowed)
        $salary_value = array(
            "@type" => "MonetaryAmount",
            "currency" => $salary_currency_meta ? strtoupper( sanitize_text_field( $salary_currency_meta ) ) : '',
            "value" => sanitize_text_field( $salary_free )
        );
    }

    // Job location: if we have a string, use as addressLocality fallback
    $job_location_array = array();
    $loc_string = $job_location ? $job_location : get_post_meta( $job_id, '_job_location', true );
    if ( ! empty( $loc_string ) ) {
        $addr = array( "@type" => "PostalAddress", "addressLocality" => wp_strip_all_tags( $loc_string ) );
        $job_location_array[] = array( "@type" => "Place", "address" => $addr );
    }

    // Hiring organization: use company meta if present
    $company_name_meta = get_post_meta( $job_id, '_company_name', true );
    if ( empty( $company_name_meta ) && function_exists( 'get_the_job_listing_company' ) ) {
        $company_name_meta = get_the_job_listing_company();
    }
    $company_logo_meta = get_post_meta( $job_id, '_company_logo', true );
    $company_website_meta = get_post_meta( $job_id, '_company_website', true );
    if ( empty( $company_website_meta ) && function_exists( 'get_job_listing_company_website' ) ) {
        $company_website_meta = get_job_listing_company_website( $post );
    }
    $hiring_org = array( "@type" => "Organization", "name" => $company_name_meta ? $company_name_meta : get_bloginfo( 'name' ) );
    if ( ! empty( $company_logo_meta ) ) {
        // If company_logo_meta is an attachment ID or URL, try to make full URL
        if ( is_numeric( $company_logo_meta ) ) {
            $img_src = wp_get_attachment_url( (int) $company_logo_meta );
            if ( $img_src ) {
                $hiring_org['logo'] = esc_url( $img_src );
            }
        } elseif ( filter_var( $company_logo_meta, FILTER_VALIDATE_URL ) ) {
            $hiring_org['logo'] = esc_url( $company_logo_meta );
        } else {
            // try to convert attachment URL to ID
            $aid = attachment_url_to_postid( $company_logo_meta );
            if ( $aid ) {
                $img_src = wp_get_attachment_url( $aid );
                if ( $img_src ) {
                    $hiring_org['logo'] = esc_url( $img_src );
                }
            }
        }
    } else {
        // fallback to theme logo if present
        $theme_logo = get_theme_mod( 'hiregen_header_logo' );
        if ( $theme_logo ) {
            $hiring_org['logo'] = esc_url( $theme_logo );
        }
    }
    if ( ! empty( $company_website_meta ) ) {
        $hiring_org['sameAs'] = array( esc_url( $company_website_meta ) );
    }

    // Application contact: try common meta keys
    $application_contact = '';
    $app_url_keys = array( 'application', '_application', 'application_url', 'apply_url', 'job_application_url' );
    foreach ( $app_url_keys as $k ) {
        $v = get_post_meta( $job_id, $k, true );
        if ( ! empty( $v ) ) {
            $application_contact = $v;
            break;
        }
    }
    // maybe an email
    if ( empty( $application_contact ) ) {
        $app_email_keys = array( 'application_email', 'apply_email', '_application_email' );
        foreach ( $app_email_keys as $k ) {
            $v = get_post_meta( $job_id, $k, true );
            if ( ! empty( $v ) ) {
                $application_contact = $v;
                break;
            }
        }
    }

    // Build JobPosting array
    $job_posting = array(
        "@context" => "https://schema.org/",
        "@type" => "JobPosting",
        "title" => $title,
        "description" => wp_trim_words( wp_strip_all_tags( $description ), 200, '...' ),
        "datePosted" => $date_posted,
        "hiringOrganization" => $hiring_org,
        "employmentType" => $employment_type ? $employment_type : null,
        "jobLocation" => ! empty( $job_location_array ) ? $job_location_array : null,
        "identifier" => array(
            "@type" => "PropertyValue",
            "name" => get_bloginfo( 'name' ),
            "value" => (string) $job_id
        )
    );

    if ( ! empty( $valid_through ) ) {
        $job_posting['validThrough'] = $valid_through;
    }

    if ( ! empty( $salary_value ) ) {
        $job_posting['baseSalary'] = $salary_value;
    }

    if ( ! empty( $application_contact ) ) {
        // If it looks like an email
        if ( is_email( $application_contact ) ) {
            $job_posting['applicationContact'] = array( "@type" => "ContactPoint", "email" => sanitize_email( $application_contact ) );
        } else {
            // assume URL
            $job_posting['applicationContact'] = array( "@type" => "ContactPoint", "url" => esc_url( $application_contact ) );
        }
    }

    // Clean nulls/empties
    $job_posting_clean = array();
    foreach ( $job_posting as $k => $v ) {
        if ( $v !== null && $v !== '' ) {
            $job_posting_clean[ $k ] = $v;
        }
    }

    // Output JSON-LD
    echo '<script type="application/ld+json">' . PHP_EOL;
    echo wp_json_encode( $job_posting_clean, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
    echo PHP_EOL . '</script>' . PHP_EOL;
}
?>

<!-- Sub-header top bar -->
<div class="sub-header py-4">
  <div class="container">
    <h1 class="entry-title mb-3"><?php the_title(); ?></h1>

<?php
// ----- Improved Salary block (reads salary, currency, unit) -----

// Feature toggles (checkboxes in WPJM settings)
$opt_currency_enabled = get_option( 'job_manager_enable_salary_currency_customization', false );
$opt_unit_enabled     = get_option( 'job_manager_enable_salary_unit_customization', false );

// Currency code => symbol map (extend if needed)
$currency_symbols = array(
    'USD' => '$',
    'EUR' => '€',
    'GBP' => '£',
    'INR' => '₹',
    'AUD' => 'A$',
    'CAD' => 'C$',
    'JPY' => '¥',
    'CNY' => '¥',
);

// numeric formatter
$format_numeric = function( $val ) {
    if ( $val === '' || $val === null ) return '';
    // try numeric strings too
    $clean = str_replace( array( ',', ' ' ), '', (string) $val );
    if ( is_numeric( $clean ) ) {
        return number_format_i18n( (float) $clean );
    }
    return sanitize_text_field( $val );
};

// Read meta fields (admin UI shows these keys)
$salary_raw   = get_post_meta( $post->ID, '_job_salary', true );     // freeform input
if ( $salary_raw === '' ) {
    $salary_raw = get_post_meta( $post->ID, '_salary', true );
}

$salary_min = get_post_meta( $post->ID, '_job_salary_min', true );
if ( $salary_min === '' ) {
    $salary_min = get_post_meta( $post->ID, '_salary_min', true );
}
$salary_max = get_post_meta( $post->ID, '_job_salary_max', true );
if ( $salary_max === '' ) {
    $salary_max = get_post_meta( $post->ID, '_salary_max', true );
}

// ALWAYS read currency/unit meta (so admin-entered values are available)
$meta_currency = get_post_meta( $post->ID, '_job_salary_currency', true );
if ( empty( $meta_currency ) ) {
    $meta_currency = get_post_meta( $post->ID, '_salary_currency', true );
}
$meta_currency = $meta_currency ? strtoupper( sanitize_text_field( $meta_currency ) ) : '';

$meta_unit = get_post_meta( $post->ID, '_job_salary_type', true );
if ( empty( $meta_unit ) ) {
    $meta_unit = get_post_meta( $post->ID, '_salary_type', true );
}
$meta_unit = $meta_unit ? sanitize_text_field( $meta_unit ) : '';

// Also keep previous variables for backward compatibility
$salary_currency = '';
if ( $opt_currency_enabled ) {
    // if option enabled, prefer post meta (already read above)
    $salary_currency = $meta_currency;
}

$salary_unit = '';
if ( $opt_unit_enabled ) {
    $salary_unit = $meta_unit;
}

// Build human-friendly salary output
$salary_output = '';

// 1) prefer raw freeform if present
if ( ! empty( $salary_raw ) ) {
    $raw = trim( (string) $salary_raw );

    // If looks like numeric range "30000-50000" (with - or –)
    if ( preg_match( '/^\s*([0-9\.,]+)\s*[–-]\s*([0-9\.,]+)\s*$/u', $raw, $m ) ) {
        $left  = $format_numeric( $m[1] );
        $right = $format_numeric( $m[2] );
        $salary_output = $left . ' - ' . $right;
    } elseif ( is_numeric( str_replace( array( ',', ' ' ), '', $raw ) ) ) {
        // single numeric
        $salary_output = $format_numeric( $raw );
    } else {
        // freeform text — sanitize (keeps words like "Competitive", "DOE", etc.)
        $salary_output = sanitize_text_field( $raw );
    }
}
// 2) fallback to min/max meta
elseif ( $salary_min !== '' || $salary_max !== '' ) {
    $min = $format_numeric( $salary_min );
    $max = $format_numeric( $salary_max );

    if ( $min !== '' && $max !== '' ) {
        $salary_output = $min . ' - ' . $max;
    } elseif ( $min !== '' ) {
        $salary_output = $min;
    } else {
        $salary_output = $max;
    }
}

// 3) Apply currency (use option to decide symbol vs code, but always show meta if present)
if ( $salary_output ) {
    // Determine which currency code to use (post meta preferred)
    $use_currency = $meta_currency ?: $salary_currency;

    if ( $use_currency ) {
        // If currency customization option enabled, try to use mapped symbol
        if ( $opt_currency_enabled && isset( $currency_symbols[ $use_currency ] ) ) {
            $symbol = $currency_symbols[ $use_currency ];
            // symbols like $ or ₹ should be attached directly
            $salary_output = esc_html( $symbol ) . $salary_output;
        } else {
            // show currency code (e.g. INR, USD) before amount
            $salary_output = esc_html( $use_currency ) . ' ' . $salary_output;
        }
    }

    // Decide which unit to append:
    // - if the opt is enabled, prefer sanitized $meta_unit (as $salary_unit was set earlier)
    // - if opt is disabled but meta exists, still append it (you requested that backend values show)
    if ( ( $opt_unit_enabled && $salary_unit ) || ( ! $opt_unit_enabled && $meta_unit ) ) {
        $append_unit = $salary_unit ?: $meta_unit;
        $salary_output = $salary_output . ' / ' . esc_html( $append_unit );
    }
}

// final safety: ensure plain text
$salary_output = wp_strip_all_tags( (string) $salary_output );
?>

    <div class="breadcrumb mb-2 d-flex gap-4 flex-wrap">
      <?php if ( ! empty( $job_location ) ) : ?>
        <span><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-map-pin"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"></path><circle cx="12" cy="10" r="3"></circle></svg> <?php echo esc_html( $job_location ); ?></span>
      <?php endif; ?>

      <span><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-clock"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
        <?php echo esc_html( human_time_diff( strtotime( $post->post_date ), current_time( 'timestamp' ) ) . ' ' . __( 'ago', 'hiregen-recruitment' ) ); ?>
      </span>

      <?php if ( $job_types_text ) : ?>
        <span><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-briefcase"><path d="M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path><rect width="20" height="14" x="2" y="6" rx="2"></rect></svg> <?php echo esc_html( $job_types_text ); ?></span>
      <?php endif; ?>

      <?php
    // --- Job categories (display after job types) ---
    $job_categories = get_the_terms( $post->ID, 'job_listing_category' );
    if ( ! empty( $job_categories ) && ! is_wp_error( $job_categories ) ) {
        // Extract plain category names
        $cat_names = wp_list_pluck( $job_categories, 'name' );

        // Sanitize each category name individually before imploding
        $cat_names_safe = array_map( 'esc_html', $cat_names );

        // Build comma-separated output
        $cat_output = implode( ', ', $cat_names_safe );
        ?>
        <span class="job-categories">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                 viewBox="0 0 24 24" fill="none" stroke="currentColor"
                 stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                 aria-hidden="true" focusable="false"
                 class="lucide lucide-tag">
                <path d="M20.59 13.41L11 3 3 11l8.59 8.59a2 2 0 0 0 2.83 0l6.17-6.17a2 2 0 0 0 0-2.83z"></path>
                <circle cx="7" cy="7" r="1.5"></circle>
            </svg>
            <?php echo $cat_output; ?>
        </span>
        <?php
    }
?>


<?php if ( ! empty( $salary_output ) ) : ?>
  <span class="job-salary d-flex align-items-center gap-1">
    <!-- icon... -->
    <strong class="salary-amount"><?php echo esc_html( $salary_output ); ?></strong>
  </span>
<?php endif; ?>



      

      <span><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg> <?php echo esc_html( $posted_by ); ?></span>

      <?php if ( $expiry_output ) : ?>
        <span><svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-calendar"><rect x="3" y="4" width="18" height="18" rx="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line></svg>
          <span class="ms-1"><?php esc_html_e( 'Expiry date:', 'hiregen-recruitment' ); ?></span> <?php echo esc_html( $expiry_output ); ?>
        </span>
      <?php endif; ?>
    </div>
  </div>
</div>


<?php
/* Now main listing content and company details */

/* permission check */
if ( ! job_manager_user_can_view_job_listing( $post->ID ) ) {
    get_job_manager_template_part( 'access-denied', 'single-job_listing' );
    get_footer();
    return;
}

/* --- Obtain company details --- */
$company_name = '';
if ( function_exists( 'get_the_job_listing_company' ) ) {
    $company_name = get_the_job_listing_company();
}
if ( empty( $company_name ) ) {
    $company_name = get_post_meta( $post->ID, '_company_name', true );
}

$company_tagline = get_post_meta( $post->ID, '_company_tagline', true );

/* company logo - normalize to HTML <img> if needed */
$company_logo_img = '';

if ( function_exists( 'get_the_company_logo' ) ) {
    $logo_html = get_the_company_logo( $post );
    if ( ! empty( $logo_html ) ) {
        // normalize via helper (handles URL, ID, or HTML)
        $company_logo_img = hiregen_normalize_logo( $logo_html, $company_name ?: get_the_title() );
    }
}

if ( empty( $company_logo_img ) ) {
    $company_logo_meta = get_post_meta( $post->ID, '_company_logo', true );

    if ( $company_logo_meta ) {
        $company_logo_img = hiregen_normalize_logo( $company_logo_meta, $company_name ?: get_the_title() );
    }
}

/* website */
$company_website = get_post_meta( $post->ID, '_company_website', true );
if ( empty( $company_website ) && function_exists( 'get_job_listing_company_website' ) ) {
    $company_website = get_job_listing_company_website( $post );
}

/* company social handles (we'll use twitter in the first card) */
$company_twitter   = get_post_meta( $post->ID, '_company_twitter', true );
if ( empty( $company_twitter ) ) {
    $company_twitter = get_post_meta( $post->ID, 'company_twitter', true );
}

/* company video (we will render this after description in left column) */
$company_video = get_post_meta( $post->ID, '_company_video', true );
if ( empty( $company_video ) ) {
    $company_video = get_post_meta( $post->ID, 'company_video', true );
}
?>

<div class="single_job_listing container">
    <?php if ( get_option( 'job_manager_hide_expired_content', 1 ) && 'expired' === $post->post_status ) : ?>
        <div class="job-manager-info"><?php esc_html_e( 'This listing has expired.', 'hiregen-recruitment' ); ?></div>
    <?php else : ?>

        <!-- Two column layout: left 8, right 4 -->
        <div class="row g-5">
            <div class="col-12 col-md-8">
                <div class="card">
                    <div class="card-body">
                <div class="job_description mb-5">
                    <?php wpjm_the_job_description(); ?>
                </div>

                <!-- moved company video here (left column after description) -->
                <?php if ( ! empty( $company_video ) ) :
                    // sanitize URL for processing (use esc_url_raw when passing to APIs)
                    $company_video_raw = esc_url_raw( $company_video );

                    // request an oEmbed; width kept for layout but provider may ignore
                    $embed = $company_video_raw ? wp_oembed_get( $company_video_raw, array( 'width' => 850 ) ) : false;

                    if ( $embed ) : ?>
                        <div class="company-video">
                            <?php
                            // sanitize oEmbed HTML before printing
                            echo wp_kses_post( $embed );
                            ?>
                        </div>
                    <?php else : ?>
                        <p class="">
                            <a href="<?php echo esc_url( $company_video ); ?>" target="_blank" rel="noopener noreferrer">
                                <?php esc_html_e( 'Company Video', 'hiregen-recruitment' ); ?>
                            </a>
                        </p>
                    <?php endif;
                endif; ?>

                <?php
                /* NOTE: The left-column apply area has been removed as requested.
                   If you previously relied on `job-application.php` to show an embedded
                   application form here, it will no longer display. The sidebar still
                   contains the Apply button which opens the modal. */
                ?>

                <?php do_action( 'single_job_listing_end' ); ?>
            </div>
            </div>
            </div>


            <div class="col-12 col-md-4">
                <?php
                // fetch extra meta values (with fallbacks) for sidebar display
                $company_facebook  = get_post_meta( $post->ID, '_company_facebook', true );
                $company_linkedin  = get_post_meta( $post->ID, '_company_linkedin', true );
                $company_instagram = get_post_meta( $post->ID, '_company_instagram', true );
                ?>

                <!-- SIDEBAR: Card 1 - company info -->
                <?php if ( $company_logo_img || $company_name || $company_tagline || $company_twitter || $company_website ) : ?>
                    <div class="card mb-4 bg-light">
                        <div class="card-body text-center">
                            <?php if ( $company_logo_img ) : ?>
                                <div class="company-logo mb-3"><?php echo wp_kses_post( $company_logo_img ); ?></div>
                            <?php endif; ?>

                            <?php if ( $company_name ) : ?>
                                <h4 class="company-name mb-1"><?php echo esc_html( $company_name ); ?></h4>
                            <?php endif; ?>

                            <?php if ( $company_tagline ) : ?>
                                <p class="company-tagline text-muted small mb-3"><?php echo esc_html( $company_tagline ); ?></p>
                            <?php endif; ?>

                            <?php if ( $company_twitter ) :
                                $twitter_link = ( strpos( $company_twitter, 'http' ) === 0 ) ? $company_twitter : 'https://twitter.com/' . ltrim( $company_twitter, '@' );
                            ?>
                                <span>
                                    <a class="btn btn-outline-secondary me-3" href="<?php echo esc_url( $twitter_link ); ?>" target="_blank" rel="noopener noreferrer"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" class="lucide lucide-twitter-x">
  <path d="M18.244 2H21.5l-7.39 8.451L22 22h-6.563l-5.144-6.49L4.39 22H1.133l7.925-9.067L2 2h6.75l4.715 6.045L18.244 2Zm-2.315 18h1.708L8.153 4H6.29l9.639 16Z"/>
</svg>
 
                                    Twitter</a>
                                </span>
                            <?php endif; ?>

                            <?php if ( $company_website ) : ?>
                                <span>
                                    <a class="btn btn-outline-secondary" href="<?php echo esc_url( $company_website ); ?>" target="_blank" rel="noopener noreferrer"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-link" data-lov-id="src/pages/Index.tsx:22:12" data-lov-name="WebsiteUrlIcon" data-component-path="src/pages/Index.tsx" data-component-line="22" data-component-file="Index.tsx" data-component-name="WebsiteUrlIcon" data-component-content="%7B%22className%22%3A%22mx-auto%20mb-4%20h-12%20w-12%20text-primary%22%7D"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path></svg> Website</a></span>
                            <?php endif; ?>

                            <div class="company-social d-flex justify-content-center gap-2 mt-3">
                                <?php if ( $company_facebook ) : ?>
                                    <a href="<?php echo esc_url( $company_facebook ); ?>" target="_blank" rel="noopener noreferrer"><span class="dashicons dashicons-facebook"></span></a>
                                <?php endif; if ( $company_twitter ) : ?>
                                    <a href="<?php echo esc_url( $twitter_link ); ?>" target="_blank" rel="noopener noreferrer"><span class="dashicons dashicons-twitter"></span></a>
                                <?php endif; if ( $company_linkedin ) : ?>
                                    <a href="<?php echo esc_url( $company_linkedin ); ?>" target="_blank" rel="noopener noreferrer"><span class="dashicons dashicons-linkedin"></span></a>
                                <?php endif; if ( $company_instagram ) : ?>
                                    <a href="<?php echo esc_url( $company_instagram ); ?>" target="_blank" rel="noopener noreferrer"><span class="dashicons dashicons-instagram"></span></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- SIDEBAR: Card 2 - Apply button -->
                <div class="card bg-light">
                    <div class="card-body">
                        <!-- Apply button opens CF7 modal -->
                        <button type="button" class="btn btn-primary w-100 mb-0" data-bs-toggle="modal" data-bs-target="#jobApplyModal">
                          <?php _e('Apply for Job','hiregen-recruitment'); ?>
                        </button>
                    </div>
                </div>

            </div>
        </div>

    <?php endif; ?>
</div>

<?php
// --- Related jobs (styled like WP Job Manager job list) ---
$related_args = array(
    'post_type'      => 'job_listing',
    'posts_per_page' => 6,
    'post__not_in'   => array( $post->ID ),
    'orderby'        => 'date',
    'order'          => 'DESC',
);

// try to find related by same category if available
$job_cats = get_the_terms( $post->ID, 'job_listing_category' );
if ( ! empty( $job_cats ) && ! is_wp_error( $job_cats ) ) {
    $cat_ids = wp_list_pluck( $job_cats, 'term_id' );
    $related_args['tax_query'] = array(
        array(
            'taxonomy' => 'job_listing_category',
            'field'    => 'term_id',
            'terms'    => $cat_ids,
        ),
    );
}

$related_query = new WP_Query( $related_args );

if ( $related_query->have_posts() ) : ?>
    <div class="related-jobs container">
        <h4 class="mb-3"><?php esc_html_e( 'Related Jobs', 'hiregen-recruitment' ); ?></h4>
        <ul class="job_listings mb-5 ps-0">
            <?php while ( $related_query->have_posts() ) : $related_query->the_post(); global $post; ?>
                <?php
                // Company / meta helpers (these functions exist in WP Job Manager or fallbacks)
                $rel_company = function_exists( 'get_the_job_listing_company' ) ? get_the_job_listing_company() : get_post_meta( $post->ID, '_company_name', true );
                $rel_location = function_exists( 'get_the_job_location' ) ? get_the_job_location( $post ) : get_post_meta( $post->ID, '_job_location', true );
                $rel_types = get_the_terms( $post->ID, 'job_listing_type' );
                $rel_type_text = '';
                if ( ! empty( $rel_types ) && ! is_wp_error( $rel_types ) ) {
                    $names = wp_list_pluck( $rel_types, 'name' );
                    $rel_type_text = esc_html( $names[0] ?? implode( ', ', $names ) );
                }

                // ===== robust company logo generation =====
                $rel_logo = '';

                // 1) try WP Job Manager helper
                if ( function_exists( 'get_the_company_logo' ) ) {
                    $maybe = get_the_company_logo( $post );
                    if ( ! empty( $maybe ) ) {
                        $rel_logo = hiregen_normalize_logo( $maybe, $rel_company ?: get_the_title() );
                    }
                }

                // 2) fallback to meta _company_logo (attachment ID, URL or HTML)
                if ( empty( $rel_logo ) ) {
                    $meta_logo = get_post_meta( $post->ID, '_company_logo', true );
                    if ( ! empty( $meta_logo ) ) {
                        $rel_logo = hiregen_normalize_logo( $meta_logo, $rel_company ?: get_the_title() );
                    }
                }

                // 3) optional: use a placeholder if still empty (uncomment to use)
                if ( empty( $rel_logo ) ) {
                    // placeholder image path (optional)
                    // $rel_logo = '<img src="' . esc_url( get_stylesheet_directory_uri() . '/assets/img/company-placeholder.png' ) . '" class="company_logo" alt="Company">';
                }
                // ============================================
                ?>

                <li class="card shadow-sm job_listing mb-3">
                    <a href="<?php the_permalink(); ?>">
                        <div class="positio d-flex align-items-center">
                            <?php if ( ! empty( $rel_logo ) ) : ?>
                                <div class="company_logo_wrap me-3"><?php echo wp_kses_post( $rel_logo ); ?></div>
                            <?php endif; ?>

                            <div class="position-info flex-grow-1 ms-5">
                                <h3 class="job_listing-title mb-0"><?php the_title(); ?></h3>
                                <?php if ( $rel_company ) : ?>
                                    <div class="company"><?php echo esc_html( $rel_company ); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="meta text-end flex-grow-1 ms-3">
                                <?php if ( $rel_location ) : ?>
                                    <div class="location d-block small text-muted"><?php echo esc_html( $rel_location ); ?></div>
                                <?php endif; ?>

                                <?php if ( $rel_type_text ) : ?>
                                    <span class="job-type badge bg-transparent border <?php echo esc_attr( sanitize_html_class( 'job-type-' . strtolower( preg_replace( '/\s+/', '-', $rel_type_text ) ) ) ); ?>">
                                        <?php echo esc_html( $rel_type_text ); ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </a>
                </li>
            <?php endwhile; ?>
        </ul>
    </div>
<?php
    wp_reset_postdata();
endif;
?>


<!-- Job Application Modal -->
<div class="modal fade" id="jobApplyModal" tabindex="-1" aria-labelledby="jobApplyModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="jobApplyModalLabel"><?php _e('Apply for:','hiregen-recruitment'); ?> <?php the_title(); ?></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php esc_attr_e( 'Close', 'hiregen-recruitment' ); ?>"></button>
      </div>
      <div class="modal-body p-4">
        <?php
        /*
         * Replace the ID below with your actual Contact Form 7 form shortcode if needed.
         * It's better to use numeric ID like [contact-form-7 id="123" title="Job Application"]. 
         */
        echo do_shortcode('[contact-form-7 id="77dc84e" title="Job Application Form"]');
        ?>
      </div>
    </div>
  </div>
</div>

<?php
get_footer();
?>
