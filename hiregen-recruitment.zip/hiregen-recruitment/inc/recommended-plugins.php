<?php
// inc/recommended-plugins.php
// Registers recommended plugins with TGMPA if available; otherwise shows a minimal admin notice
// instructing the user how to install required/recommended plugins (no bundled zip / no direct zip install).

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function hiregen_register_recommended_plugins() {

    // If TGMPA is available, register plugins (preferred).
    // NOTE: Do NOT reference a bundled zip here. Register by slug so TGMPA will fetch from WP.org
    if ( function_exists( 'tgmpa' ) ) {
        $plugins = array(
            array(
                'name'     => 'Hiregen CPTs',
                'slug'     => 'hiregen-cpts',
                'required' => false,
                // no 'source' => avoid bundled zip; let TGMPA install from WP repo or external repo if configured
            ),
            array(
                'name'     => 'WP Job Manager',
                'slug'     => 'wp-job-manager',
                'required' => false,
            ),
            array(
                'name'     => 'Contact Form 7',
                'slug'     => 'contact-form-7',
                'required' => false,
            ),
        );

        $config = array(
            'id'           => 'hiregen-recruitment',
            'default_path' => '',
            'menu'         => 'tgmpa-install-plugins',
            'has_notices'  => true,
            'dismissable'  => true,
            'is_automatic' => false,
            'message'      => '',
        );

        tgmpa( $plugins, $config );
        return;
    }

    // If TGMPA is not present, function ends and a minimal admin notice (fallback) will handle notifying the user.
}
add_action( 'init', 'hiregen_register_recommended_plugins' );


/**
 * Fallback admin notice — only shows when TGMPA is NOT available.
 * NOTE: This fallback intentionally does NOT provide a direct ZIP download link.
 * It points users to the plugin install screen or to your external plugin repository.
 */
add_action( 'admin_notices', function() {
    // Only show to users who can install plugins
    if ( ! current_user_can( 'install_plugins' ) ) {
        return;
    }

    // If TGMPA exists, no need to show fallback
    if ( function_exists( 'tgmpa' ) ) {
        return;
    }

    // Prefer to point users to the WordPress plugin install page or your hosted repo (update the URL below)
    $install_plugins_url = esc_url( admin_url( 'plugin-install.php' ) );
    $external_repo_url   = esc_url( 'https://github.com/your-org/hiregen-cpts/releases' ); // update to your real repo if applicable

    ?>
    <div class="notice notice-info is-dismissible">
        <p><strong><?php esc_html_e( 'Hiregen: Recommended plugins', 'hiregen-recruitment' ); ?></strong></p>
        <p>
            <?php esc_html_e( 'To enable Services, Projects, Testimonials and Team sections, please install the recommended plugins via the WordPress plugin installer or from your plugin repository.', 'hiregen-recruitment' ); ?>
            <br/>
            <a href="<?php echo $install_plugins_url; ?>"><?php esc_html_e( 'Install plugins (WordPress plugin installer)', 'hiregen-recruitment' ); ?></a>
            &nbsp;|&nbsp;
            <a href="<?php echo $external_repo_url; ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Download / view Hiregen CPTs (external repo)', 'hiregen-recruitment' ); ?></a>
        </p>
    </div>
    <?php
} );
