<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>

<header id="masthead" class="site-header" role="banner" aria-label="<?php esc_attr_e( 'Site Header', 'hiregen-recruitment' ); ?>">
	<a class="skip-link sr-only sr-only-focusable" href="#content"><?php esc_html_e( 'Skip to content', 'hiregen-recruitment' ); ?></a>

	<div class="container d-flex align-items-center justify-content-between py-3">
		<div class="site-branding d-flex align-items-center">
			<?php
			// Custom logo (if set) otherwise site title.
			if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
				the_custom_logo();
			} else {
				?>
				<div class="site-title-wrap">
					<a class="site-title h4 mb-0" href="<?php echo esc_url( home_url( '/' ) ); ?>">
						<?php bloginfo( 'name' ); ?>
					</a>
					<?php if ( get_bloginfo( 'description' ) ) : ?>
						<p class="site-description mb-0 small"><?php bloginfo( 'description' ); ?></p>
					<?php endif; ?>
				</div>
				<?php
			}
			?>
		</div>

		<button class="btn btn-light d-md-none mobile-nav-toggle" aria-expanded="false" aria-controls="site-navigation" aria-label="<?php esc_attr_e( 'Toggle navigation', 'hiregen-recruitment' ); ?>">
			<span class="navbar-toggler-icon"></span>
		</button>

		<nav id="site-navigation" class="main-navigation" role="navigation" aria-label="<?php esc_attr_e( 'Primary Menu', 'hiregen-recruitment' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'primary',
					'container'      => '',
					'menu_class'     => 'nav d-none d-md-flex gap-3',
					'fallback_cb'    => 'wp_page_menu',
				)
			);
			?>
		</nav>

		<div class="header-actions d-none d-md-block">
			<?php get_search_form(); ?>
		</div>
	</div>
</header>
