<?php
/**
 * Archive: hiregen_testimonial
 * Matches the homepage testimonial section layout
 * Save as: wp-content/themes/your-active-theme/archive-hiregen_testimonial.php
 */

defined( 'ABSPATH' ) || exit;

get_header();

// Setup paged and query args safely
$paged = max( 1, (int) get_query_var( 'paged' ) );
$args = array(
    'post_type'      => 'hiregen_testimonial',
    'post_status'    => 'publish',
    'posts_per_page' => 9,
    'paged'          => $paged,
);

// Use a dedicated query object and ensure we reset afterwards
$q = new WP_Query( $args );

/**
 * Render stars as inline spans (keeps markup simple)
 * Wrapped in function_exists for safety.
 */
if ( ! function_exists( 'hiregen_render_stars' ) ) {
    function hiregen_render_stars( $rating ) {
        $rating = intval( $rating );
        if ( $rating < 0 ) {
            $rating = 0;
        }
        if ( $rating > 5 ) {
            $rating = 5;
        }

        // Build markup with safe elements only
        $out = '<div class="d-flex align-items-center mb-4 hiregen-testimonial-stars" aria-hidden="true" style="gap:.35rem;">';
        for ( $i = 1; $i <= 5; $i++ ) {
            if ( $i <= $rating ) {
                // filled star — use a semantic span and an accessible title on container if needed
                $out .= '<span class="hiregen-star hiregen-star-filled" aria-hidden="true" style="font-size:1.2rem;display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:7px;">'
                      . '<span class="bi bi-star-fill" aria-hidden="true">★</span>'
                      . '</span>';
            } else {
                $out .= '<span class="hiregen-star hiregen-star-empty" aria-hidden="true" style="font-size:1.05rem;display:inline-flex;align-items:center;justify-content:center;width:40px;height:40px;border-radius:7px;color:#e6e6e6;">★</span>';
            }
        }
        $out .= '</div>';

        // Return safe HTML string: allowed tags are span and div with classes/styles
        return $out;
    }
}
?>

<?php
// Sub Header Section
?>
<div class="sub-header py-4">
  <div class="container">
    <?php
    // Get the Testimonial Section Title from Customizer
    $testimonial_title = get_theme_mod( 'hiregen_testimonial_title', '' );

    if ( ! empty( $testimonial_title ) ) {
        $title_to_show = $testimonial_title;
    } else {
        // fallback: normal archive title (string)
        $title_to_show = (string) post_type_archive_title( '', false );
    }
    ?>
    <h1 class="entry-title fw-bold"><?php echo wp_kses_post( $title_to_show ); ?></h1>
    <div class="breadcrumb mb-0" aria-label="<?php echo esc_attr__( 'Breadcrumb', 'hiregen-recruitment' ); ?>">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color:inherit;"><?php esc_html_e( 'Home', 'hiregen-recruitment' ); ?></a>
        &nbsp;→&nbsp;<?php echo esc_html( wp_strip_all_tags( $title_to_show ) ); ?>
    </div>
  </div>
</div>

<main id="main" class="site-main py-4" role="main">
  <div class="container">

    <?php if ( $q instanceof WP_Query && $q->have_posts() ) : ?>
      <div class="row row-cols-1 row-cols-md-2 row-cols-lg-2 g-4">
        <?php
        while ( $q->have_posts() ) :
            $q->the_post();
            $post_id     = get_the_ID();
            $rating      = get_post_meta( $post_id, 'hiregen_testimonial_rating', true );
            $designation = get_post_meta( $post_id, 'hiregen_testimonial_designation', true );
            $thumb_id    = get_post_thumbnail_id( $post_id );

            // Prepare avatar markup (right aligned) - same logic as section but sanitized
            if ( $thumb_id ) {
                // get alt text from attachment meta; fallback to post title
                $alt = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true );
                if ( ! $alt ) {
                    $alt = get_the_title( $post_id );
                }
                // wp_get_attachment_image returns safe HTML; still pass expected attributes
                $avatar_html = wp_get_attachment_image(
                    $thumb_id,
                    'hiregen-product',
                    false,
                    array(
                        'class' => 'rounded-custom',
                        'alt'   => esc_attr( $alt ),
                        'style' => 'object-fit:cover;border-radius:8px;display:block;',
                        'loading' => 'lazy',
                    )
                );
            } else {
                // fallback: initials (escaped)
                $initials = '';
                $name = get_the_title( $post_id );
                if ( $name ) {
                    $parts = preg_split( '/\s+/', trim( $name ) );
                    $initials = strtoupper( ( $parts[0][0] ?? '' ) . ( $parts[1][0] ?? '' ) );
                    $initials = preg_replace( '/[^A-Z0-9]/', '', $initials ); // keep safe
                    $initials = substr( $initials, 0, 2 );
                }
                $avatar_html = '<div class="hiregen-testimonial-initials" style="width:96px;height:96px;border-radius:8px;background:#f1f5f9;color:#374151;display:flex;align-items:center;justify-content:center;font-weight:600;">' . esc_html( $initials ) . '</div>';
            }
            ?>
          <div class="col">
            <article id="post-<?php echo (int) $post_id; ?>" <?php post_class( 'card shadow-sm' ); ?> style="background:transparent;">
              <div class="card-body p-4">
                <div class="d-flex align-items-start" style="gap:1rem;">
                  <!-- left: content -->
                  <div class="flex-grow-1" style="min-width:0;">
                    <!-- stars -->
                    <?php
                    // hiregen_render_stars returns HTML; sanitize with wp_kses to allow only specific tags/attributes
                    echo wp_kses(
                        hiregen_render_stars( $rating ),
                        array(
                            'div'  => array( 'class' => true, 'aria-hidden' => true, 'style' => true ),
                            'span' => array( 'class' => true, 'aria-hidden' => true, 'style' => true ),
                        )
                    );
                    ?>

                    <!-- quote -->
                    <blockquote class="mb-3" style="margin:0;font-style:normal;color:#374151;">
                      <p>“<?php
                        // apply the_content filters so shortcodes are processed, then trim and sanitize
                        $raw_content = apply_filters( 'the_content', get_post_field( 'post_content', $post_id ) );
                        // strip tags to keep a short safe excerpt
                        echo esc_html( wp_trim_words( wp_strip_all_tags( $raw_content ), 40 ) );
                      ?>”</p>
                    </blockquote>

                    <!-- name & designation -->
                    <div class="mt-4">
                      <h5 class="mb-2"><?php echo esc_html( get_the_title( $post_id ) ); ?></h5>
                      <?php if ( ! empty( $designation ) ) : ?>
                        <p class="mb-0"><?php echo esc_html( $designation ); ?></p>
                      <?php endif; ?>
                    </div>
                  </div>

                  <!-- right: avatar -->
                  <div class="ms-3 testimonial-avatar" style="flex:0 0 96px;">
                    <?php
                    // avatar_html contains HTML; use wp_kses_post to allow safe img/div markup
                    echo wp_kses(
                        $avatar_html,
                        array(
                            'img' => array( 'src' => true, 'alt' => true, 'class' => true, 'style' => true, 'loading' => true ),
                            'div' => array( 'class' => true, 'style' => true ),
                        )
                    );
                    ?>
                  </div>
                </div>
              </div>
            </article>
          </div>
        <?php endwhile; ?>

        <?php
        // restore original post data
        wp_reset_postdata();
        ?>
      </div>

      <div class="mt-5 d-flex justify-content-center" role="navigation" aria-label="<?php echo esc_attr__( 'Testimonials pagination', 'hiregen-recruitment' ); ?>">
        <?php
        // Use paginate_links safely and escape output
        $paginate = paginate_links( array(
          'total'        => (int) $q->max_num_pages,
          'current'      => (int) $paged,
          'prev_text'    => esc_html__( '← Prev', 'hiregen-recruitment' ),
          'next_text'    => esc_html__( 'Next →', 'hiregen-recruitment' ),
          'type'         => 'array',
        ) );

        if ( is_array( $paginate ) && ! empty( $paginate ) ) {
            echo '<ul class="pagination">';
            foreach ( $paginate as $link ) {
                // $link contains anchor HTML - sanitize allowed tags
                echo '<li class="page-item">' . wp_kses( $link, array( 'a' => array( 'href' => true, 'class' => true ), 'span' => array( 'class' => true ) ) ) . '</li>';
            }
            echo '</ul>';
        } elseif ( is_string( $paginate ) ) {
            // fallback: string output
            echo wp_kses( $paginate, array( 'a' => array( 'href' => true ), 'span' => array( 'class' => true ) ) );
        }
        ?>
      </div>

    <?php else : ?>
      <div class="no-results py-5 text-center" role="status" aria-live="polite">
        <h2><?php esc_html_e( 'No testimonials found or query failed to return posts.', 'hiregen-recruitment' ); ?></h2>
        <p class="text-muted"><?php esc_html_e( 'Check WP Admin → Testimonials and ensure posts are published.', 'hiregen-recruitment' ); ?></p>
      </div>
    <?php endif; ?>

  </div>
</main>

<?php
get_footer();
