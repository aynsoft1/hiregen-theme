<?php
/**
 * Archive template for FAQ CPT
 * Place this file in your theme / child theme root as:
 *   wp-content/themes/your-theme/archive-hiregen_faq.php
 *
 * Uses Bootstrap 5 accordion markup for FAQs.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header();
?>
<?php
// Sub Header Section
?>
<div class="sub-header py-4">
  <div class="container">
    <?php
    // 1) Try a list of common customizer keys used by FAQ section files
    $possible_keys = array(
        'hiregen_faq_title',
        'hiregen_faqs_title',
        'hiregen_faq_section_title',
        'hiregen_faqs_section_title',
        'hiregen_faqs_heading',
        'hiregen_faq_heading',
        'hiregen_faqs_title_home',
        'hiregen_faq_title_home'
    );

    $section_title = '';

    foreach ( $possible_keys as $k ) {
        $val = get_theme_mod( $k, '' );
        if ( ! empty( $val ) ) {
            $section_title = $val;
            break;
        }
    }

    // 2) If your theme stores section settings in an array option (common pattern),
    // check a few likely containers for 'faq' / 'faqs' keys and 'title' index.
    if ( empty( $section_title ) ) {
        $sections = get_theme_mod( 'hiregen_sections', get_theme_mod( 'hiregen_section_settings', array() ) );

        if ( is_array( $sections ) && ! empty( $sections ) ) {
            $candidates = array( 'faq', 'faqs', 'faq_section', 'section_faqs', 'section-faqs' );
            foreach ( $candidates as $c ) {
                // keyed array containing title
                if ( isset( $sections[ $c ] ) ) {
                    if ( is_array( $sections[ $c ] ) && ! empty( $sections[ $c ]['title'] ) ) {
                        $section_title = $sections[ $c ]['title'];
                        break;
                    }
                    // sometimes sections store plain title
                    if ( is_string( $sections[ $c ] ) && $sections[ $c ] !== '' ) {
                        $section_title = $sections[ $c ];
                        break;
                    }
                }
                // sometimes stored with numeric index objects => scan inner arrays
                foreach ( $sections as $entry ) {
                    if ( is_array( $entry ) && ! empty( $entry['id'] ) && false !== stripos( $entry['id'], 'faq' ) ) {
                        if ( ! empty( $entry['title'] ) ) {
                            $section_title = $entry['title'];
                            break 2;
                        }
                    }
                }
            }
        }
    }

    // 3) Final fallback: default archive title
    if ( empty( $section_title ) ) {
        $section_title = post_type_archive_title( '', false ); // returns string
    }

    // Output - allow limited HTML from customizer title; breadcrumb should be safe text
    ?>
    <h1 class="entry-title fw-bold"><?php echo wp_kses_post( $section_title ); ?></h1>

    <div class="breadcrumb mb-0" aria-label="<?php echo esc_attr__( 'Breadcrumb', 'hiregen-recruitment' ); ?>">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color:inherit;"><?php esc_html_e( 'Home', 'hiregen-recruitment' ); ?></a>
        &nbsp;→&nbsp;
        <?php echo esc_html( wp_strip_all_tags( $section_title ) ); ?>
    </div>
  </div>
</div>


<main id="main" class="site-main py-4" role="main">
  <div class="container">

    <?php if ( have_posts() ) : ?>
      <header class="archive-header mb-4">
        <?php
        // Display post type description if set in register_post_type
        $post_type = get_post_type_object( 'hiregen_faq' );
        if ( $post_type && ! empty( $post_type->description ) ) : ?>
          <div class="archive-description text-muted">
            <?php echo wp_kses_post( wpautop( $post_type->description ) ); ?>
          </div>
        <?php endif; ?>
      </header>

      <div class="accordion" id="faqAccordion">
        <?php
        $i = 0;
        while ( have_posts() ) : the_post();
          $i++;
          // build safe, unique IDs
          $heading_id  = 'faqHeading' . (int) $i;
          $collapse_id = 'faqCollapse' . (int) $i;

          // Title and content - escape appropriately.
          $faq_title   = get_the_title();
          // Use the_content filters so shortcodes and embeds behave as expected,
          // then sanitize output to allowed HTML (wp_kses_post).
          $raw_content = apply_filters( 'the_content', get_the_content() );
        ?>
          <div class="accordion-item mb-3 border rounded shadow-sm">
            <h2 class="accordion-header" id="<?php echo esc_attr( $heading_id ); ?>">
              <button
                class="accordion-button rounded lead p-4 collapsed"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#<?php echo esc_attr( $collapse_id ); ?>"
                aria-expanded="false"
                aria-controls="<?php echo esc_attr( $collapse_id ); ?>"
              >
                <?php echo esc_html( $faq_title ); ?>
              </button>
            </h2>

            <div id="<?php echo esc_attr( $collapse_id ); ?>"
                 class="accordion-collapse collapse"
                 aria-labelledby="<?php echo esc_attr( $heading_id ); ?>"
                 data-bs-parent="#faqAccordion"
            >
              <div class="accordion-body">
                <?php echo wp_kses_post( $raw_content ); ?>
              </div>
            </div>
          </div>
        <?php endwhile; ?>

        <?php
        // restore global post data just in case
        wp_reset_postdata();
        ?>
      </div><!-- .accordion -->

      <div class="mt-5 d-flex justify-content-center">
        <?php
        the_posts_pagination( array(
          'mid_size'           => 2,
          'prev_text'          => esc_html__( '← Prev', 'hiregen-recruitment' ),
          'next_text'          => esc_html__( 'Next →', 'hiregen-recruitment' ),
          'screen_reader_text' => esc_html__( 'FAQ navigation', 'hiregen-recruitment' ),
        ) );
        ?>
      </div>

    <?php else : ?>

      <div class="no-results py-5 text-center">
        <h2><?php esc_html_e( 'No FAQs found', 'hiregen-recruitment' ); ?></h2>
        <p class="text-muted"><?php esc_html_e( 'There are no FAQs to display yet. Please check back later.', 'hiregen-recruitment' ); ?></p>
      </div>

    <?php endif; ?>
  </div><!-- .container -->
</main>

<?php
get_footer();
