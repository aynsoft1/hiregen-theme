<?php
/**
 * Template Name: Blog Listing (custom Page template)
 * Place in theme root and assign to a Page called "Blog".
 *
 * Hardened for escaping, safe queries and accessibility.
 *
 * @package Hiregen
 */

defined( 'ABSPATH' ) || exit;
get_header();
?>

<main id="main" class="site-main py-4" role="main" aria-label="<?php echo esc_attr__( 'Blog', 'hiregen-recruitment' ); ?>">
  <div class="container">

<?php
// Use customizer values for blog page title/subtitle if available
$blog_page_title    = get_theme_mod( 'hiregen_blog_title', '' );
$blog_page_subtitle = get_theme_mod( 'hiregen_blog_subtitle', '' );
$blog_page_desc     = get_theme_mod( 'hiregen_blog_description', '' );

// If no custom title, try the page title (the page using this template).
if ( '' === $blog_page_title ) {
	// get_queried_object() will be the page if this template is assigned to a Page.
	$page_obj = get_queried_object();
	if ( $page_obj && ! empty( $page_obj->post_title ) ) {
		$blog_page_title = $page_obj->post_title;
	} else {
		$blog_page_title = __( 'Our Blog', 'hiregen-recruitment' );
	}
}

if ( '' === $blog_page_subtitle ) {
	$blog_page_subtitle = ''; // intentionally empty by default
}

if ( '' === $blog_page_desc ) {
	$blog_page_desc = __( 'Our blog serves as a valuable resource for both job seekers and employers, offering', 'hiregen-recruitment' );
}
?>

<header class="mb-4 text-center">
	<?php if ( $blog_page_title ) : ?>
		<h1 class="entry-title fw-bold"><?php echo esc_html( $blog_page_title ); ?></h1>
	<?php endif; ?>

	<?php
	// If the page using this template has content, show it (sanitized).
	$page_obj = get_queried_object();
	$page_content = '';
	if ( $page_obj && ! empty( $page_obj->post_content ) ) {
		$page_content = apply_filters( 'the_content', $page_obj->post_content );
	}

	if ( $page_content ) : ?>
		<div class="text-muted mx-auto" style="max-width:900px;"><?php echo wp_kses_post( $page_content ); ?></div>
	<?php elseif ( $blog_page_desc ) : ?>
		<div class="text-muted mx-auto" style="max-width:900px;"><?php echo wp_kses_post( wpautop( $blog_page_desc ) ); ?></div>
	<?php endif; ?>
</header>

<?php
// Standard posts query with pagination support.
// Use a local variable for the query to avoid clobbering globals.
$paged = max( 1, get_query_var( 'paged', 1 ) );
$args  = array(
	'post_type'      => 'post',
	'posts_per_page' => (int) get_option( 'posts_per_page', 10 ),
	'paged'          => $paged,
);

$blog_query = new WP_Query( $args );

if ( $blog_query->have_posts() ) : ?>
	<div class="row g-4" aria-live="polite">
		<?php
		while ( $blog_query->have_posts() ) :
			$blog_query->the_post();

			$post_id = get_the_ID();
			$permalink = get_permalink( $post_id );
			$title     = get_the_title( $post_id );
			if ( '' === $title ) {
				/* translators: %s: post ID */
				$title = sprintf( esc_html__( 'Post #%s', 'hiregen-recruitment' ), $post_id );
			}
			?>
			<div class="col-12 col-md-6 col-lg-4">
				<article id="post-<?php echo esc_attr( $post_id ); ?>" <?php post_class( 'card h-100 p-3 shadow-sm' ); ?>>
					<?php if ( has_post_thumbnail( $post_id ) ) : ?>
						<a href="<?php echo esc_url( $permalink ); ?>" class="d-block" aria-labelledby="post-title-<?php echo esc_attr( $post_id ); ?>">
							<div class="img-fluid card-img rounded overflow-hidden" style="height:190px;">
								<?php
								// let WordPress output the image tag; attributes passed are safe strings.
								the_post_thumbnail(
									'large',
									array(
										'class' => 'img-fluid w-100 h-100',
										'style' => 'object-fit:cover; display:block;',
										'alt'   => esc_attr( get_the_title( $post_id ) ),
									)
								);
								?>
							</div>
						</a>
					<?php endif; ?>

					<div class="card-body d-flex flex-column">
						<h5 id="post-title-<?php echo esc_attr( $post_id ); ?>" class="mb-2">
							<a href="<?php echo esc_url( $permalink ); ?>" class="stretched-link"><?php echo esc_html( $title ); ?></a>
						</h5>

						<div class="card-text text-muted mb-3">
							<?php
							$excerpt = get_the_excerpt() ?: wp_trim_words( wp_strip_all_tags( get_the_content( null, false, $post_id ) ), 28, '...' );
							echo wp_kses_post( wpautop( $excerpt ) );
							?>
						</div>

						<div class="mt-auto">
							<a href="<?php echo esc_url( $permalink ); ?>" class="btn btn-sm btn-outline-secondary"><?php echo esc_html__( 'Read More', 'hiregen-recruitment' ); ?></a>
						</div>
					</div>
				</article>
			</div>
		<?php endwhile; ?>
	</div>

	<div class="mt-5 d-flex justify-content-center" role="navigation" aria-label="<?php echo esc_attr__( 'Posts navigation', 'hiregen-recruitment' ); ?>">
		<?php
		$paginate_args = array(
			'total'     => (int) $blog_query->max_num_pages,
			'current'   => (int) $paged,
			'prev_text' => wp_kses_post( __( '← Prev', 'hiregen-recruitment' ) ),
			'next_text' => wp_kses_post( __( 'Next →', 'hiregen-recruitment' ) ),
		);

		// paginate_links returns safe HTML; still pass through wp_kses_post.
		echo wp_kses_post( paginate_links( $paginate_args ) );
		?>
	</div>

<?php else : ?>
	<div class="no-results py-5 text-center">
		<h2><?php echo esc_html__( 'No posts found', 'hiregen-recruitment' ); ?></h2>
	</div>
<?php
endif;

// Reset postdata and clean up.
wp_reset_postdata();
?>

  </div>
</main>

<?php
get_footer();
