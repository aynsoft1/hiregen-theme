( function( $ ) {
    'use strict';

    $( function() {
        var controlId = '#customize-control-hiregen_section_order';
        var control = $( controlId );

        if ( ! control.length ) {
            return;
        }

        var list = control.find( '.hiregen-sortable-list' );
        var input = control.find( 'input[type="hidden"]' );

        // Initialize sortable
        list.sortable({
            axis: 'y',
            handle: '.hiregen-drag-handle',
            placeholder: 'hiregen-sortable-placeholder',
            update: function() {
                // read order
                var order = [];
                list.find('li').each(function(){
                    order.push( $(this).data('id') );
                });
                input.val( order.join(',') );
                // trigger change so Customizer knows the value changed
                input.trigger('change');
            }
        });

        // make items focusable (a11y)
        list.find('li').attr('tabindex', 0);
    });

} )( jQuery );
