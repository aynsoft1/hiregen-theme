<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Template tags & helpers for Hiregen Recruitment
 *
 * These helpers try to be defensive about input and return values that are
 * safe to echo in templates. If you need raw/unescaped values (e.g. for logic),
 * call the underlying WP functions directly (get_theme_mod(), get_post_meta(), etc.).
 *
 * NOTE: Functions return escaped strings / safe HTML by default so templates can
 * echo them without additional escaping in most cases. If you need a raw value,
 * use the underlying API instead.
 */

/**
 * Safe wrapper for get_theme_mod with fallback.
 *
 * Returns an escaped string (wp_kses_post) when the theme mod is scalar.
 *
 * @param string $id      Theme mod id.
 * @param mixed  $default Default to return if the theme mod is empty.
 * @return mixed Escaped theme mod value or the $default.
 */
if ( ! function_exists( 'hiregen_get_theme_mod' ) ) {
	function hiregen_get_theme_mod( $id, $default = '' ) {
		$val = get_theme_mod( $id );

		// If nothing set, return default (no escaping necessary for default here).
		if ( null === $val || '' === $val ) {
			return $default;
		}

		// If scalar, sanitize and allow safe HTML. If array/object, return raw value (caller should sanitize).
		if ( is_scalar( $val ) ) {
			// Allow limited safe HTML (useful for e.g. small markup); strip dangerous tags.
			return wp_kses_post( (string) $val );
		}

		// Non-scalar values may be used by advanced customizations; return as-is (caller responsible for sanitization).
		return $val;
	}
}

/**
 * Check whether a homepage section is enabled in the Customizer.
 *
 * Usage: hiregen_section_is_visible( 'services' ) checks hiregen_show_section_services.
 *
 * @param string $key Section key (suffix used for theme_mod).
 * @return bool True if visible; false otherwise.
 */
if ( ! function_exists( 'hiregen_section_is_visible' ) ) {
	function hiregen_section_is_visible( $key ) {
		$key_safe = sanitize_key( (string) $key );
		$id       = 'hiregen_show_section_' . $key_safe;

		// default true so sections show by default unless user toggles off
		$raw = get_theme_mod( $id, true );

		// Use filter_var with FILTER_VALIDATE_BOOLEAN to accept many truthy/falsy values
		return filter_var( $raw, FILTER_VALIDATE_BOOLEAN );
	}
}

/**
 * Generates a small block of CSS based on customizer color settings.
 *
 * Returns a safe CSS string. Colors are validated via sanitize_hex_color() and
 * fall back to sensible defaults if invalid.
 *
 * You can echo the returned string into a <style> block, or pass it to
 * wp_add_inline_style( 'your-handle', hiregen_customizer_generated_css() ).
 *
 * @return string Valid, sanitized CSS string.
 */
if ( ! function_exists( 'hiregen_customizer_generated_css' ) ) {
	function hiregen_customizer_generated_css() {
		// Defaults (safe hex colors)
		$defaults = array(
			'primary'   => '#0d6efd',
			'secondary' => '#6c757d',
			'heading'   => '#222222',
			'text'      => '#666666',
			'link'      => '#0d6efd',
		);

		// Retrieve and sanitize hex colors — sanitize_hex_color() returns null on invalid input.
		$primary   = sanitize_hex_color( get_theme_mod( 'hiregen_color_primary', $defaults['primary'] ) ) ?: $defaults['primary'];
		$secondary = sanitize_hex_color( get_theme_mod( 'hiregen_color_secondary', $defaults['secondary'] ) ) ?: $defaults['secondary'];
		$heading   = sanitize_hex_color( get_theme_mod( 'hiregen_heading_color', $defaults['heading'] ) ) ?: $defaults['heading'];
		$text      = sanitize_hex_color( get_theme_mod( 'hiregen_text_color', $defaults['text'] ) ) ?: $defaults['text'];
		$link      = sanitize_hex_color( get_theme_mod( 'hiregen_color_link', $defaults['link'] ) ) ?: $defaults['link'];

		// Build CSS. Values are already safe hex colors.
		$css = "
:root {
  --hiregen-primary: {$primary};
  --hiregen-secondary: {$secondary};
  --hiregen-heading: {$heading};
  --hiregen-text: {$text};
  --hiregen-link: {$link};
}
.btn-primary { background-color: var(--hiregen-primary); border-color: var(--hiregen-primary); }
.btn-secondary { background-color: var(--hiregen-secondary); border-color: var(--hiregen-secondary); }
h1,h2,h3,h4,h5,h6 { color: var(--hiregen-heading); }
body { color: var(--hiregen-text); }
a, a:visited { color: var(--hiregen-link); }
a:hover, a:focus { color: var(--hiregen-primary); }
";

		// Return trimmed CSS string.
		return trim( $css );
	}
}

/**
 * Helper to output images with alt attribute consistently.
 *
 * Returns safe HTML for an <img> element produced by wp_get_attachment_image().
 * The returned string is safe to echo directly in templates.
 *
 * @param int    $attachment_id Attachment ID.
 * @param string $size          Image size (e.g. 'thumbnail', 'full', or array).
 * @param string $alt           Optional alt text override. If empty, uses attachment alt meta.
 * @return string Safe <img> HTML or empty string on failure.
 */
if ( ! function_exists( 'hiregen_get_img_tag' ) ) {
	function hiregen_get_img_tag( $attachment_id = 0, $size = 'full', $alt = '' ) {
		$attachment_id = absint( $attachment_id );
		if ( 0 === $attachment_id ) {
			return '';
		}

		// If an explicit alt is given, sanitize it. Otherwise use the attachment alt meta (sanitized by WP core).
		$alt = $alt ? wp_strip_all_tags( (string) $alt ) : get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );

		// wp_get_attachment_image will escape attributes properly. Pass sanitized alt via attr array.
		$attr = array();
		if ( '' !== $alt ) {
			$attr['alt'] = esc_attr( $alt );
		}

		// Return the HTML (already escaped by WP core functions).
		$img_html = wp_get_attachment_image( $attachment_id, $size, false, $attr );

		// Ensure string return type.
		return is_string( $img_html ) ? $img_html : '';
	}
}
