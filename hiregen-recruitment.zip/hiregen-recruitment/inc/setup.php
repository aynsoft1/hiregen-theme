<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'hiregen_setup' ) ) {
    /**
     * Sets up theme defaults and registers support for various WordPress features.
     */
    function hiregen_setup() {
        /*
         * Make theme available for translation.
         * Translations can be filed in the /languages/ directory.
         */
        load_theme_textdomain( 'hiregen-recruitment', get_template_directory() . '/languages' );

        /*
         * Let WordPress manage the document title.
         */
        add_theme_support( 'title-tag' );

        /*
         * Add default posts and comments RSS feed links to head.
         * REQUIRED by Theme Check.
         */
        add_theme_support( 'automatic-feed-links' );

        /*
         * Enable support for Post Thumbnails on posts and pages.
         */
        add_theme_support( 'post-thumbnails' );

        /*
         * Custom logo support.
         */
        add_theme_support(
            'custom-logo',
            array(
                'height'      => 50,
                'width'       => 200,
                'flex-width'  => true,
                'flex-height' => true,
            )
        );

        /*
         * HTML5 markup support.
         */
        add_theme_support(
            'html5',
            array(
                'search-form',
                'comment-form',
                'comment-list',
                'gallery',
                'caption',
            )
        );

        /*
         * Responsive embeds for oEmbed and other media.
         */
        add_theme_support( 'responsive-embeds' );

        /*
         * Align wide for Gutenberg blocks.
         */
        add_theme_support( 'align-wide' );

        /*
         * Add support for core block visual styles.
         */
        add_theme_support( 'wp-block-styles' );

        /*
         * Allow editor styles and register the editor stylesheet (create the file if not present).
         */
        add_theme_support( 'editor-styles' );
        add_editor_style( 'assets/css/hiregen-editor-style.css' );

        /*
         * Custom header and background support.
         * These can also be registered here instead of outside the setup function.
         */
        add_theme_support(
            'custom-header',
            array(
                'width'       => 1600,
                'height'      => 400,
                'flex-height' => true,
            )
        );

        add_theme_support(
            'custom-background',
            array(
                'default-color' => 'ffffff',
            )
        );

        /*
         * Editor font sizes.
         */
        add_theme_support(
            'editor-font-sizes',
            array(
                array(
                    'name' => __( 'Small', 'hiregen-recruitment' ),
                    'size' => 12,
                    'slug' => 'small',
                ),
                array(
                    'name' => __( 'Normal', 'hiregen-recruitment' ),
                    'size' => 16,
                    'slug' => 'normal',
                ),
            )
        );

        /*
         * Improve Customizer experience: selective refresh for widgets.
         */
        add_theme_support( 'customize-selective-refresh-widgets' );

        /*
         * Register navigation menus.
         */
        register_nav_menus(
            array(
                'primary' => __( 'Primary Menu', 'hiregen-recruitment' ),
            )
        );

        /*
         * You may add additional theme supports here (starter content, image sizes, etc).
         */
    } // end hiregen_setup()

    add_action( 'after_setup_theme', 'hiregen_setup' );
}
