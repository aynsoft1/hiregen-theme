
<?php
/**
 * Front Page Template
 *
 * Render homepage sections in the order saved via Customizer (hiregen_section_order)
 * and check show/hide toggles using hiregen_section_is_visible().
 * Fallback: if all sections are hidden, display static page content instead.
 *
 * @package Hiregen
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header();
?>

<main id="content" class="site-main" role="main" aria-label="<?php echo esc_attr__( 'Homepage', 'hiregen-recruitment' ); ?>">

	<?php
	// Map section slug => template part suffix.
	$section_to_template = array(
		'hero'           => 'hero',
		'featured_logos' => 'featured-logos',
		'jobs'           => 'jobs',
		'our_products'   => 'our-products',

		'services'       => 'services',
		'why'            => 'why',
		'projects'       => 'projects',
		'testimonial'    => 'testimonial',
		'team'           => 'team',
		'faq'            => 'faqs',
		'blog'           => 'blog',
		'contact'        => 'contact',
	);

	$default_order = implode( ',', array_keys( $section_to_template ) );

	// Cast to string and trim to avoid unexpected types from theme mod.
	$order_raw = get_theme_mod( 'hiregen_section_order', $default_order );
	
	$order     = is_string( $order_raw ) ? $order_raw : $default_order;
	$slugs     = array_filter( array_map( 'trim', explode( ',', (string) $order ) ) );

	if ( empty( $slugs ) ) {
		$slugs = array_keys( $section_to_template );
	}

	$visible_sections = 0;

	foreach ( $slugs as $slug ) {
		// Skip unknown slugs.
		if ( ! isset( $section_to_template[ $slug ] ) ) {
			continue;
		}

		// Respect the section visibility callback if present.
		if ( function_exists( 'hiregen_section_is_visible' ) && ! hiregen_section_is_visible( $slug ) ) {
			continue;
		}

		$tpl = $section_to_template[ $slug ];

		// Use the standard template part pattern.
		get_template_part( 'template-parts/sections/section', $tpl );

		$visible_sections++;
	}

	// Fallback — if all sections are hidden, show static page content
	if ( 0 === $visible_sections ) :
		if ( have_posts() ) :
			while ( have_posts() ) :
				the_post();

				$post_id    = get_the_ID();
				$post_title = get_the_title( $post_id );
				$post_classes = get_post_class( '', $post_id );
				?>
				<article id="post-<?php echo esc_attr( $post_id ); ?>" <?php post_class( esc_attr( implode( ' ', (array) $post_classes ) ) ); ?>>
					<header class="mb-4">
						<?php if ( $post_title ) : ?>
							<h1 class="entry-title fw-bold"><?php echo esc_html( $post_title ); ?></h1>
						<?php endif; ?>
					</header>

					<div class="entry-content">
						<?php
						// Apply content filters and sanitize output for safe HTML.
						$content = apply_filters( 'the_content', get_the_content( null, false, $post_id ) );
						echo wp_kses_post( $content );
						?>
					</div>
				</article>
				<?php
			endwhile;

			// Clean up global post data.
			wp_reset_postdata();
		else :
			?>
			<div class="container py-5 text-center">
				<p><?php echo esc_html__( 'No content found.', 'hiregen-recruitment' ); ?></p>
			</div>
			<?php
		endif;
	endif;
	?>

</main>

<?php
/**
 * Popup modal injection:
 *
 * We inject a Bootstrap 5 modal here only if:
 *  - the popup is enabled via Customizer (hiregen_popup_enable)
 *  - AND there is no existing function 'hiregen_print_popup_modal' that already outputs modal (to avoid duplication).
 *
 * Note: if your theme/plugin already prints the modal via hiregen_print_popup_modal() (hooked to wp_footer),
 * this block will be skipped and the modal will be printed by that function instead.
 */
if ( ! is_admin() && get_theme_mod( 'hiregen_popup_enable', false ) ) :

	// Avoid duplicate if modal is already printed via hiregen_print_popup_modal()
	if ( ! function_exists( 'hiregen_print_popup_modal' ) ) :

		// Gather values from Customizer (sanitized)
		$hg_title = wp_kses_post( get_theme_mod( 'hiregen_popup_title', '' ) );
		$hg_desc  = wp_kses_post( get_theme_mod( 'hiregen_popup_desc', '' ) );
		$hg_btn   = esc_html( get_theme_mod( 'hiregen_popup_button_text', __( 'Subscribe', 'hiregen-recruitment' ) ) );
		?>

		<!-- Hiregen Popup Modal (printed in front-page.php) -->
		<div class="modal fade" id="hiregen-popup-modal" tabindex="-1" aria-labelledby="myModalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
		  <div class="modal-dialog modal-dialog-centered">
			<div class="modal-content">
			  <div class="modal-header">
				<h5 class="modal-title" id="hiregenPopupLabel"><?php echo $hg_title; ?></h5>
				<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="<?php esc_attr_e( 'Close', 'hiregen-recruitment' ); ?>"></button>
			  </div>
			  <div class="modal-body">
				<div class="hiregen-popup-desc"><?php echo $hg_desc; ?></div>
				<form class="hiregen-popup-form mt-3" novalidate>
				  <div class="mb-3">
					<label for="hg_name" class="form-label"><?php esc_html_e( 'Name', 'hiregen-recruitment' ); ?> <span class="text-danger">*</span></label>
					<input type="text" class="form-control" id="hg_name" name="name" required />
				  </div>
				  <div class="mb-3">
					<label for="hg_email" class="form-label"><?php esc_html_e( 'Email', 'hiregen-recruitment' ); ?> <span class="text-danger">*</span></label>
					<input type="email" class="form-control" id="hg_email" name="email" required />
				  </div>
				  <!-- Description field -->
				  <div class="mb-3">
					<label for="hg_description" class="form-label"><?php esc_html_e( 'Description', 'hiregen-recruitment' ); ?> <span class="text-danger">*</span></label>
					<textarea class="form-control" id="hg_description" name="description" rows="4" required></textarea>
				  </div>

				  <div id="hiregen-popup-feedback" role="status" aria-live="polite" class="mb-2"></div>
				  <div class="d-flex justify-content-end">
					<button type="submit" class="btn btn-primary" id="hiregen-popup-submit"><?php echo $hg_btn; ?></button>
				  </div>
				</form>
			  </div>
			</div>
		  </div>
		</div>

		<?php
	endif; // ! function_exists( 'hiregen_print_popup_modal' )

endif;
?>

<?php
get_footer();
