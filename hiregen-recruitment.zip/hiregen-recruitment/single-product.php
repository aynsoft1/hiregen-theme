<?php
/**
 * The template for displaying single product pages (WooCommerce)
 *
 * This template includes the standard WooCommerce hooks and a safe loop.
 *
 * @package Hiregen
 */

defined( 'ABSPATH' ) || exit;

get_header( 'shop' );
?>

<div class="container py-5"> <!-- theme container -->
	<div class="row">
		<div class="col-12" role="main" aria-label="<?php echo esc_attr( __( 'Product', 'hiregen-recruitment' ) ); ?>">
			<?php
			/**
			 * Hook: woocommerce_before_main_content.
			 *
			 * @hooked woocommerce_output_content_wrapper - 10 (outputs opening divs for the content)
			 * @hooked woocommerce_breadcrumb - 20
			 */
			do_action( 'woocommerce_before_main_content' );

			// Standard loop — WC templates expect the global post data to be set.
			while ( have_posts() ) :
				the_post();

				// Load the WooCommerce content-single-product template part.
				wc_get_template_part( 'content', 'single-product' );

			endwhile;

			// Reset global post data after the loop to avoid side-effects.
			wp_reset_postdata();

			/**
			 * Hook: woocommerce_after_main_content.
			 *
			 * @hooked woocommerce_output_content_wrapper_end - 10 (outputs closing divs for the content)
			 */
			do_action( 'woocommerce_after_main_content' );
			?>
		</div>
	</div>
</div>

<?php
get_footer( 'shop' );
