<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Theme bootstrap / includes
 * Keep only one customizer file active to avoid duplicate registrations.
 */

define( 'HIREGEN_THEME_DIR', get_template_directory() );
define( 'HIREGEN_THEME_URI', get_template_directory_uri() );

/* Load core setup and helpers */
require_once HIREGEN_THEME_DIR . '/inc/setup.php';

/* Template tags (helpers & CSS generator) must be loaded BEFORE enqueue so inline CSS is available */
require_once HIREGEN_THEME_DIR . '/inc/template-tags.php';

/* Enqueue scripts/styles (uses hiregen_customizer_generated_css) */
require_once HIREGEN_THEME_DIR . '/inc/enqueue.php';

/* Load widgets */
require_once HIREGEN_THEME_DIR . '/inc/widgets.php';
require_once HIREGEN_THEME_DIR . '/inc/admin-notices.php';
require_once HIREGEN_THEME_DIR . '/inc/optimization.php'; // WebP, PWA, SEO
require_once get_template_directory() . '/inc/block-patterns.php';
//require_once get_template_directory() . '/inc/schema-jobposting.php';

/*
 * Customizer: prefer the complete file if present. If you still want to keep
 * the older partial file for fallback, the code below will pick the complete
 * customizer first and fall back to the older customizer.php if needed.
 *
 * IMPORTANT: Do not include both customizer files at once.
 */
if ( file_exists( HIREGEN_THEME_DIR . '/inc/customizer-complete.php' ) ) {
    require_once HIREGEN_THEME_DIR . '/inc/customizer-complete.php';
} elseif ( file_exists( HIREGEN_THEME_DIR . '/inc/customizer.php' ) ) {
    // fallback for older installs — consider removing customizer.php once complete is stable
    require_once HIREGEN_THEME_DIR . '/inc/customizer.php';
}

/* Prints the Bootstrap 5 modal HTML into the footer when popup is enabled */
if ( ! function_exists( 'hiregen_print_popup_modal' ) ) :
function hiregen_print_popup_modal() {
    if ( is_admin() ) return;
    if ( ! is_front_page() && ! is_home() ) return;
    if ( ! get_theme_mod( 'hiregen_popup_enable', false ) ) return;

    $title = wp_kses_post( get_theme_mod( 'hiregen_popup_title', '' ) );
    $desc  = wp_kses_post( get_theme_mod( 'hiregen_popup_desc', '' ) );
    $btn   = esc_html( get_theme_mod( 'hiregen_popup_button_text', __( 'Subscribe', 'hiregen-recruitment' ) ) );
    ?>
<!-- Hiregen Popup Modal -->
<div class="modal fade" id="hiregen-popup-modal" tabindex="-1"
     aria-labelledby="hiregenModalTitle"
     aria-hidden="true" data-backdrop="static" data-keyboard="false"
     aria-modal="true" role="dialog">

  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">

      <div class="modal-header">
        <h5 class="modal-title" id="hiregenModalTitle">
          <?php echo $title; ?>
        </h5>

        <button type="button" class="btn-close" data-bs-dismiss="modal"
                aria-label="<?php esc_attr_e( 'Close', 'hiregen-recruitment' ); ?>"></button>
      </div>

      <div class="modal-body">
        <p><?php echo $desc; ?></p>
        <!--<form class="hiregen-popup-form" novalidate>
          <!-- Honeypot (hidden) -->
          <!--<input type="text" name="hp_name" value="" style="display:none!important"
                 autocomplete="off" tabindex="-1" />-->

          <!-- Name -->
          <!--<div class="mb-3">
            <label for="hiregen-name" class="form-label">
              <?php esc_html_e( 'Name', 'hiregen-recruitment' ); ?>
            </label>
            <input id="hiregen-name" name="name" type="text" class="form-control"
                   required aria-required="true" />
          </div>-->

          <!-- Email -->
          <!--<div class="mb-3">
            <label for="hiregen-email" class="form-label">
              <?php esc_html_e( 'Email', 'hiregen-recruitment' ); ?>
            </label>
            <input id="hiregen-email" name="email" type="email" class="form-control"
                   required aria-required="true" />
          </div>-->

          <!-- Description -->
          <!--<div class="mb-3">
            <label for="hiregen-description" class="form-label">
              <?php esc_html_e( 'Description', 'hiregen-recruitment' ); ?>
            </label>
            <textarea id="hiregen-description" name="description"
                      class="form-control" rows="4"
                      required aria-required="true"></textarea>
          </div>-->

          <!-- Submit -->
          <!--<div class="d-flex justify-content-end">
            <button type="submit" class="btn btn-primary w-100">
              <?php echo esc_html( $btn ); ?>
            </button>-->
            <a href="https://ejobsitesoftware.com/" class="btn btn-primary w-100">
              <?php echo esc_html( $btn ); ?>
            </a>
          </div>
        <!--</form>-->

      </div>

    </div>
  </div>
</div>


    <?php
}
add_action( 'wp_footer', 'hiregen_print_popup_modal', 20 );
endif;

/**
 * Hiregen Top Header — Customizer + Output (with Font Color & Border Bottom Color)
 * Paste after: require_once HIREGEN_THEME_DIR . '/inc/customizer.php';
 * Remove any previous Top Header code to avoid duplicates.
 */

/* ---------- Customizer: Top Header (attach to existing panel 'hiregen_panel_home') ---------- */
add_action( 'customize_register', 'hiregen_top_header_customizer_complete' );
function hiregen_top_header_customizer_complete( $wp_customize ) {
    $panel_id = 'hiregen_panel_home';

    // safe fallback: create panel if missing
    if ( ! $wp_customize->get_panel( $panel_id ) ) {
        $wp_customize->add_panel( $panel_id, array(
            'priority'   => 10,
            'capability' => 'edit_theme_options',
            'title'      => __( 'Hiregen Theme Options', 'hiregen-recruitment' ),
        ) );
    }

    // add section if not exists
    if ( ! $wp_customize->get_section( 'hiregen_top_header_section' ) ) {
        $wp_customize->add_section( 'hiregen_top_header_section', array(
            'title'    => __( 'Top Header', 'hiregen-recruitment' ),
            'priority' => 5,
            'panel'    => $panel_id,
        ) );
    }

    // setting: display
    $wp_customize->add_setting( 'hiregen_top_header_display', array(
        'default'           => false,
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'hiregen_sanitize_checkbox',
    ) );
    $wp_customize->add_control( 'hiregen_top_header_display', array(
        'label'   => __( 'Display Top Header', 'hiregen-recruitment' ),
        'section' => 'hiregen_top_header_section',
        'type'    => 'checkbox',
    ) );

    // setting: background color
    $wp_customize->add_setting( 'hiregen_top_header_bg', array(
        'default'           => '',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_hex_color',
    ) );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_top_header_bg', array(
        'label'    => __( 'Top Header Background Color', 'hiregen-recruitment' ),
        'section'  => 'hiregen_top_header_section',
        'settings' => 'hiregen_top_header_bg',
    ) ) );

    // setting: font (text) color
    $wp_customize->add_setting( 'hiregen_top_header_color', array(
        'default'           => '',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_hex_color',
    ) );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_top_header_color', array(
        'label'    => __( 'Top Header Font Color', 'hiregen-recruitment' ),
        'section'  => 'hiregen_top_header_section',
        'settings' => 'hiregen_top_header_color',
    ) ) );

    // setting: border bottom color
    $wp_customize->add_setting( 'hiregen_top_header_border', array(
        'default'           => '',
        'capability'        => 'edit_theme_options',
        'sanitize_callback' => 'sanitize_hex_color',
    ) );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_top_header_border', array(
        'label'    => __( 'Top Header Border Bottom Color', 'hiregen-recruitment' ),
        'section'  => 'hiregen_top_header_section',
        'settings' => 'hiregen_top_header_border',
    ) ) );
}

/* sanitize helper */
if ( ! function_exists( 'hiregen_sanitize_checkbox' ) ) {
    function hiregen_sanitize_checkbox( $checked ) {
        return ( ( isset( $checked ) && true == $checked ) ? true : false );
    }
}

/* ---------- Renderer: output top header (safe single declaration) ---------- */
if ( ! function_exists( 'hiregen_render_top_header' ) ) {
    function hiregen_render_top_header() {
        // debug log (optional)
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( 'hiregen_render_top_header() called' );
        }

        // only display if enabled
        $enabled = get_theme_mod( 'hiregen_top_header_display', false );
        if ( ! $enabled ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                error_log( 'hiregen_render_top_header() - disabled via customizer' );
            }
            return;
        }

        // color values
        $bg    = get_theme_mod( 'hiregen_top_header_bg', '' );
        $color = get_theme_mod( 'hiregen_top_header_color', '' );
        $bcol  = get_theme_mod( 'hiregen_top_header_border', '' );

        // compose inline style
        
// earlier in hiregen_render_top_header()
$styles = array();
if ( $bg )  $styles[] = 'background-color:' . esc_attr( $bg );
if ( $color ) $styles[] = '--hg-top-color:' . esc_attr( $color );
if ( $bcol ) $styles[] = 'border-bottom:1px solid ' . esc_attr( $bcol );
$style_attr = $styles ? ' style="' . implode( ';', $styles ) . ';"' : '';

        // reuse footer/contact settings
        $address = get_theme_mod( 'hiregen_footer_address', '' );
        $email   = get_theme_mod( 'hiregen_footer_email', '' );
        $phone   = get_theme_mod( 'hiregen_footer_phone', '' );

        // social keys used by footer
        $socials = array( 'facebook','twitter','linkedin','instagram','youtube' );

        // output marker
        echo '<!-- HIREGEN-TOP-HEADER -->';

        // render markup
        ?>
        <div class="hiregen-top-header" <?php echo $style_attr; ?>>
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-9 top-header-left">
                        <ul class="list-unstyled mb-0 d-flex flex-column flex-sm-row p-0">
                            <?php if ( $address ) : ?>
                                <li class="me-5 top-header-address">
                                    <span class="me2"><i class="bi bi-geo-alt-fill" aria-hidden="true"></i></span>
                                    <span><?php echo wp_kses_post( $address ); ?></span>
                                </li>
                            <?php endif; ?>

                            <?php if ( $email ) : ?>
                                <li class="me-5 top-header-email">
                                    <span class="me2"><i class="bi bi-envelope-fill" aria-hidden="true"></i></span>
                                    <a href="mailto:<?php echo esc_attr( $email ); ?>"><?php echo esc_html( $email ); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if ( $phone ) : ?>
                                <li class="top-header-phone">
                                    <span class="me2"><i class="bi bi-telephone-fill" aria-hidden="true"></i></span>
                                    <a href="tel:<?php echo esc_attr( preg_replace( '/[^0-9+]/', '', $phone ) ); ?>"><?php echo esc_html( $phone ); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>

                    <div class="col-md-3 text-md-end top-header-right">
                        <?php
                        $has_any_social = false;
                        foreach ( $socials as $s ) {
                            $url = get_theme_mod( 'hiregen_footer_social_' . $s );
                            if ( $url ) {
                                $has_any_social = true;
                                break;
                            }
                        }
                        if ( $has_any_social ) : ?>
                            <div class="hiregen-top-socials">
                            <?php foreach ( $socials as $s ) :
                                $url = get_theme_mod( 'hiregen_footer_social_' . $s );
                                if ( ! $url ) continue;
                                printf(
                                    '<a class="me-2" href="%1$s" target="_blank" rel="noopener noreferrer" aria-label="%2$s"><i class="bi bi-%3$s bi-top-header" aria-hidden="true"></i></a>',
                                    esc_url( $url ),
                                    esc_attr( ucfirst( $s ) ),
                                    esc_attr( $s )
                                );
                            endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
        // debug
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( 'hiregen_render_top_header() - output rendered' );
        }
    } // function
} // if function_exists

/* ---------- Hook renderer to wp_body_open (preferred) ---------- */
remove_action( 'wp_head', 'hiregen_render_top_header' ); // remove old fallback if present
add_action( 'wp_body_open', 'hiregen_render_top_header', 20 );



/* Load optional navwalker for Bootstrap menus (safe include) */
$navwalker_file = HIREGEN_THEME_DIR . '/inc/class-wp-bootstrap-navwalker.php';
if ( file_exists( $navwalker_file ) ) {
    require_once $navwalker_file;
}

/*
 * Note: CPTs for Services/Projects/Testimonial/Team/Logos should be registered
 * by the "hiregen-cpts" plugin (wp-content/plugins/hiregen-cpts/hiregen-cpts.php).
 * Make sure that plugin is installed & activated on the site where you test the theme.
 */

/**
 * Complete Customizer for Hiregen Recruitment
 * File: inc/customizer-complete.php
 *
 * Adds customizer panels/sections/settings for:
 * - Display toggles
 * - Header
 * - Hero
 * - Featured Logos
 * - Why
 * - Services, Projects, Testimonial, Team, Blog (common controls)
 * - Jobs & Contact (info)
 * - Footer
 * - Colors & Typography skeleton
 *
 * Includes sanitizers, selective refresh partials, and render callbacks.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/* ---------------------------
 * Sanitizer helpers
 * --------------------------- */
if ( ! function_exists( 'hiregen_sanitize_checkbox' ) ) {
    function hiregen_sanitize_checkbox( $checked ) {
        return ( ( isset( $checked ) && true == $checked ) ? true : false );
    }
}
if ( ! function_exists( 'hiregen_sanitize_text' ) ) {
    function hiregen_sanitize_text( $text ) {
        return sanitize_text_field( $text );
    }
}
if ( ! function_exists( 'hiregen_sanitize_url' ) ) {
    function hiregen_sanitize_url( $url ) {
        return esc_url_raw( $url );
    }
}
if ( ! function_exists( 'hiregen_sanitize_hex_color' ) ) {
    function hiregen_sanitize_hex_color( $color ) {
        return sanitize_hex_color( $color );
    }
}
if ( ! function_exists( 'hiregen_sanitize_html' ) ) {
    function hiregen_sanitize_html( $html ) {
        return wp_kses_post( $html );
    }
}

/**
 * Theme setup — register theme supports, image sizes, menus.
 * Add this to functions.php (or inc/theme-setup.php) and ensure it's hooked to after_setup_theme.
 */
if ( ! function_exists( 'hiregen_theme_setup' ) ) {

            // Load translations from wp-content/languages/themes first, then fall back to this theme's /languages
        $domain = 'hiregen-recruitment';

        // Current locale (filterable for themes)
        $locale = determine_locale();
        $locale = apply_filters( 'theme_locale', $locale, $domain );

        // 1) Try global languages dir: wp-content/languages/themes/hiregen-recruitment-LOCALE.mo
        $global_mo = trailingslashit( WP_LANG_DIR ) . 'themes/' . $domain . '-' . $locale . '.mo';
        load_textdomain( $domain, $global_mo );

        // 2) Fallback to the theme’s own /languages directory (expects .mo compiled from languages/hiregen-recruitment.pot)
        load_theme_textdomain( $domain, get_template_directory() . '/languages' );

    
    function hiregen_theme_setup() {

        // Let WP manage the document title (avoid hard-coded <title> in header.php)
        add_theme_support( 'title-tag' );

        // Enable automatic feed links in head
        add_theme_support( 'automatic-feed-links' );

        // Enable post thumbnails (featured images)
        add_theme_support( 'post-thumbnails' );
        // Register common image sizes used by the theme
        set_post_thumbnail_size( 150, 150, true ); // default thumb (cropped)
        add_image_size( 'hiregen-medium', 600, 400, true );
        add_image_size( 'hiregen-large', 1200, 800, false );

        // Support custom logo (WP Customizer)
        add_theme_support( 'custom-logo', array(
            'height'      => 80,
            'width'       => 250,
            'flex-height' => true,
            'flex-width'  => true,
            'header-text' => array( 'site-title', 'site-description' ),
        ) );

        // Support for HTML5 markup for forms, comments, galleries, captions, etc.
        add_theme_support( 'html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'script',
            'style',
        ) );

        // Add support for selective refresh for widgets in Customizer
        add_theme_support( 'customize-selective-refresh-widgets' );

        // Support wide/full alignment in Gutenberg
        add_theme_support( 'align-wide' );

        // Support editor styles and load theme editor stylesheet
        add_theme_support( 'editor-styles' );
        add_editor_style( 'assets/css/editor-style.css' ); // create this file if you want to style the editor

        // Make embeds responsive
        add_theme_support( 'responsive-embeds' );

        // Enable block styles
        add_theme_support( 'wp-block-styles' );

        // Support for block-based editor spacing, if you use it:
        // add_theme_support( 'editor-font-sizes', array(...) );
        // add_theme_support( 'editor-color-palette', array(...) );

        // Register nav menus (common requirement)
        register_nav_menus( array(
            'primary'   => __( 'Primary Menu', 'hiregen-recruitment' ),
            'footer'    => __( 'Footer Menu', 'hiregen-recruitment' ),
        ) );
    }
}
add_action( 'after_setup_theme', 'hiregen_theme_setup' );

// Fallback SEO outputs (only if no SEO plugin)
function hiregen_fallback_seo_head() {
    if ( defined('WPSEO_VERSION') || function_exists('yoast_breadcrumb') ) {
        return;
    }
    // You can reuse the header meta code or call a template part:
    get_template_part( 'template-parts/seo/fallback-head' );
}
add_action( 'wp_head', 'hiregen_fallback_seo_head', 1 );


/* ---------------------------
 * Selective refresh render callbacks
 * --------------------------- */
function hiregen_partial_render_header_logo() {
    if ( function_exists( 'the_custom_logo' ) && has_custom_logo() ) {
        the_custom_logo();
        return;
    }

    $logo = get_theme_mod( 'hiregen_header_logo' );
    if ( $logo ) {
        $logo_size = absint( get_theme_mod( 'hiregen_header_logo_size', 180 ) );

        // Try to resolve URL to an attachment ID so WP can output proper srcset/width/height
        $attachment_id = attachment_url_to_postid( $logo );

        if ( $attachment_id ) {
            // If available, let WP output the responsive <img> with sizes/srcset
            echo wp_get_attachment_image(
                $attachment_id,
                array( $logo_size, 0 ),
                false,
                array(
                    'alt'   => get_bloginfo( 'name' ) ? esc_attr( get_bloginfo( 'name' ) ) : '',
                    'style' => 'max-width:' . esc_attr( $logo_size ) . 'px;height:auto;display:block;',
                )
            );
        } else {
            // Fallback: external URL or non-attachment image — provide width attribute and sanitize everything
            echo '<img src="' . esc_url( $logo ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" width="' . esc_attr( $logo_size ) . '" style="height:auto;max-width:100%;display:block;">';
        }
    } else {
        echo '<span>' . esc_html( get_bloginfo( 'name' ) ) . '</span>';
    }
}

function hiregen_partial_render_hero_title() {
    echo wp_kses_post( get_theme_mod( 'hiregen_hero_title', '<strong>Hire the best</strong> for your team' ) );
}

function hiregen_partial_render_hero_subtitle() {
    echo esc_html( get_theme_mod( 'hiregen_hero_subtitle', 'Find your next hire' ) );
}

function hiregen_partial_render_footer_about() {
    echo wp_kses_post( get_theme_mod( 'hiregen_footer_about', '' ) );
}

function hiregen_partial_render_footer_logo() {
    $logo = get_theme_mod( 'hiregen_footer_logo' );
    if ( $logo ) {
        $footer_logo_size = absint( get_theme_mod( 'hiregen_footer_logo_size', 160 ) );
        echo '<img src="' . esc_url( $logo ) . '" alt="' . esc_attr( get_bloginfo( 'name' ) ) . '" style="max-width:' . $footer_logo_size . 'px; height:auto; display:block;">';
    } else {
        echo '<span>' . esc_html( get_bloginfo( 'name' ) ) . '</span>';
    }
}
// Then add a selective_refresh partial (similar to your header one) where you register partials:
if ( isset( $wp_customize->selective_refresh ) ) {
    $wp_customize->selective_refresh->add_partial( 'hiregen_footer_logo', array(
        'selector'        => '.site-footer .footer-logo', // adapt the selector used in your footer markup
        'render_callback' => 'hiregen_partial_render_footer_logo',
        'fallback_refresh'=> true,
    ) );
}
/**
 * Output customizer CSS for badge color
 */
function hiregen_customizer_badge_css() {
    $badge = get_theme_mod( 'hiregen_badge_color', '#ff7c01' );
    if ( empty( $badge ) ) {
        return;
    }
    // Ensure valid value is printed safely
    $badge = esc_attr( $badge );
    echo "<style id='hiregen-badge-color'>\n";
    echo ".badge-custom{border: 0px solid {$badge} !important;color: {$badge} !important;}\n";
    echo "</style>\n";
}
add_action( 'wp_head', 'hiregen_customizer_badge_css', 11 );

function hiregen_customizer_live_preview() {
    if ( is_customize_preview() ) {
        wp_enqueue_script(
            'hiregen-customizer-live',
            get_template_directory_uri() . '/assets/js/customizer-live.js', // adjust path/name
            array( 'jquery', 'customize-preview' ),
            null,
            true
        );
    }
}
add_action( 'customize_preview_init', 'hiregen_customizer_live_preview' );

/**
 * Enqueue Go to Top script for front-end
 */
function hiregen_enqueue_go_top_script() {
    // Only load on the front-end (not admin or login)
    if ( is_admin() ) {
        return;
    }

    // Enqueue the JS file in footer
    wp_enqueue_script(
        'hiregen-go-top', // handle
        get_template_directory_uri() . '/assets/js/go-top.js', // path to your JS
        array(), // dependencies (none)
        filemtime( get_template_directory() . '/assets/js/go-top.js' ), // version for cache-busting
        true // load in footer
    );
}
add_action( 'wp_enqueue_scripts', 'hiregen_enqueue_go_top_script' );

/* ---------------------------
 * Register all customizer controls
 * --------------------------- */
function hiregen_customize_register_complete( $wp_customize ) {
   
    // -------------------------------------------------------------
// Color options (basic)
// -------------------------------------------------------------
$wp_customize->add_section( 'hiregen_color_section', array(
    'title'    => __( 'Color Options', 'hiregen-recruitment' ),
    'panel'    => 'hiregen_panel_home',
    'priority' => 90,
) );

// -----------------------------
// Blog section title / subtitle / description (Customizer)
// -----------------------------
$wp_customize->add_setting( 'hiregen_blog_title', array(
    'default'           => '',
    'sanitize_callback' => 'sanitize_text_field',
    'transport'         => 'postMessage', // live preview without reload
) );
$wp_customize->add_control( 'hiregen_blog_title', array(
    'label'   => __( 'Blog section title', 'hiregen-recruitment' ),
    'section' => 'hiregen_color_section', // change to your preferred section
    'type'    => 'text',
) );

$wp_customize->add_setting( 'hiregen_blog_subtitle', array(
    'default'           => '',
    'sanitize_callback' => 'sanitize_text_field',
    'transport'         => 'postMessage',
) );
$wp_customize->add_control( 'hiregen_blog_subtitle', array(
    'label'   => __( 'Blog section subtitle (small badge)', 'hiregen-recruitment' ),
    'section' => 'hiregen_color_section',
    'type'    => 'text',
) );

$wp_customize->add_setting( 'hiregen_blog_description', array(
    'default'           => '',
    'sanitize_callback' => 'wp_kses_post',
    'transport'         => 'postMessage',
) );
$wp_customize->add_control( 'hiregen_blog_description', array(
    'label'   => __( 'Blog section description / subtext', 'hiregen-recruitment' ),
    'section' => 'hiregen_color_section',
    'type'    => 'textarea',
) );

$wp_customize->add_setting( 'hiregen_color_primary', array( 'default' => '#6f42c1', 'sanitize_callback' => 'hiregen_sanitize_hex_color' ) );
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_color_primary', array( 'label' => __( 'Primary color', 'hiregen-recruitment' ), 'section' => 'hiregen_color_section' ) ) );

$wp_customize->add_setting( 'hiregen_color_secondary', array( 'default' => '#6c757d', 'sanitize_callback' => 'hiregen_sanitize_hex_color' ) );
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_color_secondary', array( 'label' => __( 'Secondary color', 'hiregen-recruitment' ), 'section' => 'hiregen_color_section' ) ) );

$wp_customize->add_setting( 'hiregen_heading_color', array( 'default' => '#222222', 'sanitize_callback' => 'hiregen_sanitize_hex_color' ) );
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_heading_color', array( 'label' => __( 'Headings color', 'hiregen-recruitment' ), 'section' => 'hiregen_color_section' ) ) );

$wp_customize->add_setting( 'hiregen_text_color', array( 'default' => '#666666', 'sanitize_callback' => 'hiregen_sanitize_hex_color' ) );
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_text_color', array( 'label' => __( 'Text color', 'hiregen-recruitment' ), 'section' => 'hiregen_color_section' ) ) );

// Badge color (Customizer)
$wp_customize->add_setting( 'hiregen_badge_color', array(
    'default'           => '#e5daf8',
    'sanitize_callback' => 'hiregen_sanitize_hex_color', // you already have this
    'transport'         => 'postMessage', // live preview
) );

$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_badge_color', array(
    'label'   => __( 'Badge color', 'hiregen-recruitment' ),
    'section' => 'hiregen_color_section',
) ) );

    // -- Panels
    $wp_customize->add_panel( 'hiregen_panel_home', array(
        'title'    => __( 'Hiregen Theme Options', 'hiregen-recruitment' ),
        'priority' => 10,
    ) );

    // Display Features panel (for show/hide toggles)
    $wp_customize->add_panel( 'hiregen_display_features', array(
        'title'    => __( 'Display Features', 'hiregen-recruitment' ),
        'priority' => 11,
    ) );

    $wp_customize->add_setting( 'hiregen_color_link', array(
    'default'           => '#6f42c1',
    'sanitize_callback' => 'hiregen_sanitize_hex_color'
) );
$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_color_link', array(
    'label'   => __( 'Link color', 'hiregen-recruitment' ),
    'section' => 'hiregen_color_section'
) ) );

// Background color (Customizer) — reliable version
$wp_customize->add_setting( 'hiregen_background_color', array(
    'default'           => '#ffffff',
    'sanitize_callback' => 'sanitize_hex_color',   // use WP core sanitizer
    'transport'         => 'refresh',
    'capability'        => 'edit_theme_options',
) );

$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'hiregen_background_color',
    array(
        'label'    => __( 'Background color', 'hiregen-recruitment' ),
        'section'  => 'hiregen_color_section',
        'settings' => 'hiregen_background_color',
        'priority' => 70,
    )
) );

    // -------------------------------------------------------------
    // Header Section
    // -------------------------------------------------------------
    $wp_customize->add_section( 'hiregen_header_section', array(
        'title'    => __( 'Header', 'hiregen-recruitment' ),
        'panel'    => 'hiregen_panel_home',
        'priority' => 10,
    ) );
    // Background color for Header
$wp_customize->add_setting( 'hiregen_header_bg', array(
    'sanitize_callback' => 'sanitize_hex_color',
    'default'           => '#ffffff', // default fallback
    'transport'         => 'refresh',
) );

$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_header_bg', array(
    'label'    => __( 'Header Background Color', 'hiregen-recruitment' ),
    'section'  => 'hiregen_header_section',
    'settings' => 'hiregen_header_bg',
    'priority' => 1,
) ) );


    $wp_customize->add_setting( 'hiregen_header_logo', array(
        'sanitize_callback' => 'esc_url_raw',
    ) );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'hiregen_header_logo', array(
        'label'   => __( 'Header logo', 'hiregen-recruitment' ),
        'section' => 'hiregen_header_section',
    ) ) );

    $wp_customize->add_setting( 'hiregen_header_cta_text', array(
        'default'           => __( 'Get Started', 'hiregen-recruitment' ),
        'sanitize_callback' => 'hiregen_sanitize_text',
    ) );
    $wp_customize->add_control( 'hiregen_header_cta_text', array(
        'label'   => __( 'Header CTA text', 'hiregen-recruitment' ),
        'section' => 'hiregen_header_section',
        'type'    => 'text',
    ) );

    $wp_customize->add_setting( 'hiregen_header_cta_url', array(
        'sanitize_callback' => 'hiregen_sanitize_url',
    ) );
    $wp_customize->add_control( 'hiregen_header_cta_url', array(
        'label'   => __( 'Header CTA URL', 'hiregen-recruitment' ),
        'section' => 'hiregen_header_section',
        'type'    => 'url',
    ) );

    // Add selective refresh for header logo
    if ( isset( $wp_customize->selective_refresh ) ) {
        $wp_customize->selective_refresh->add_partial( 'hiregen_header_logo', array(
            'selector'            => '.navbar-brand',
            'render_callback'     => 'hiregen_partial_render_header_logo',
            'fallback_refresh'    => true,
        ) );
    }

// Header logo size (pixel slider)
$wp_customize->add_setting( 'hiregen_header_logo_size', array(
    'default'           => 180,
    'sanitize_callback' => 'absint',
    'transport'         => 'postMessage',
) );

$wp_customize->add_control( 'hiregen_header_logo_size', array(
    'label'       => __( 'Header logo size (px)', 'hiregen-recruitment' ),
    'section'     => 'hiregen_header_section',
    'type'        => 'range',
    'input_attrs' => array(
        'min'  => 50,
        'max'  => 400,
        'step' => 1,
    ),
) );




// -------------------------------------------------------------
    // Hero section
    // -------------------------------------------------------------
// ---- Hero background controls: color and image ----
$wp_customize->add_setting( 'hiregen_hero_bg', array(
    'default'           => '', // optional: put a default color like '#ffffff'
    'sanitize_callback' => 'sanitize_hex_color',
    'transport'         => 'refresh',
) );

$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_hero_bg', array(
    'label'    => __( 'Hero background color', 'hiregen-recruitment' ),
    'section'  => 'hiregen_hero_section', // match the hero section id in your file
    'settings' => 'hiregen_hero_bg',
    'priority' => 30,
) ) );

// Background image (optional)
$wp_customize->add_setting( 'hiregen_hero_bg_image', array(
    'default'           => '',
    'sanitize_callback' => 'esc_url_raw',
    'transport'         => 'refresh',
) );

$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'hiregen_hero_bg_image', array(
    'label'    => __( 'Hero background image', 'hiregen-recruitment' ),
    'section'  => 'hiregen_hero_section', // same section as hero controls
    'settings' => 'hiregen_hero_bg_image',
    'priority' => 31,
) ) );

    $wp_customize->add_section( 'hiregen_hero_section', array(
        'title'    => __( 'Hero Section', 'hiregen-recruitment' ),
        'panel'    => 'hiregen_panel_home',
        'priority' => 15,
    ) );

    $wp_customize->add_setting( 'hiregen_hero_subtitle', array( 'sanitize_callback' => 'hiregen_sanitize_text' ) );
    $wp_customize->add_control( 'hiregen_hero_subtitle', array(
        'label'   => __( 'Hero subtitle', 'hiregen-recruitment' ),
        'section' => 'hiregen_hero_section',
        'type'    => 'text',
    ) );

    $wp_customize->add_setting( 'hiregen_hero_title', array( 'sanitize_callback' => 'hiregen_sanitize_html' ) );
    $wp_customize->add_control( 'hiregen_hero_title', array(
        'label'   => __( 'Hero title', 'hiregen-recruitment' ),
        'section' => 'hiregen_hero_section',
        'type'    => 'textarea',
    ) );

    $wp_customize->add_setting( 'hiregen_hero_description', array( 'sanitize_callback' => 'hiregen_sanitize_html' ) );
    $wp_customize->add_control( 'hiregen_hero_description', array(
        'label'   => __( 'Hero description', 'hiregen-recruitment' ),
        'section' => 'hiregen_hero_section',
        'type'    => 'textarea',
    ) );

    for ( $i = 1; $i <= 6; $i++ ) {
        $wp_customize->add_setting( 'hiregen_hero_li_' . $i, array( 'sanitize_callback' => 'hiregen_sanitize_text' ) );
        $wp_customize->add_control( 'hiregen_hero_li_' . $i, array( 'label' => sprintf( __( 'List item %d', 'hiregen-recruitment' ), $i ), 'section' => 'hiregen_hero_section', 'type' => 'text' ) );
    }

    $wp_customize->add_setting( 'hiregen_hero_image', array( 'sanitize_callback' => 'esc_url_raw' ) );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'hiregen_hero_image', array(
        'label'   => __( 'Hero image', 'hiregen-recruitment' ),
        'section' => 'hiregen_hero_section',
    ) ) );

    $wp_customize->add_setting( 'hiregen_hero_primary_text', array( 'default' => __( 'Start Your Search', 'hiregen-recruitment' ), 'sanitize_callback' => 'hiregen_sanitize_text' ) );
    $wp_customize->add_control( 'hiregen_hero_primary_text', array(
        'label'   => __( 'Primary button text', 'hiregen-recruitment' ),
        'section' => 'hiregen_hero_section',
    ) );
    $wp_customize->add_setting( 'hiregen_hero_primary_url', array( 'sanitize_callback' => 'hiregen_sanitize_url' ) );
    $wp_customize->add_control( 'hiregen_hero_primary_url', array( 'label' => __( 'Primary button link', 'hiregen-recruitment' ), 'section' => 'hiregen_hero_section', 'type' => 'url' ) );

    $wp_customize->add_setting( 'hiregen_hero_secondary_text', array( 'default' => __( 'Contact Us', 'hiregen-recruitment' ), 'sanitize_callback' => 'hiregen_sanitize_text' ) );
    $wp_customize->add_control( 'hiregen_hero_secondary_text', array( 'label' => __( 'Secondary button text', 'hiregen-recruitment' ), 'section' => 'hiregen_hero_section' ) );
    $wp_customize->add_setting( 'hiregen_hero_secondary_url', array( 'sanitize_callback' => 'hiregen_sanitize_url' ) );
    $wp_customize->add_control( 'hiregen_hero_secondary_url', array( 'label' => __( 'Secondary button link', 'hiregen-recruitment' ), 'section' => 'hiregen_hero_section', 'type' => 'url' ) );

    // selective refresh for hero title/subtitle
    if ( isset( $wp_customize->selective_refresh ) ) {
        $wp_customize->selective_refresh->add_partial( 'hiregen_hero_title', array(
            'selector'        => '.hiregen-hero .hero-title',
            'render_callback' => 'hiregen_partial_render_hero_title',
        ) );
        $wp_customize->selective_refresh->add_partial( 'hiregen_hero_subtitle', array(
            'selector'        => '.hiregen-hero .subtitle',
            'render_callback' => 'hiregen_partial_render_hero_subtitle',
        ) );
    }

    // -------------------------------------------------------------
    // Featured Logos
    // -------------------------------------------------------------
    $wp_customize->add_section( 'hiregen_featured_logos_section', array(
        'title'    => __( 'Featured Logos', 'hiregen-recruitment' ),
        'panel'    => 'hiregen_panel_home',
        'priority' => 18,
    ) );

    $wp_customize->add_setting( 'hiregen_featured_logos_bg', array( 'default' => '#ffffff', 'sanitize_callback' => 'hiregen_sanitize_hex_color' ) );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_featured_logos_bg', array(
        'label'   => __( 'Background color', 'hiregen-recruitment' ),
        'section' => 'hiregen_featured_logos_section',
    ) ) );

    $wp_customize->add_setting( 'hiregen_featured_logos_limit', array( 'default' => 10, 'sanitize_callback' => 'absint' ) );
    $wp_customize->add_control( 'hiregen_featured_logos_limit', array(
        'label'   => __( 'Display limit', 'hiregen-recruitment' ),
        'section' => 'hiregen_featured_logos_section',
        'type'    => 'number',
    ) );

    // -------------------------------------------------------------
    // Why section
    // -------------------------------------------------------------
    $wp_customize->add_section( 'hiregen_why_section', array(
        'title'    => __( 'Why Section', 'hiregen-recruitment' ),
        'panel'    => 'hiregen_panel_home',
        'priority' => 20,
    ) );

// Background color for Why Section
$wp_customize->add_setting( 'hiregen_why_bg', array(
    'sanitize_callback' => 'sanitize_hex_color',
    'default'           => '#ffffff', // fallback default
    'transport'         => 'refresh',
) );

$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_why_bg', array(
    'label'    => __( 'Background Color', 'hiregen-recruitment' ),
    'section'  => 'hiregen_why_section',
    'settings' => 'hiregen_why_bg',
    'priority' => 1,
) ) );


    $wp_customize->add_setting( 'hiregen_why_image', array( 'sanitize_callback' => 'esc_url_raw' ) );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'hiregen_why_image', array(
        'label'   => __( 'Why image', 'hiregen-recruitment' ),
        'section' => 'hiregen_why_section',
    ) ) );

    $wp_customize->add_setting( 'hiregen_why_subtitle', array( 'sanitize_callback' => 'hiregen_sanitize_text' ) );
    $wp_customize->add_control( 'hiregen_why_subtitle', array( 'label' => __( 'Subtitle', 'hiregen-recruitment' ), 'section' => 'hiregen_why_section' ) );

    $wp_customize->add_setting( 'hiregen_why_title', array( 'sanitize_callback' => 'hiregen_sanitize_html' ) );
    $wp_customize->add_control( 'hiregen_why_title', array( 'label' => __( 'Title', 'hiregen-recruitment' ), 'section' => 'hiregen_why_section', 'type' => 'textarea' ) );

    $wp_customize->add_setting( 'hiregen_why_description', array( 'sanitize_callback' => 'hiregen_sanitize_html' ) );
    $wp_customize->add_control( 'hiregen_why_description', array( 'label' => __( 'Description', 'hiregen-recruitment' ), 'section' => 'hiregen_why_section', 'type' => 'textarea' ) );

    for ( $i = 1; $i <= 4; $i++ ) {
        $wp_customize->add_setting( 'hiregen_why_li_' . $i, array( 'sanitize_callback' => 'hiregen_sanitize_text' ) );
        $wp_customize->add_control( 'hiregen_why_li_' . $i, array( 'label' => sprintf( __( 'List item %d', 'hiregen-recruitment' ), $i ), 'section' => 'hiregen_why_section', 'type' => 'text' ) );
    }

    $wp_customize->add_setting( 'hiregen_why_btn_text', array( 'default' => __( 'About Us', 'hiregen-recruitment' ), 'sanitize_callback' => 'hiregen_sanitize_text' ) );
    $wp_customize->add_control( 'hiregen_why_btn_text', array( 'label' => __( 'Button text', 'hiregen-recruitment' ), 'section' => 'hiregen_why_section' ) );

$wp_customize->add_setting(
    'hiregen_why_btn_url',
    array(
        'default'           => home_url( '/about-us/' ),
        'sanitize_callback' => 'hiregen_sanitize_url', // or 'esc_url_raw'
        'transport'         => 'refresh',
    )
);
$wp_customize->add_control( 'hiregen_why_btn_url', array( 'label' => __( 'Button URL', 'hiregen-recruitment' ), 'section' => 'hiregen_why_section', 'type' => 'url' ) );

    // -------------------------------------------------------------
    // Services / Projects / Testimonial / Team / Blog sections (common controls)
    // -------------------------------------------------------------
    $common_sections = array( 'services', 'projects', 'testimonial', 'team', 'blog');
    foreach ( $common_sections as $s ) {
        $sec_id = 'hiregen_' . $s . '_section';
        $wp_customize->add_section( $sec_id, array(
            'title'    => ucfirst( $s ),
            'panel'    => 'hiregen_panel_home',
            'priority' => 30,
        ) );

        $wp_customize->add_setting( 'hiregen_' . $s . '_bg', array( 'default' => '#ffffff', 'sanitize_callback' => 'hiregen_sanitize_hex_color' ) );
        $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_' . $s . '_bg', array( 'label' => __( 'Background color', 'hiregen-recruitment' ), 'section' => $sec_id ) ) );

        $wp_customize->add_setting( 'hiregen_' . $s . '_subtitle', array( 'sanitize_callback' => 'hiregen_sanitize_text' ) );
        $wp_customize->add_control( 'hiregen_' . $s . '_subtitle', array( 'label' => __( 'Subtitle', 'hiregen-recruitment' ), 'section' => $sec_id ) );

        $wp_customize->add_setting( 'hiregen_' . $s . '_title', array( 'sanitize_callback' => 'hiregen_sanitize_html' ) );
        $wp_customize->add_control( 'hiregen_' . $s . '_title', array( 'label' => __( 'Title', 'hiregen-recruitment' ), 'section' => $sec_id, 'type' => 'textarea' ) );

        $wp_customize->add_setting( 'hiregen_' . $s . '_description', array( 'sanitize_callback' => 'hiregen_sanitize_html' ) );
        $wp_customize->add_control( 'hiregen_' . $s . '_description', array( 'label' => __( 'Description', 'hiregen-recruitment' ), 'section' => $sec_id, 'type' => 'textarea' ) );

        $wp_customize->add_setting( 'hiregen_' . $s . '_btn_text', array( 'sanitize_callback' => 'hiregen_sanitize_text' ) );
        $wp_customize->add_control( 'hiregen_' . $s . '_btn_text', array( 'label' => __( 'Button text', 'hiregen-recruitment' ), 'section' => $sec_id ) );

        $wp_customize->add_setting( 'hiregen_' . $s . '_btn_url', array( 'sanitize_callback' => 'hiregen_sanitize_url' ) );
        $wp_customize->add_control( 'hiregen_' . $s . '_btn_url', array( 'label' => __( 'Button URL', 'hiregen-recruitment' ), 'section' => $sec_id, 'type' => 'url' ) );

        // posts per section
        $wp_customize->add_setting( 'hiregen_' . $s . '_count', array( 'default' => 3, 'sanitize_callback' => 'absint' ) );
        $wp_customize->add_control( 'hiregen_' . $s . '_count', array( 'label' => __( 'Number of items to show', 'hiregen-recruitment' ), 'section' => $sec_id, 'type' => 'number' ) );
    }

    // -------------------------------------------------------------
    // Jobs section note (WP Job Manager dependency)
    // -------------------------------------------------------------
// ----------------------------
// ----------------------------
// ----------------------------
// Jobs Section (Customizer)
// ----------------------------
$wp_customize->add_section( 'hiregen_jobs_section', array(
    'title'    => __( 'Jobs Section', 'hiregen-recruitment' ),
    'panel'    => 'hiregen_panel_home',
    'priority' => 60,
) );

// Background color for Jobs Section
$wp_customize->add_setting( 'hiregen_jobs_bg', array(
    'sanitize_callback' => 'sanitize_hex_color',
    'default'           => '#ffffff',
    'transport'         => 'refresh',
) );

$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_jobs_bg', array(
    'label'    => __( 'Background Color', 'hiregen-recruitment' ),
    'section'  => 'hiregen_jobs_section',
    'settings' => 'hiregen_jobs_bg',
    'priority' => 1,
) ) );


$wp_customize->add_setting( 'hiregen_jobs_subtitle', array(
    'default'           => __( 'Our Jobs', 'hiregen-recruitment' ),
    'sanitize_callback' => 'sanitize_text_field',
    'transport'         => 'refresh',
) );
$wp_customize->add_control( 'hiregen_jobs_subtitle', array(
    'label'   => __( 'Subtitle', 'hiregen-recruitment' ),
    'section' => 'hiregen_jobs_section',
    'type'    => 'text',
) );

$wp_customize->add_setting( 'hiregen_jobs_title', array(
    'default'           => __( 'Latest Jobs', 'hiregen-recruitment' ),
    'sanitize_callback' => 'sanitize_text_field',
    'transport'         => 'refresh',
) );
$wp_customize->add_control( 'hiregen_jobs_title', array(
    'label'   => __( 'Title', 'hiregen-recruitment' ),
    'section' => 'hiregen_jobs_section',
    'type'    => 'text',
) );

$wp_customize->add_setting( 'hiregen_jobs_description', array(
    'default'           => __( 'Explore the newest opportunities available right now.', 'hiregen-recruitment' ),
    'sanitize_callback' => 'wp_kses_post',
    'transport'         => 'refresh',
) );
$wp_customize->add_control( 'hiregen_jobs_description', array(
    'label'   => __( 'Description', 'hiregen-recruitment' ),
    'section' => 'hiregen_jobs_section',
    'type'    => 'textarea',
) );

$wp_customize->add_setting( 'hiregen_jobs_button_text', array(
    'default'           => __( 'See all jobs', 'hiregen-recruitment' ),
    'sanitize_callback' => 'sanitize_text_field',
    'transport'         => 'refresh',
) );
$wp_customize->add_control( 'hiregen_jobs_button_text', array(
    'label'   => __( 'Button text', 'hiregen-recruitment' ),
    'section' => 'hiregen_jobs_section',
    'type'    => 'text',
) );

$wp_customize->add_setting( 'hiregen_jobs_button_url', array(
    'default'           => '',
    'sanitize_callback' => 'esc_url_raw',
    'transport'         => 'refresh',
) );
$wp_customize->add_control( 'hiregen_jobs_button_url', array(
    'label'   => __( 'Button URL', 'hiregen-recruitment' ),
    'section' => 'hiregen_jobs_section',
    'type'    => 'url',
) );

$wp_customize->add_setting( 'hiregen_jobs_count', array(
    'default'           => 3,
    'sanitize_callback' => 'absint',
    'transport'         => 'refresh',
) );
$wp_customize->add_control( 'hiregen_jobs_count', array(
    'label'   => __( 'Number of items to show', 'hiregen-recruitment' ),
    'section' => 'hiregen_jobs_section',
    'type'    => 'number',
    'input_attrs' => array(
        'min'  => 1,
        'max'  => 20,
        'step' => 1,
    ),
) );



// -------------------------------------------------------------
// Contact (Contact Form 7)
// -------------------------------------------------------------
$wp_customize->add_section( 'hiregen_contact_section', array(
    'title'    => __( 'Contact Section', 'hiregen-recruitment' ),
    'panel'    => 'hiregen_panel_home',
    'priority' => 65,
) );

$wp_customize->add_setting( 'hiregen_contact_bg', array(
    'default'           => '#ffffff',
    'sanitize_callback' => 'hiregen_sanitize_hex_color',
) );
$wp_customize->add_control( new WP_Customize_Color_Control(
    $wp_customize,
    'hiregen_contact_bg',
    array(
        'label'   => __( 'Background color', 'hiregen-recruitment' ),
        'section' => 'hiregen_contact_section',
    )
) );

$wp_customize->add_setting( 'hiregen_contact_subtitle', array( 'sanitize_callback' => 'hiregen_sanitize_text' ) );
$wp_customize->add_control( 'hiregen_contact_subtitle', array(
    'label'   => __( 'Subtitle', 'hiregen-recruitment' ),
    'section' => 'hiregen_contact_section',
    'type'    => 'text',
) );

$wp_customize->add_setting( 'hiregen_contact_title', array( 'sanitize_callback' => 'hiregen_sanitize_html' ) );
$wp_customize->add_control( 'hiregen_contact_title', array(
    'label'   => __( 'Title', 'hiregen-recruitment' ),
    'section' => 'hiregen_contact_section',
    'type'    => 'textarea',
) );

$wp_customize->add_setting( 'hiregen_contact_description', array( 'sanitize_callback' => 'hiregen_sanitize_html' ) );
$wp_customize->add_control( 'hiregen_contact_description', array(
    'label'   => __( 'Description', 'hiregen-recruitment' ),
    'section' => 'hiregen_contact_section',
    'type'    => 'textarea',
) );

$wp_customize->add_setting( 'hiregen_contact_form_shortcode', array(
    'sanitize_callback' => 'wp_kses_post',
) );
$wp_customize->add_control( 'hiregen_contact_form_shortcode', array(
    'label'       => __( 'Contact Form 7 Shortcode', 'hiregen-recruitment' ),
    'section'     => 'hiregen_contact_section',
    'type'        => 'text',
    'description' => __( 'Paste your Contact Form 7 shortcode here, e.g. [contact-form-7 id="123" title="Contact form"]', 'hiregen-recruitment' ),
) );

// -------------------------------------------------------------
// Contact - additional boxes (Customizer)
// -------------------------------------------------------------
/* Box 1 */
$wp_customize->add_setting( 'hiregen_contact_box1_title', array(
    'default'           => 'Give us a Call',
    'sanitize_callback' => 'hiregen_sanitize_text',
) );
$wp_customize->add_control( 'hiregen_contact_box1_title', array(
    'label'   => __( 'Box 1 Title', 'hiregen-recruitment' ),
    'section' => 'hiregen_contact_section',
    'type'    => 'text',
) );

$wp_customize->add_setting( 'hiregen_contact_box1_info', array(
    'default'           => '+1 (212) 555-7890',
    'sanitize_callback' => 'hiregen_sanitize_text',
) );
$wp_customize->add_control( 'hiregen_contact_box1_info', array(
    'label'   => __( 'Box 1 Info', 'hiregen-recruitment' ),
    'section' => 'hiregen_contact_section',
    'type'    => 'text',
) );

$wp_customize->add_setting( 'hiregen_contact_box1_icon', array(
    'default'           => 'bi-telephone', // bootstrap icon class fallback
    'sanitize_callback' => 'hiregen_sanitize_text',
) );
$wp_customize->add_control( 'hiregen_contact_box1_icon', array(
    'label'   => __( 'Box 1 Icon (Bootstrap icon class)', 'hiregen-recruitment' ),
    'section' => 'hiregen_contact_section',
    'type'    => 'text',
    'description' => __( 'Example: bi-telephone or bi-telephone-fill', 'hiregen-recruitment' )
) );

/* Box 2 */
$wp_customize->add_setting( 'hiregen_contact_box2_title', array(
    'default'           => 'Send me Mail',
    'sanitize_callback' => 'hiregen_sanitize_text',
) );
$wp_customize->add_control( 'hiregen_contact_box2_title', array(
    'label'   => __( 'Box 2 Title', 'hiregen-recruitment' ),
    'section' => 'hiregen_contact_section',
    'type'    => 'text',
) );

$wp_customize->add_setting( 'hiregen_contact_box2_info', array(
    'default'           => 'support@wpjobnova.com',
    'sanitize_callback' => 'sanitize_email',
) );
$wp_customize->add_control( 'hiregen_contact_box2_info', array(
    'label'   => __( 'Box 2 Info (email)', 'hiregen-recruitment' ),
    'section' => 'hiregen_contact_section',
    'type'    => 'text',
) );

$wp_customize->add_setting( 'hiregen_contact_box2_icon', array(
    'default'           => 'bi-envelope',
    'sanitize_callback' => 'hiregen_sanitize_text',
) );
$wp_customize->add_control( 'hiregen_contact_box2_icon', array(
    'label'   => __( 'Box 2 Icon (Bootstrap icon class)', 'hiregen-recruitment' ),
    'section' => 'hiregen_contact_section',
    'type'    => 'text',
    'description' => __( 'Example: bi-envelope or bi-envelope-fill', 'hiregen-recruitment' )
) );


    // -------------------------------------------------------------
    // Footer
    // -------------------------------------------------------------
    $wp_customize->add_section( 'hiregen_footer_section', array(
        'title'    => __( 'Footer Settings', 'hiregen-recruitment' ),
        'panel'    => 'hiregen_panel_home',
        'priority' => 80,
    ) );

    // Background color for Footer
$wp_customize->add_setting( 'hiregen_footer_bg', array(
    'sanitize_callback' => 'sanitize_hex_color',
    'default'           => '#222222', // fallback default
    'transport'         => 'refresh',
) );

$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_footer_bg', array(
    'label'    => __( 'Footer Background Color', 'hiregen-recruitment' ),
    'section'  => 'hiregen_footer_section',
    'settings' => 'hiregen_footer_bg',
    'priority' => 1,
) ) );


    $wp_customize->add_setting( 'hiregen_footer_logo', array( 'sanitize_callback' => 'esc_url_raw' ) );
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'hiregen_footer_logo', array(
        'label'   => __( 'Footer logo', 'hiregen-recruitment' ),
        'section' => 'hiregen_footer_section',
    ) ) );

    $wp_customize->add_setting( 'hiregen_footer_about', array( 'sanitize_callback' => 'hiregen_sanitize_html' ) );
    $wp_customize->add_control( 'hiregen_footer_about', array( 'label' => __( 'About text', 'hiregen-recruitment' ), 'section' => 'hiregen_footer_section', 'type' => 'textarea' ) );

    // social links (facebook, twitter, linkedin, instagram, youtube)
    $socials = array( 'facebook', 'twitter', 'linkedin', 'instagram', 'youtube' );
    foreach ( $socials as $s ) {
        $wp_customize->add_setting( 'hiregen_footer_social_' . $s, array( 'sanitize_callback' => 'hiregen_sanitize_url' ) );
        $wp_customize->add_control( 'hiregen_footer_social_' . $s, array(
            'label'   => ucwords( $s ) . ' ' . __( 'URL', 'hiregen-recruitment' ),
            'section' => 'hiregen_footer_section',
            'type'    => 'url',
        ) );
    }

    $wp_customize->add_setting( 'hiregen_footer_contact_title', array( 'sanitize_callback' => 'hiregen_sanitize_text' ) );
    $wp_customize->add_control( 'hiregen_footer_contact_title', array( 'label' => __( 'Contact title', 'hiregen-recruitment' ), 'section' => 'hiregen_footer_section' ) );

    $wp_customize->add_setting( 'hiregen_footer_address', array( 'sanitize_callback' => 'hiregen_sanitize_text' ) );
    $wp_customize->add_control( 'hiregen_footer_address', array( 'label' => __( 'Address', 'hiregen-recruitment' ), 'section' => 'hiregen_footer_section', 'type' => 'textarea' ) );

    $wp_customize->add_setting( 'hiregen_footer_email', array( 'sanitize_callback' => 'sanitize_email' ) );
    $wp_customize->add_control( 'hiregen_footer_email', array( 'label' => __( 'Email', 'hiregen-recruitment' ), 'section' => 'hiregen_footer_section', 'type' => 'email' ) );

    $wp_customize->add_setting( 'hiregen_footer_phone', array( 'sanitize_callback' => 'hiregen_sanitize_text' ) );
    $wp_customize->add_control( 'hiregen_footer_phone', array( 'label' => __( 'Phone', 'hiregen-recruitment' ), 'section' => 'hiregen_footer_section' ) );

    // selective refresh for footer about
    if ( isset( $wp_customize->selective_refresh ) ) {
        $wp_customize->selective_refresh->add_partial( 'hiregen_footer_about', array(
            'selector'        => '.site-footer .footer-about',
            'render_callback' => 'hiregen_partial_render_footer_about',
        ) );
    }

// Footer logo size (pixel slider)
$wp_customize->add_setting( 'hiregen_footer_logo_size', array(
    'default'           => 160,
    'sanitize_callback' => 'absint',
    'transport'         => 'postMessage',
) );

$wp_customize->add_control( 'hiregen_footer_logo_size', array(
    'label'       => __( 'Footer logo size (px)', 'hiregen-recruitment' ),
    'section'     => 'hiregen_footer_section',
    'type'        => 'range',
    'input_attrs' => array(
        'min'  => 50,
        'max'  => 400,
        'step' => 1,
    ),
) );

// -------------------------------------------------------------
// WhatsApp Widget
// -------------------------------------------------------------
$wp_customize->add_setting( 'hiregen_whatsapp_icon', array(
    'default'           => 'bi bi-whatsapp',
    'sanitize_callback' => 'hiregen_sanitize_text',
) );

$wp_customize->add_control( 'hiregen_whatsapp_icon', array(
    'label'       => __( 'WhatsApp Icon (Bootstrap class)', 'hiregen-recruitment' ),
    'section'     => 'hiregen_footer_section',
    'type'        => 'text',
    'description' => __( 'Example: bi bi-whatsapp or bi-whatsapp', 'hiregen-recruitment' ),
) );

$wp_customize->add_setting( 'hiregen_whatsapp_link', array(
    'default'           => 'https://wa.me/1234567890',
    'sanitize_callback' => 'hiregen_sanitize_url',
) );

$wp_customize->add_control( 'hiregen_whatsapp_link', array(
    'label'       => __( 'WhatsApp Link', 'hiregen-recruitment' ),
    'section'     => 'hiregen_footer_section',
    'type'        => 'url',
    'description' => __( 'Use format: https://wa.me/1234567890 (replace number)', 'hiregen-recruitment' ),
) );


// Footer column order (after WhatsApp Link)
$wp_customize->add_setting( 'hiregen_footer_order', array(
    'default'           => 'default',
    'sanitize_callback' => 'sanitize_text_field',
) );

$wp_customize->add_control( 'hiregen_footer_order', array(
    'label'       => __( 'Footer Column Order', 'hiregen-recruitment' ),
    'section'     => 'hiregen_footer_section', // same as WhatsApp Link section
    'type'        => 'select',
    'choices'     => array(
        'default' => __( 'Default (1 → 2 → 3 → 4)', 'hiregen-recruitment' ),
        'swap'    => __( 'Swap First ↔ Last (4 → 2 → 3 → 1)', 'hiregen-recruitment' ),
        'reverse' => __( 'Reverse (4 → 3 → 2 → 1)', 'hiregen-recruitment' ),
    ),
    'description' => __( 'Reorder footer widget columns visually.', 'hiregen-recruitment' ),
) );


    // -------------------------------------------------------------
    // Display toggles: show/hide each homepage section
    // -------------------------------------------------------------
    $wp_customize->add_section( 'hiregen_display_toggle_section', array(
        'title'    => __( 'Show / Hide Sections', 'hiregen-recruitment' ),
        'panel'    => 'hiregen_display_features',
        'priority' => 5,
    ) );

$show_sections = array(
    'hero',
    'featured_logos',
    'jobs',
    'our_products',
    'pricing',
    'services',
    'why',
    'projects',
    'testimonial',
    'team',
    'faq',
    'blog',
    'contact'
);

    foreach ( $show_sections as $ss ) {
        $id = 'hiregen_show_section_' . $ss;
        $wp_customize->add_setting( $id, array( 'default' => true, 'sanitize_callback' => 'hiregen_sanitize_checkbox' ) );
        $wp_customize->add_control( $id, array( 'label' => sprintf( __( 'Show %s section', 'hiregen-recruitment' ), ucwords( str_replace( '_', ' ', $ss ) ) ), 'section' => 'hiregen_display_toggle_section', 'type' => 'checkbox' ) );
    }

    // -------------------------------------------------------------
    // Color options (basic)
    // -------------------------------------------------------------
    $wp_customize->add_section( 'hiregen_color_section', array(
        'title'    => __( 'Color Options', 'hiregen-recruitment' ),
        'panel'    => 'hiregen_panel_home',
        'priority' => 90,
    ) );

    $wp_customize->add_setting( 'hiregen_color_primary', array( 'default' => '#6f42c1', 'sanitize_callback' => 'hiregen_sanitize_hex_color' ) );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_color_primary', array( 'label' => __( 'Primary color', 'hiregen-recruitment' ), 'section' => 'hiregen_color_section' ) ) );

    $wp_customize->add_setting( 'hiregen_color_secondary', array( 'default' => '#6c757d', 'sanitize_callback' => 'hiregen_sanitize_hex_color' ) );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_color_secondary', array( 'label' => __( 'Secondary color', 'hiregen-recruitment' ), 'section' => 'hiregen_color_section' ) ) );

    $wp_customize->add_setting( 'hiregen_heading_color', array( 'default' => '#222222', 'sanitize_callback' => 'hiregen_sanitize_hex_color' ) );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_heading_color', array( 'label' => __( 'Headings color', 'hiregen-recruitment' ), 'section' => 'hiregen_color_section' ) ) );

    $wp_customize->add_setting( 'hiregen_text_color', array( 'default' => '#666666', 'sanitize_callback' => 'hiregen_sanitize_hex_color' ) );
    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'hiregen_text_color', array( 'label' => __( 'Text color', 'hiregen-recruitment' ), 'section' => 'hiregen_color_section' ) ) );

// -------------------------------------------------------------
// Typography skeleton (20 Google fonts dropdown simplified)
// -------------------------------------------------------------
$fonts = array(
    '' => __( 'Default (system)', 'hiregen-recruitment' ),
    'Inter,system-ui,-apple-system,Segoe UI,Roboto' => 'Inter / System',
    'Roboto,Arial,Helvetica,sans-serif' => 'Roboto',
    'Poppins,Arial,Helvetica,sans-serif' => 'Poppins',
    'Montserrat,Arial,Helvetica,sans-serif' => 'Montserrat',
    'Lato,Arial,Helvetica,sans-serif' => 'Lato',
    'Nunito,Arial,Helvetica,sans-serif' => 'Nunito',
    'Open Sans,Arial,Helvetica,sans-serif' => 'Open Sans',
    'Merriweather,serif' => 'Merriweather',
    'Playfair Display,serif' => 'Playfair Display',

    // --- Added 10 more modern, free Google Fonts ---
    'Source Sans 3,Arial,Helvetica,sans-serif' => 'Source Sans 3',
    'Work Sans,Arial,Helvetica,sans-serif' => 'Work Sans',
    'Raleway,Arial,Helvetica,sans-serif' => 'Raleway',
    'Quicksand,Arial,Helvetica,sans-serif' => 'Quicksand',
    'Rubik,Arial,Helvetica,sans-serif' => 'Rubik',
    'Mulish,Arial,Helvetica,sans-serif' => 'Mulish',
    'Ubuntu,Arial,Helvetica,sans-serif' => 'Ubuntu',
    'Josefin Sans,Arial,Helvetica,sans-serif' => 'Josefin Sans',
    'Manrope,Arial,Helvetica,sans-serif' => 'Manrope',
    'DM Sans,Arial,Helvetica,sans-serif' => 'DM Sans',
);


$wp_customize->add_section( 'hiregen_typography_section', array(
    'title'    => __( 'Typography', 'hiregen-recruitment' ),
    'panel'    => 'hiregen_panel_home',
    'priority' => 95,
) );

// Body font (default to Inter/System)
$wp_customize->add_setting( 'hiregen_font_body', array(
    'default'           => 'Inter,system-ui,-apple-system,Segoe UI,Roboto',
    'sanitize_callback' => 'hiregen_sanitize_text',
) );
$wp_customize->add_control( 'hiregen_font_body', array(
    'label'   => __( 'Body font', 'hiregen-recruitment' ),
    'section' => 'hiregen_typography_section',
    'type'    => 'select',
    'choices' => $fonts,
) );

// Heading font (default to Inter/System)
$wp_customize->add_setting( 'hiregen_font_headings', array(
    'default'           => 'Inter,system-ui,-apple-system,Segoe UI,Roboto',
    'sanitize_callback' => 'hiregen_sanitize_text',
) );
$wp_customize->add_control( 'hiregen_font_headings', array(
    'label'   => __( 'Heading font', 'hiregen-recruitment' ),
    'section' => 'hiregen_typography_section',
    'type'    => 'select',
    'choices' => $fonts,
) );

// Button Font (use same choices; default to Inter/System)
$wp_customize->add_setting( 'hiregen_button_font', array(
    'default'           => 'Inter,system-ui,-apple-system,Segoe UI,Roboto',
    'sanitize_callback' => 'hiregen_sanitize_text',
) );
$wp_customize->add_control( 'hiregen_button_font', array(
    'label'   => __( 'Button font', 'hiregen-recruitment' ),
    'section' => 'hiregen_typography_section',
    'type'    => 'select',
    'choices' => $fonts,
) );

    /**
     * Reorder homepage sections and add an inline "SETTINGS" heading inside the same panel.
     * Place this after registering all other sections and before the customize_register function ends.
     */

    // Desired order for main homepage sections (priority values determine the order)
    $desired_order = array(
        'hiregen_header_section'           => 10,
        'hiregen_hero_section'             => 15,
        'hiregen_featured_logos_section'   => 20,
        'hiregen_jobs_section'             => 25,
        'our_products_section'     => 30, // support variant-
        'products_section'         => 30, // support variant-
        'hiregen_services_section'         => 35,
        'hiregen_why_section'              => 40,
        'projects_section'         => 45, // support variant-----
        'testimonial_section'      => 50, // support variant-----
        'hiregen_team_section'             => 55,
        'faq_section'              => 60, // support variant-----
        'hiregen_blog_section'             => 65,
        'hiregen_contact_section'          => 70,
    );

    foreach ( $desired_order as $sec_id => $prio ) {
        $sec = $wp_customize->get_section( $sec_id );
        if ( $sec ) {
            $sec->panel    = 'hiregen_panel_home';
            $sec->priority = (int) $prio;
        }
    }

    // Create a lightweight section that serves purely as a visual heading "SETTINGS"
    if ( ! $wp_customize->get_section( 'hiregen_settings_heading' ) ) {
        $wp_customize->add_section( 'hiregen_settings_heading', array(
            'title'    => __( 'SETTINGS', 'hiregen-recruitment' ),
            'panel'    => 'hiregen_panel_home',
            // Use a priority slightly after Contact Section so it appears in the requested place
            'priority' => 72,
            // No controls here — this is only a label / visual divider
        ) );
    } else {
        // ensure it's in the correct panel & priority if already exists
        $s = $wp_customize->get_section( 'hiregen_settings_heading' );
        if ( $s ) {
            $s->panel    = 'hiregen_panel_home';
            $s->priority = 72;
        }
    }

    // Ensure the actual settings sections appear directly after the heading (and in the same panel)
    $settings_after_contact = array(
        'hiregen_subheader_section' => 73,   // Sub Header Settings (if present)
        'hiregen_footer_section'    => 74,   // Footer Settings
        'hiregen_color_section'     => 75,   // Color Options
        'hiregen_typography_section'=> 76,   // Typography
    );

    foreach ( $settings_after_contact as $sec_id => $prio ) {
        $sec = $wp_customize->get_section( $sec_id );
        if ( $sec ) {
            $sec->panel    = 'hiregen_panel_home';
            $sec->priority = (int) $prio;
        }
    }

    // Keep the Display Features panel priority near top
    if ( $wp_customize->get_panel( 'hiregen_display_features' ) ) {
        $wp_customize->get_panel( 'hiregen_display_features' )->priority = 12;
    }


}

add_action( 'customize_register', 'hiregen_customize_register_complete' );
// 1. Disable big-image downscaling
add_filter( 'big_image_size_threshold', '__return_false' );

// 2. Maximize quality (keeps thumbnails high quality)
add_filter( 'jpeg_quality', function() { return 95; } );
add_filter( 'wp_editor_set_quality', function() { return 95; } );

// 3. Ensure theme supports post thumbnails (if not already added)
add_action( 'after_setup_theme', 'hiregen_theme_supports', 1 );
function hiregen_theme_supports() {
    if ( ! current_theme_supports( 'post-thumbnails' ) ) {
        add_theme_support( 'post-thumbnails' );
    }
}

// 4. Register better product / card image sizes
add_action( 'after_setup_theme', 'hiregen_image_sizes', 20 );
function hiregen_image_sizes() {
    // Primary card size used in product grid
    add_image_size( 'hiregen-card', 840, 420, true );        // 2:1 crop - 840x420
    // Retina / 2x version (use a valid name, no @)
    add_image_size( 'hiregen-card-2x', 1680, 840, true );    // retina
    // Optional alternative sizes you might need
    add_image_size( 'hiregen-card-medium', 600, 300, true ); // medium card
}


/* ---------------------------
 * Sortable (drag & drop) control for homepage sections
 * --------------------------- */

/**
 * Simple sortable control for Customizer
 */
if ( class_exists( 'WP_Customize_Control' ) && ! class_exists( 'Hiregen_Customize_Sortable_Control' ) ) {
    class Hiregen_Customize_Sortable_Control extends WP_Customize_Control {
        public $type = 'hiregen-sortable';

        // $choices is expected to be an associative array: slug => Label
        public function render_content() {
            if ( empty( $this->choices ) ) {
                return;
            }
            ?>
            <label>
                <?php if ( ! empty( $this->label ) ) : ?>
                    <span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
                <?php endif; ?>
                <?php if ( ! empty( $this->description ) ) : ?>
                    <span class="description customize-control-description"><?php echo wp_kses_post( $this->description ); ?></span>
                <?php endif; ?>
            </label>

            <input type="hidden" id="<?php echo esc_attr( $this->id ); ?>" value="<?php echo esc_attr( $this->value() ); ?>" <?php $this->link(); ?> />

            <ul class="hiregen-sortable-list" aria-label="<?php echo esc_attr( $this->label ); ?>">
                <?php
                // Use current value order if exists, otherwise default to provided choices order
                $current = $this->value();
                $current_arr = $current ? explode( ',', $current ) : array_keys( $this->choices );

                // ensure we show all choices even if some are missing from saved value
                $remaining = array_diff( array_keys( $this->choices ), $current_arr );
                $ordered = array_merge( $current_arr, $remaining );

                foreach ( $ordered as $slug ) :
                    if ( ! isset( $this->choices[ $slug ] ) ) {
                        continue;
                    }
                    ?>
                    <li class="hiregen-sortable-item" data-id="<?php echo esc_attr( $slug ); ?>">
                        <span class="hiregen-drag-handle" title="<?php esc_attr_e( 'Drag to reorder', 'hiregen-recruitment' ); ?>">≡</span>
                        <span class="hiregen-item-label"><?php echo esc_html( $this->choices[ $slug ] ); ?></span>
                    </li>
                <?php endforeach; ?>
            </ul>

            <?php
        }
    }
}

/**
 * Register the setting and the sortable control.
 * Add this inside your existing customize_register function or call it when $wp_customize is available.
 */
function hiregen_customize_register_sortable( $wp_customize ) {

    // List of homepage sections (slug => Label)
    $sections = array(
        'hero'           => __( 'Hero', 'hiregen-recruitment' ),
        'featured_logos' => __( 'Featured Logos', 'hiregen-recruitment' ),
        'jobs'           => __( 'Jobs', 'hiregen-recruitment' ),
        'our_products'   => __( 'Our Products', 'hiregen-recruitment' ),
        'pricing'        => __( 'Pricing', 'hiregen-recruitment' ),
        'services'       => __( 'Services', 'hiregen-recruitment' ),
        'why'            => __( 'Why', 'hiregen-recruitment' ),
        'projects'       => __( 'Projects', 'hiregen-recruitment' ),
        'testimonial'    => __( 'Testimonials', 'hiregen-recruitment' ),
        'team'           => __( 'Team', 'hiregen-recruitment' ),
        'faq'            => __( 'FAQ', 'hiregen-recruitment' ),
        'blog'           => __( 'Blog', 'hiregen-recruitment' ),
        'contact'        => __( 'Contact', 'hiregen-recruitment' ),
    );

    // Register the setting that stores the order as comma separated slugs
    $default_order = implode( ',', array_keys( $sections ) );

    $wp_customize->add_setting( 'hiregen_section_order', array(
        'default'           => $default_order,
        'sanitize_callback' => 'hiregen_sanitize_section_order',
    ) );

    // If your 'Display Features' is a section or panel, add the control under it.
    // We assume you added a panel with id 'hiregen_display_features'; use that section if you prefer.
    $wp_customize->add_control( new Hiregen_Customize_Sortable_Control( $wp_customize, 'hiregen_section_order', array(
        'label'       => __( 'Homepage sections order', 'hiregen-recruitment' ),
        'description' => __( 'Drag to reorder homepage sections. Use the Display Features checkboxes to show/hide each section.', 'hiregen-recruitment' ),
        'section'     => 'hiregen_display_toggle_section', // or place it under 'hiregen_display_features' or a dedicated section. Adjust if needed.
        'settings'    => 'hiregen_section_order',
        'choices'     => $sections,
        'priority'    => 1,
    ) ) );
}
add_action( 'customize_register', 'hiregen_customize_register_sortable', 20 );

/**
 * Sanitize stored order - keep only known slugs and return as comma separated string.
 */
function hiregen_sanitize_section_order( $value ) {
    if ( ! is_string( $value ) ) {
        return '';
    }

    $allowed = array(
        'hero','featured_logos','jobs','our_products','pricing','services','why','projects','testimonial','team','faq','blog','contact'
    );

    $parts = array_filter( array_map( 'trim', explode( ',', $value ) ) );

    // Keep only allowed and unique, preserve order
    $out = array();
    foreach ( $parts as $p ) {
        if ( in_array( $p, $allowed, true ) && ! in_array( $p, $out, true ) ) {
            $out[] = $p;
        }
    }

    // Append any missing allowed sections at end (preserve default completeness)
    foreach ( $allowed as $a ) {
        if ( ! in_array( $a, $out, true ) ) {
            $out[] = $a;
        }
    }

    return implode( ',', $out );
}

/**
 * Enqueue control JS + CSS for the Customizer controls pane
 */
function hiregen_customize_controls_enqueue() {
    $js_file = get_template_directory() . '/assets/js/customize-controls.js';
    $css_file = get_template_directory() . '/assets/css/customize-controls.css';
    $ver_js  = file_exists( $js_file ) ? filemtime( $js_file ) : null;
    $ver_css = file_exists( $css_file ) ? filemtime( $css_file ) : null;

    wp_enqueue_script( 'hiregen-customize-controls', get_template_directory_uri() . '/assets/js/customize-controls.js', array( 'jquery', 'jquery-ui-sortable', 'customize-controls' ), $ver_js, true );
    wp_enqueue_style( 'hiregen-customize-controls-css', get_template_directory_uri() . '/assets/css/customize-controls.css', array(), $ver_css );
}
add_action( 'customize_controls_enqueue_scripts', 'hiregen_customize_controls_enqueue' );


if ( ! function_exists( 'hiregen_get_selected_google_fonts' ) ) {
    function hiregen_get_selected_google_fonts() {
        $body_font     = get_theme_mod( 'hiregen_font_body', '' );
        $headings_font = get_theme_mod( 'hiregen_font_headings', '' );
        $button_font   = get_theme_mod( 'hiregen_button_font', '' );

        $extract = function( $font_string ) {
            if ( empty( $font_string ) ) {
                return '';
            }
            $parts = explode( ',', $font_string );
            $first = trim( $parts[0], "\"' " );
            if ( $first === '' || strtolower( $first ) === 'default (system)' ) {
                return '';
            }
            return $first;
        };

        $fonts = array();

        $f1 = $extract( $body_font );
        if ( $f1 ) $fonts[] = $f1;

        $f2 = $extract( $headings_font );
        if ( $f2 ) $fonts[] = $f2;

        $f3 = $extract( $button_font );
        if ( $f3 ) $fonts[] = $f3;

        $fonts = array_values( array_unique( array_filter( $fonts ) ) );

        return $fonts;
    }
}

if ( ! function_exists( 'hiregen_build_google_fonts_url' ) ) {
    function hiregen_build_google_fonts_url( $fonts = array() ) {
        if ( empty( $fonts ) ) {
            return '';
        }
        $families = array_map( function( $f ) {
            $name = str_replace( ' ', '+', trim( $f ) );
            return $name . ':wght@300;400;500;600;700';
        }, $fonts );

        $query = http_build_query( array(
            'family'  => implode( '&family=', $families ),
            'display' => 'swap',
        ) );

        return 'https://fonts.googleapis.com/css2?' . $query;
    }
}

if ( ! function_exists( 'hiregen_enqueue_selected_fonts_with_cpts' ) ) {
    function hiregen_enqueue_selected_fonts_with_cpts() {
        $fonts = hiregen_get_selected_google_fonts();
        if ( empty( $fonts ) ) {
            return;
        }

        $fonts_url = hiregen_build_google_fonts_url( $fonts );
        if ( ! $fonts_url ) {
            return;
        }

        wp_register_style( 'hiregen-google-fonts', $fonts_url, array(), null );
        wp_enqueue_style( 'hiregen-google-fonts' );

        // read stacks (exact stacks saved in Customizer)
        $body_stack     = get_theme_mod( 'hiregen_font_body', '' );
        $headings_stack = get_theme_mod( 'hiregen_font_headings', '' );
        $button_stack   = get_theme_mod( 'hiregen_button_font', '' );

        $use_important = true; // ensure button font wins over Bootstrap
        $imp = $use_important ? ' !important' : '';

        $custom_css = '';

        // Body stack *must not include* button selectors
        if ( $body_stack ) {
            $custom_css .= sprintf(
                "body, p, li, a, span, label, input, select, textarea { font-family: %s%s; }\n",
                esc_attr( $body_stack ), $imp
            );
        }

        if ( $headings_stack ) {
            $custom_css .= sprintf(
                "h1,h2,h3,h4,h5,h6 { font-family: %s%s; }\n",
                esc_attr( $headings_stack ), $imp
            );
        }

        // Button stack: target bootstrap .btn, inputs, and links with btn class
        if ( $button_stack ) {
            $custom_css .= sprintf(
                "button, input[type=button], input[type=submit], .btn, a.btn { font-family: %s !important; }\n",
                esc_attr( $button_stack )
            );
        }

        if ( $custom_css ) {
            // try to attach to theme main handle, fallback to google-fonts handle
            if ( wp_style_is( 'hiregen-style', 'enqueued' ) || wp_style_is( 'hiregen-style', 'registered' ) ) {
                wp_add_inline_style( 'hiregen-style', $custom_css );
            } else {
                wp_add_inline_style( 'hiregen-google-fonts', $custom_css );
            }
        }
    }
    add_action( 'wp_enqueue_scripts', 'hiregen_enqueue_selected_fonts_with_cpts', 25 );
}

/**
 * Create default About Us page on theme activation, and set customizer value.
 */
function hiregen_create_default_about_page_on_activation() {
    // only run when a theme is being activated
    if ( ! current_user_can( 'activate_plugins' ) && ! current_user_can( 'manage_options' ) ) {
        // permission check (shouldn't normally fire during activation)
    }

    // desired slug & title
    $slug  = 'about-us';
    $title = __( 'About Us', 'hiregen-recruitment' );

    // If a page with this slug already exists, do nothing
    if ( get_page_by_path( $slug, OBJECT, 'page' ) ) {
        // Page already exists; ensure theme mod points to that page URL if not set
        $existing_page = get_page_by_path( $slug, OBJECT, 'page' );
        if ( $existing_page ) {
            $current = get_theme_mod( 'hiregen_why_btn_url', '' );
            if ( empty( $current ) ) {
                set_theme_mod( 'hiregen_why_btn_url', get_permalink( $existing_page->ID ) );
            }
        }
        return;
    }

    // Create the page
    $page_id = wp_insert_post( array(
        'post_title'   => wp_strip_all_tags( $title ),
        'post_name'    => $slug,
        'post_content' => '', // optionally add default content here
        'post_status'  => 'publish',
        'post_type'    => 'page',
        'post_author'  => get_current_user_id() ?: 1,
    ) );

    // If created, set the Customizer URL to that new page
    if ( $page_id && ! is_wp_error( $page_id ) ) {
        $permalink = get_permalink( $page_id );
        // Only set the theme_mod if user hasn't already set a custom url
        $existing = get_theme_mod( 'hiregen_why_btn_url', '' );
        if ( empty( $existing ) ) {
            set_theme_mod( 'hiregen_why_btn_url', $permalink );
        }
    }
}

// Hook to after_switch_theme to run when the theme is activated
add_action( 'after_switch_theme', 'hiregen_create_default_about_page_on_activation' );



/**
 * Ensure hiregen_why_btn_url has a sensible default after theme activation
 * - If the theme_mod is empty, try to resolve an existing 'about-us' page and set its permalink
 * - If no page found, set default to home_url('/about-us/')
 */
/**
 * Ensure hiregen_why_btn_url has a sensible default if not set.
 */
function hiregen_ensure_about_btn_default() {
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $mod_key = 'hiregen_why_btn_url';
    $existing = get_theme_mod( $mod_key, '' );

    if ( ! empty( $existing ) ) {
        return; // user already set it
    }

    // Prefer an existing page with slug 'about-us'
    $page = get_page_by_path( 'about-us', OBJECT, 'page' );

    if ( $page ) {
        $url = get_permalink( $page->ID );
    } else {
        $url = home_url( '/about-us/' );
    }

    // Save default only if still empty
    if ( empty( $existing ) ) {
        set_theme_mod( $mod_key, esc_url_raw( $url ) );
    }
}
add_action( 'admin_init', 'hiregen_ensure_about_btn_default', 20 );



// functions.php
// --------------
// Add this to persist default Customizer values on theme activation.

/**
 * Persist sensible Customizer defaults on theme activation for homepage sections.
 * This only sets values if the theme_mod is not already present (non-destructive).
 */
function hiregen_set_defaults_on_activation() {

    // helper: set theme_mod only when empty / not set
    $set_if_empty = function( $key, $value ) {
        $current = get_theme_mod( $key, false );
        if ( $current === false || $current === '' ) {
            set_theme_mod( $key, $value );
        }
    };

    // 2) WP Jobs section
    $set_if_empty( 'hiregen_jobs_subtitle', __( 'Job Openings', 'hiregen-recruitment' ) );
    $set_if_empty( 'hiregen_jobs_title', __( 'Find the role that advances your career', 'hiregen-recruitment' ) );
    $set_if_empty( 'hiregen_jobs_description', __( 'Browse verified roles updated for you today.', 'hiregen-recruitment' ) );

    // 3) Our Products section - support both 'products' and 'our_products' key variants
    $set_if_empty( 'hiregen_products_subtitle', __( 'Our Products', 'hiregen-recruitment' ) );
    $set_if_empty( 'hiregen_products_description', __( 'Explore our featured products and solutions designed to help your business grow.', 'hiregen-recruitment' ) );
    $set_if_empty( 'hiregen_our_products_subtitle', __( 'Our Products', 'hiregen-recruitment' ) );
    $set_if_empty( 'hiregen_our_products_description', __( 'Explore our featured products and solutions designed to help your business grow.', 'hiregen-recruitment' ) );

    // 4) Our Services section
    $set_if_empty( 'hiregen_services_subtitle', __( 'Our Services', 'hiregen-recruitment' ) );
    $set_if_empty( 'hiregen_services_description', __( 'Delivering expert services to accelerate your hiring and HR processes.', 'hiregen-recruitment' ) );

    // 5) Who we are (Why section)
    $set_if_empty( 'hiregen_why_subtitle', __( 'Who we are', 'hiregen-recruitment' ) );
    $set_if_empty( 'hiregen_why_title', __( 'Hire the best for your team', 'hiregen-recruitment' ) );
    $set_if_empty( 'hiregen_why_description', __( 'We connect companies with top talent quickly and reliably—powered by recruitment-first technology and human expertise.', 'hiregen-recruitment' ) );

    // 6) Projects section
    $set_if_empty( 'hiregen_projects_subtitle', __( 'Our Projects', 'hiregen-recruitment' ) );
    $set_if_empty( 'hiregen_projects_description', __( 'A selection of projects and case studies that showcase our work and results.', 'hiregen-recruitment' ) );

    // 7) Testimonial section
    $set_if_empty( 'hiregen_testimonial_subtitle', __( 'Testimonials', 'hiregen-recruitment' ) );
    $set_if_empty( 'hiregen_testimonial_description', __( 'What our clients say — real feedback from happy employers and candidates.', 'hiregen-recruitment' ) );

    // 8) Team section
    $set_if_empty( 'hiregen_team_subtitle', __( 'Our Team', 'hiregen-recruitment' ) );
    $set_if_empty( 'hiregen_team_description', __( 'Meet the people behind our recruitment solutions—experienced, dedicated, and supportive.', 'hiregen-recruitment' ) );

    // 9) FAQ section
    $set_if_empty( 'hiregen_faq_subtitle', __( 'Frequently Asked Questions', 'hiregen-recruitment' ) );
    $set_if_empty( 'hiregen_faq_description', __( 'Answers to common questions about our services, the hiring process, and how to get started.', 'hiregen-recruitment' ) );

    // 10) Blog section (only subtitle explicitly requested)
    $set_if_empty( 'hiregen_blog_subtitle', __( 'Our Blog', 'hiregen-recruitment' ) );
    // also ensure blog title and description are present if templates expect them
    $set_if_empty( 'hiregen_blog_title', __( 'Our Blog', 'hiregen-recruitment' ) );
    $set_if_empty( 'hiregen_blog_description', __( 'Industry insights, hiring tips, and product updates.', 'hiregen-recruitment' ) );

    // Jobs button fallback (already exists in customizer but ensure present)
    $set_if_empty( 'hiregen_jobs_button_text', __( 'See all jobs', 'hiregen-recruitment' ) );

    // Who we are "About" button fallback (existing code sets this too but double-check)
    $current_about = get_theme_mod( 'hiregen_why_btn_url', '' );
    if ( empty( $current_about ) ) {
        // prefer an existing 'about-us' page if present, otherwise keep '/about-us/'
        $page = get_page_by_path( 'about-us', OBJECT, 'page' );
        if ( $page ) {
            set_theme_mod( 'hiregen_why_btn_url', get_permalink( $page->ID ) );
        } else {
            set_theme_mod( 'hiregen_why_btn_url', home_url( '/about-us/' ) );
        }
    }
}
add_action( 'after_switch_theme', 'hiregen_set_defaults_on_activation' );


/**
 * Auto-create a "Blog" page on theme activation and set it as the posts page.
 * This prevents /blog/ 404s and gives the section button a valid archive target.
 */
function hiregen_create_blog_page_on_activation() {
    // run only when a privileged user activates theme
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    // If a page with slug 'blog' already exists, ensure it's set as the posts page
    $existing = get_page_by_path( 'blog', OBJECT, 'page' );
    if ( $existing ) {
        $current_posts_page = (int) get_option( 'page_for_posts' );
        if ( $current_posts_page <= 0 || $current_posts_page !== (int) $existing->ID ) {
            update_option( 'page_for_posts', (int) $existing->ID );
        }
        return;
    }

    // Create the Blog page
    $blog_page = array(
        'post_title'   => wp_strip_all_tags( __( 'Blog', 'hiregen-recruitment' ) ),
        'post_name'    => 'blog', // slug
        'post_content' => __( 'Welcome to our blog. Here you will find the latest posts.', 'hiregen-recruitment' ),
        'post_status'  => 'publish',
        'post_type'    => 'page',
        'post_author'  => get_current_user_id() ? get_current_user_id() : 1,
    );

    $page_id = wp_insert_post( $blog_page );

    if ( ! is_wp_error( $page_id ) && $page_id ) {
        // Set created page as the Posts page (so WP will use it for the posts index)
        update_option( 'page_for_posts', (int) $page_id );
    }
}
add_action( 'after_switch_theme', 'hiregen_create_blog_page_on_activation' );

/* ---------------------------
 * End of customizer file
 * --------------------------- */
/**
 * Enqueue Bootstrap (if not already) and navbar JS fix.
 * Put this in inc/enqueue.php inside your existing enqueue function,
 * or append to functions.php if you must.
 */
function hiregen_enqueue_navbar_fix() {
    $theme_version = wp_get_theme()->get( 'Version' );

    // 1) Bootstrap CSS - only if not already enqueued by theme
    if ( ! wp_style_is( 'bootstrap', 'enqueued' ) ) {
        // Allow child themes / plugins to override CDN or use local copy via filter
        $bootstrap_cdn = apply_filters( 'hiregen_bootstrap_cdn', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' );
        wp_enqueue_style(
            'bootstrap',
            esc_url_raw( $bootstrap_cdn ),
            array(),
            '5.3.2'
        );
        // NOTE: For theme review and offline installs you should bundle a local copy at
        // assets/css/bootstrap.min.css and provide a filter to use it instead.
    }

    // 2) Ensure your main theme stylesheet is enqueued (if not already)
    if ( ! wp_style_is( 'hiregen-style', 'enqueued' ) ) {
        wp_enqueue_style(
            'hiregen-style',
            get_stylesheet_uri(),
            array( 'bootstrap' ),
            $theme_version
        );
    }

    // 4) Enqueue the navbar fix JS you uploaded (depends on bootstrap JS)
    // Only enqueue if file exists in theme assets; use get_stylesheet_directory_uri() and escape URL
    if ( file_exists( get_stylesheet_directory() . '/assets/js/navbar-dropdown-fix.js' ) ) {
        wp_enqueue_script(
            'hiregen-navbar-fix',
            esc_url_raw( get_stylesheet_directory_uri() . '/assets/js/navbar-dropdown-fix.js' ),
            array( 'bootstrap' ),
            $theme_version,
            true
        );
    }
}
add_action( 'wp_enqueue_scripts', 'hiregen_enqueue_navbar_fix', 20 );


/**
 * Add Bootstrap nav classes to menu li and links when walker not used.
 */
function hiregen_nav_menu_link_atts( $atts, $item, $args, $depth ) {
    // If the menu is used in the primary location (or has class 'navbar-nav'), add nav-link
    if ( isset( $args->theme_location ) && 'primary' === $args->theme_location ) {
        $atts['class'] = isset( $atts['class'] ) ? $atts['class'] . ' nav-link' : 'nav-link';
    }
    return $atts;
}
add_filter( 'nav_menu_link_attributes', 'hiregen_nav_menu_link_atts', 10, 4 );

function hiregen_nav_menu_item_classes( $classes, $item, $args, $depth ) {
    if ( isset( $args->theme_location ) && 'primary' === $args->theme_location ) {
        // ensure top-level items have nav-item (do not duplicate)
        if ( ! in_array( 'nav-item', $classes ) ) {
            $classes[] = 'nav-item';
        }
        // keep menu-item-has-children because our JS/CSS use it
    }
    return $classes;
}
add_filter( 'nav_menu_css_class', 'hiregen_nav_menu_item_classes', 10, 4 );

/**
 * Temporary: ensure /testimonials/ route works and uses archive-hiregen_testimonial.php
 * Paste into your theme functions.php (remove after debugging / once fixed).
 */

// 1) Add rewrite rule for /testimonials/
add_action( 'init', function() {
    add_rewrite_rule( '^testimonials/?$', 'index.php?post_type=hiregen_testimonial', 'top' );
});

// 2) Flush rewrite rules once (safe: uses transient so it only runs one time)
add_action( 'init', function() {
    if ( ! get_option( 'hiregen_testimonials_rewrite_flushed' ) ) {
        flush_rewrite_rules( false );
        update_option( 'hiregen_testimonials_rewrite_flushed', 1 );
    }
});

// 3) If WP doesn't pick up the archive template, force our template for this path
add_filter( 'template_include', function( $template ) {
    // If the requested URI ends with /testimonials/ or it's a CPT archive for hiregen_testimonial
    $request_path = trim( parse_url( add_query_arg( array() ), PHP_URL_PATH ), '/' );
    $is_testimonials_uri = ( strtolower( $request_path ) === 'testimonials' || strpos( $_SERVER['REQUEST_URI'], '/testimonials' ) !== false );

    if ( $is_testimonials_uri || is_post_type_archive( 'hiregen_testimonial' ) ) {
        // prefer theme archive file
        $theme_template = locate_template( 'archive-hiregen_testimonial.php' );
        if ( $theme_template ) {
            return $theme_template;
        }

        // fallback: use a minimal built-in template (inline)
        add_action( 'wp', function() {
            // nothing here — continue to template_include below
        } );

        // let WordPress continue if no theme file found
    }

    return $template;
}, 99 );

function hiregen_apply_customizer_colors() {
    // Read values from Customizer (fallback to sensible defaults)
    $primary    = get_theme_mod( 'hiregen_color_primary', '#6f42c1' );
    $secondary  = get_theme_mod( 'hiregen_color_secondary', '#6c757d' );
    $link       = get_theme_mod( 'hiregen_color_link', '#6f42c1' );
    $headings   = get_theme_mod( 'hiregen_heading_color', '#222222' );
    $text       = get_theme_mod( 'hiregen_text_color', '#666666' );
    $background = get_theme_mod( 'hiregen_background_color', '#ffffff' ); // <-- new

    // Sanitize the values (hex colors expected)
    $primary    = sanitize_hex_color( $primary ) ?: '#6f42c1';
    $secondary  = sanitize_hex_color( $secondary ) ?: '#6c757d';
    $link       = sanitize_hex_color( $link ) ?: '#6f42c1';
    $headings   = sanitize_hex_color( $headings ) ?: '#222222';
    $text       = sanitize_hex_color( $text ) ?: '#666666';
    $background = sanitize_hex_color( $background ) ?: '#ffffff';

    // Build CSS - uses CSS variables and some direct color rules for reliability
    $custom_css = "
    /* Customizer dynamic colors - generated by hiregen_apply_customizer_colors() */
    :root {
      --hiregen-primary: {$primary};
      --hiregen-secondary: {$secondary};
      --hiregen-link: {$link};
      --hiregen-heading: {$headings};
      --hiregen-text: {$text};
      --hiregen-background: {$background};
    }

    /* Apply background color to body and main containers (important to override other styles) */
    body {
      background-color: var(--hiregen-background) !important;
      /* keep background-image options if any later */
    }

    /* Basic usage (guarantee important rules for UI elements) */
    a, a:visited { color: var(--hiregen-link); }
    a:hover, a:focus { color: var(--hiregen-primary); }

    h1,h2,h3,h4,h5,h6 { color: var(--hiregen-heading); }
    body, p, li, span { color: var(--hiregen-text); }

    /* Buttons/CTAs */
    .btn-primary, .btn-primary:visited {
      background-color: var(--hiregen-primary)!important;
      border-color: var(--hiregen-primary)!important;
      border-width: 2px!important;
      color: #ffffff;
      border-radius: 4px!important;
    }

    /* keep your other rules (copied from original) */
    .btn-primary:hover {
      background-color: color-mix(in srgb, var(--hiregen-primary) 80%, transparent) !important;
      border-color: var(--hiregen-primary) !important;
      border-width: 2px !important;
      color: #ffffff;
      border-radius: 4px !important;
    }
    .btn-outline-secondary, .btn-outline-secondary:visited {
      background-color: transparent!important;
      border-color: var(--hiregen-secondary)!important;
      color: var(--hiregen-secondary)!important;
      border-width: 2px!important;
      border-radius: 4px!important;
    }
    .btn-outline-secondary:hover {
      background-color: color-mix(in srgb, var(--hiregen-secondary) 15%, transparent) !important;
      border-color: var(--hiregen-secondary) !important;
      color: var(--hiregen-secondary) !important;
      border-width: 2px !important;
      border-radius: 4px !important;
    }

    .site-header .btn.btn-primary { background-color: var(--hiregen-primary); border-color: rgba(0,0,0,0.05); }
    .navbar .nav-link { color: var(--hiregen-text) !important; }
    .navbar .nav-link:hover, .navbar .nav-link:focus { color: var(--hiregen-primary) !important; }
    .navbar .dropdown-item { color: var(--hiregen-text) !important; }
    .navbar .dropdown-item:hover { color: var(--hiregen-primary) !important; }
    ";

    // Attach inline style to main theme stylesheet handle (use hiregen-style if present)
    $main_handle = false;
    if ( wp_style_is( 'hiregen-style', 'registered' ) || wp_style_is( 'hiregen-style', 'enqueued' ) ) {
        $main_handle = 'hiregen-style';
    } elseif ( wp_style_is( 'style', 'registered' ) ) {
        $main_handle = 'style';
    } elseif ( wp_style_is( 'theme-style', 'registered' ) ) {
        $main_handle = 'theme-style';
    } else {
        $main_handle = 'wp-block-library';
    }

    if ( $main_handle ) {
        wp_add_inline_style( $main_handle, $custom_css );
    } else {
        add_action( 'wp_head', function() use ( $custom_css ) {
            echo "<style type=\"text/css\">{$custom_css}</style>";
        }, 999 );
    }
}
add_action( 'wp_enqueue_scripts', 'hiregen_apply_customizer_colors', 40 );


/**
 * Serve a posts archive at /blog/ without creating a Page.
 * Adds a rewrite rule, query var and template redirect that loads the theme's home/index template.
 */
function hiregen_blog_virtual_rewrite() {
    add_rewrite_rule( '^blog/page/([0-9]+)/?$', 'index.php?is_blog=1&paged=$matches[1]', 'top' );
    add_rewrite_rule( '^blog/?$', 'index.php?is_blog=1', 'top' );
}
add_action( 'init', 'hiregen_blog_virtual_rewrite' );

function hiregen_blog_query_vars( $vars ) {
    $vars[] = 'is_blog';
    return $vars;
}
add_filter( 'query_vars', 'hiregen_blog_query_vars' );

function hiregen_blog_template_redirect() {
    if ( get_query_var( 'is_blog' ) ) {
        // Build the main query for posts (so theme templates behave normally)
        $paged = max( 1, get_query_var( 'paged' ) ? intval( get_query_var( 'paged' ) ) : 1 );
        $posts_per_page = (int) get_option( 'posts_per_page', 10 );

        // Replace global main query with posts query
        global $wp_query;
        $wp_query = new WP_Query( array(
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => $posts_per_page,
            'paged'          => $paged,
        ) );

        // Mark query flags so templates treat this as the posts index
        $wp_query->is_home = true;
        $wp_query->is_archive = false;
        $wp_query->is_post_type_archive = false;

        // Load home.php if present, otherwise load index.php
        $template = locate_template( array( 'home.php', 'index.php' ) );
        if ( $template ) {
            include $template;
            exit; // done — we've output the archive
        }

        // Safety fallback — if no template found, do nothing (WP will 404)
    }
}
add_action( 'template_redirect', 'hiregen_blog_template_redirect', 0 );

// Footer bottom links widget area
function hiregen_footer_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Footer Bottom Links', 'hiregen-recruitment' ),
        'id'            => 'footer-bottom',
        'description'   => __( 'Add links like Terms, Privacy, Sitemap here.', 'hiregen-recruitment' ),
        'before_widget' => '<div class="footer-bottom-widget">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title text-white mb-4">',
        'after_title'   => '</h4>',
    ) );
}
add_action( 'widgets_init', 'hiregen_footer_widgets_init' );


/**
 * Register custom block styles and enqueue their CSS.
 * Put this in functions.php or include as inc/block-styles.php
 */

function hiregen_register_block_styles() {
    // Only run if WP supports block styles (WP 5.3+)
    if ( ! function_exists( 'register_block_style' ) ) {
        return;
    }

    // Example: Add an "Outline" style to the Button block.
    register_block_style(
        'core/button',
        array(
            'name'  => 'outline',
            'label' => __( 'Outline', 'hiregen-recruitment' ),
        )
    );

    // Example: Add a "Muted" style to Quote block.
    register_block_style(
        'core/quote',
        array(
            'name'  => 'muted',
            'label' => __( 'Muted', 'hiregen-recruitment' ),
        )
    );

    // Example: Add a compact style to core/group (optional)
    register_block_style(
        'core/group',
        array(
            'name'  => 'compact',
            'label' => __( 'Compact', 'hiregen-recruitment' ),
        )
    );
}
add_action( 'init', 'hiregen_register_block_styles' );


/**
 * Enqueue block styles CSS for both front-end and editor.
 */
// load patterns CSS for editor + frontend
function hiregen_enqueue_pattern_styles() {
    if ( file_exists( get_template_directory() . '/assets/css/patterns.css' ) ) {
        wp_enqueue_style(
            'hiregen-patterns',
            get_template_directory_uri() . '/assets/css/patterns.css',
            array(),
            filemtime( get_template_directory() . '/assets/css/patterns.css' )
        );
    }
}
add_action( 'enqueue_block_assets', 'hiregen_enqueue_pattern_styles' );

function hiregen_enqueue_job_single_styles() {
    wp_enqueue_style( 'hiregen-job-single', get_stylesheet_directory_uri() . '/assets/css/job-single.css', array(), '1.0' );
}
add_action( 'wp_enqueue_scripts', 'hiregen_enqueue_job_single_styles' );


/**
 * Enqueue the core 'comment-reply' script when threaded comments are enabled.
 */
function hiregen_enqueue_comment_reply_script() {
    // Only load on singular pages where comments are open and threaded comments are enabled.
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'hiregen_enqueue_comment_reply_script' );

// Recommend Hiregen CPTs plugin (simple admin notice)
function hiregen_admin_notice_recommend_cpts() {
    if ( ! current_user_can( 'install_plugins' ) ) {
        return;
    }

    // Path to plugin file once installed: hiregen-cpts/hiregen-cpts.php
    if ( ! is_plugin_active( 'hiregen-cpts/hiregen-cpts.php' ) ) {
        $plugin_url = 'https://wpnova.com/wp-content/uploads/hiregen-cpts.zip'; // your hosted URL or GitHub release page
        printf(
            '<div class="notice notice-warning is-dismissible"><p>%1$s <a href="%2$s" target="_blank" rel="noopener noreferrer">%3$s</a></p></div>',
            esc_html__( 'For full Hiregen theme functionality (custom content types), please install the', 'hiregen-recruitment' ),
            esc_url( $plugin_url ),
            esc_html__( 'Hiregen CPTs plugin', 'hiregen-recruitment' )
        );
    }
}
add_action( 'admin_notices', 'hiregen_admin_notice_recommend_cpts' );

function hiregen_subheader_custom_styles() {
    $bgcolor    = get_theme_mod( 'hiregen_subheader_bgcolor', '#6f42c1' );
    $bgimage    = get_theme_mod( 'hiregen_subheader_bgimage' );
    $fontcolor  = get_theme_mod( 'hiregen_subheader_fontcolor', '#ffffff' );
    $breadtext  = get_theme_mod( 'hiregen_subheader_breadcrumb_textcolor', '#cccccc' );
    $breadlink  = get_theme_mod( 'hiregen_subheader_breadcrumb_linkcolor', '#ffffff' );

    $styles = '';
    if ( $bgcolor ) {
        $styles .= "background-color: " . esc_attr( $bgcolor ) . "; ";
    }
    if ( $bgimage ) {
        $styles .= "background-image: url('" . esc_url( $bgimage ) . "'); background-size: cover; background-position: center; ";
    }
    if ( $fontcolor ) {
        $styles .= "color: " . esc_attr( $fontcolor ) . "; ";
    }

    if ( ! empty( $styles ) ) {
        echo "<style type='text/css'>\n";
        echo ".sub-header { {$styles} }\n";
        echo ".sub-header h1.entry-title { color: {$fontcolor} !important; }\n";
        echo ".sub-header .breadcrumb, span { color: {$breadtext}; }\n";
        echo ".sub-header .breadcrumb a { color: {$breadlink}; }\n";
        echo "</style>\n";
    }
}
add_action( 'wp_head', 'hiregen_subheader_custom_styles' );

/**
 * Show an informational notice at the top of the WP Job Manager "Post a job" form.
 * Place this in your theme's functions.php (or a loaded include).
 */
add_action( 'submit_job_form_start', 'hiregen_post_job_form_notice', 5 );
function hiregen_post_job_form_notice() {

	// Customize these strings and URL as needed
	$contact_url  = esc_url( home_url( '/contact/' ) ); // ✅ use home_url() instead of site_url()
	$contact_html = '<a href="' . $contact_url . '">' . esc_html__( 'contact us', 'hiregen-recruitment' ) . '</a>';

	// Message for visitors (not logged in)
	if ( ! is_user_logged_in() ) {
		/* translators: %s: contact link */
		$msg = sprintf(
			/* translators: notice shown to guests on the job submission form */
			esc_html__( 'Your job submission will be reviewed and published by site administrators. If you have any questions, please %s.', 'hiregen-recruitment' ),
			$contact_html
		);

		echo '<div class="alert alert-info" role="alert">' . wp_kses_post( $msg ) . '</div>';
		return;
	}

	// For logged-in users who are NOT administrators
	if ( ! current_user_can( 'manage_options' ) ) {
		/* translators: %s: contact link */
		$msg = sprintf(
			esc_html__( 'Your job submission will be reviewed and published by site administrators. If you have any questions, please %s.', 'hiregen-recruitment' ),
			$contact_html
		);

		echo '<div class="hiregen-jobform-notice hiregen-jobform-notice-loggedin" role="status">' . wp_kses_post( $msg ) . '</div>';
		return;
	}

	// For administrators (optional short notice)
	$msg = esc_html__( 'You are posting as an administrator; jobs you publish will appear immediately.', 'hiregen-recruitment' );
	echo '<div class="hiregen-jobform-notice hiregen-jobform-notice-admin" style="display:none" role="status">' . esc_html( $msg ) . '</div>';
}

/**
 * Set a transient when job submitted; show it once on the form page.
 */

/* Helper: safe remote IP retrieval */
if ( ! function_exists( 'hiregen_get_sanitized_remote_addr' ) ) {
	function hiregen_get_sanitized_remote_addr() {
		$remote_addr = '';
		if ( isset( $_SERVER['REMOTE_ADDR'] ) ) {
			// wp_unslash in case WP or server added slashes; sanitize_text_field to be conservative
			$remote_addr = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
		}
		return $remote_addr;
	}
}

/* 1) After job submits, set a short transient keyed to current user or session */
add_action( 'job_manager_job_submitted', 'hiregen_job_submitted_set_transient', 10, 1 );
function hiregen_job_submitted_set_transient( $job_id ) {
	// Build a key - prefer user ID for logged-in users else use ip+site salt
	if ( is_user_logged_in() ) {
		$key = 'hiregen_job_submitted_uid_' . absint( get_current_user_id() );
	} else {
		$remote_addr = hiregen_get_sanitized_remote_addr();
		$key         = 'hiregen_job_submitted_ip_' . md5( $remote_addr . wp_salt() );
	}

	// Set transient for 2 minutes (120 seconds)
	set_transient( $key, 1, 120 );
}

/**
 * Redirect to Job Dashboard after the front-end submission completes.
 */
add_action( 'job_manager_job_submitted', function( $job_id ) {
	// Preferred: WP Job Manager option (set when you created the Job Dashboard page)
	$dashboard_id  = get_option( 'job_manager_job_dashboard_page_id' );
	$dashboard_url = '';

	if ( $dashboard_id ) {
		$dashboard_url = get_permalink( absint( $dashboard_id ) );
	}

	// Fallback to slug if option not set
	if ( ! $dashboard_url ) {
		$page = get_page_by_path( 'job-dashboard' );
		if ( $page && isset( $page->ID ) ) {
			$dashboard_url = get_permalink( absint( $page->ID ) );
		}
	}

	// Only redirect if we have a valid URL
	if ( $dashboard_url ) {
		// Ensure URL is safe for redirect
		$dashboard_url_safe = esc_url_raw( $dashboard_url );
		if ( $dashboard_url_safe ) {
			wp_safe_redirect( $dashboard_url_safe );
			exit;
		}
	}
}, 999 );


/* 2) Show the notice at form start if transient found, then delete it */
add_action( 'submit_job_form_start', 'hiregen_show_job_submitted_notice_transient', 6 );
function hiregen_show_job_submitted_notice_transient() {
	if ( is_user_logged_in() ) {
		$key = 'hiregen_job_submitted_uid_' . absint( get_current_user_id() );
	} else {
		$remote_addr = hiregen_get_sanitized_remote_addr();
		$key         = 'hiregen_job_submitted_ip_' . md5( $remote_addr . wp_salt() );
	}

	// Use get_transient once and store the result
	$transient_value = get_transient( $key );
	if ( $transient_value ) {
		/* translators: Message shown after successfully submitting a job */
		$msg = __( 'Thank you — your job has been submitted. An administrator will review and publish it shortly.', 'hiregen-recruitment' );

		// Output safe HTML wrapper with escaped text
		echo '<div class="alert alert-success hiregen-job-submitted-notice" role="alert">' . esc_html( $msg ) . '</div>';

		// delete so it shows only once
		delete_transient( $key );
	}
}


/**
 * Remove unwanted default WordPress Customizer sections
 */
function hiregen_remove_default_customizer_sections( $wp_customize ) {
    
    // Remove core sections
    $wp_customize->remove_section( 'title_tagline' );      // Site Identity
    $wp_customize->remove_section( 'colors' );             // Colors
    $wp_customize->remove_section( 'header_image' );       // Header Image
    $wp_customize->remove_section( 'background_image' );   // Background Image

    // Optional: also remove other unused panels if needed
    // $wp_customize->remove_panel( 'nav_menus' );        // Menus
    // $wp_customize->remove_panel( 'widgets' );          // Widgets
}

add_action( 'customize_register', 'hiregen_remove_default_customizer_sections', 30 );

// === Simple XML Sitemap ===
function hiregen_generate_sitemap() {
    // Only run if ?generate_sitemap=1 is present — sanitize input
    if ( ! isset( $_GET['generate_sitemap'] ) ) {
        return;
    }
    $generate = sanitize_text_field( wp_unslash( $_GET['generate_sitemap'] ) );
    if ( '1' !== $generate ) {
        return;
    }

    // Send XML headers
    header( 'Content-Type: application/xml; charset=utf-8' );

    $posts = get_posts( array(
        'numberposts' => -1,
        'post_type'   => array( 'page', 'post', 'job_listing', 'hiregen_product' ),
        'post_status' => 'publish',
    ) );

    echo '<?xml version="1.0" encoding="UTF-8"?>';
    echo '<urlset xmlns="https://www.sitemaps.org/schemas/sitemap/0.9">';

    foreach ( $posts as $p ) {
        $loc     = esc_url( get_permalink( $p->ID ) );
        $lastmod = esc_html( get_the_modified_time( 'c', $p->ID ) );

        echo '<url>';
        echo '<loc>' . $loc . '</loc>';
        echo '<lastmod>' . $lastmod . '</lastmod>';
        echo '</url>';
    }

    echo '</urlset>';
    exit;
}
add_action( 'init', 'hiregen_generate_sitemap' );

/**
 * Hiregen: meta + social tags with social image handling (1200x628)
 * Paste into your theme's functions.php
 */

/**
 * 1) Register social image size (1200x628 hard crop)
 */
add_action( 'after_setup_theme', function() {
    // 1200x628 is recommended for social previews (Facebook, LinkedIn, Twitter)
    add_image_size( 'hiregen_social', 1200, 628, true );
} );

/**
 * 2) Helper: return social-sized image for an attachment ID.
 *    Tries to return an existing 'hiregen_social' size; if missing, attempts to create it programmatically.
 *    Returns array( 'url' => '', 'width' => int, 'height' => int ) or false on failure.
 */
function hiregen_get_social_image_for_attachment( $attachment_id ) {
    if ( empty( $attachment_id ) ) {
        return false;
    }

    // Prefer the registered size
    $img = wp_get_attachment_image_src( $attachment_id, 'hiregen_social' );
    if ( $img && ! empty( $img[0] ) ) {
        return array(
            'url'    => $img[0],
            'width'  => intval( $img[1] ),
            'height' => intval( $img[2] ),
        );
    }

    // Fallback: try 'full' and then create the social sized crop programmatically
    $full = wp_get_attachment_image_src( $attachment_id, 'full' );
    $file_path = get_attached_file( $attachment_id );

    if ( ! $file_path || ! file_exists( $file_path ) ) {
        return false;
    }

    if ( function_exists( 'wp_get_image_editor' ) ) {
        $editor = wp_get_image_editor( $file_path );
        if ( is_wp_error( $editor ) ) {
            return false;
        }

        // Resize & crop to 1200x628
        $resized = $editor->resize( 1200, 628, true );
        if ( is_wp_error( $resized ) ) {
            return false;
        }

        $saved = $editor->save(); // returns array with keys path, file, width, height, mime
        if ( is_wp_error( $saved ) ) {
            return false;
        }

        // Map saved path to URL
        $upload_dir = wp_get_upload_dir();
        if ( strpos( $saved['path'], $upload_dir['basedir'] ) === 0 ) {
            $url = str_replace( $upload_dir['basedir'], $upload_dir['baseurl'], $saved['path'] );
            return array(
                'url'    => $url,
                'width'  => isset( $saved['width'] ) ? intval( $saved['width'] ) : 1200,
                'height' => isset( $saved['height'] ) ? intval( $saved['height'] ) : 628,
            );
        }
    }

    return false;
}

/**
 * 3) Main function: outputs meta description + OpenGraph + Twitter meta tags.
 *    It uses _social_image_id -> featured image -> custom logo -> site icon as image fallbacks,
 *    and requests/creates 1200x628 social size for attachments.
 */
function hiregen_output_meta_and_social() {
    if ( is_admin() ) {
        return;
    }

    global $post;

    // DESCRIPTION: try SEO plugin meta -> excerpt -> trimmed content -> site tagline
    $desc = '';
    if ( is_singular() && isset( $post ) ) {
        $desc = get_post_meta( $post->ID, '_yoast_wpseo_metadesc', true ); // Yoast (if present)
        if ( ! $desc ) {
            $desc = get_post_meta( $post->ID, '_aioseo_description', true ); // All in One SEO (optional)
        }
        if ( ! $desc ) {
            $desc = get_the_excerpt( $post );
        }
        if ( ! $desc ) {
            $content = wp_strip_all_tags( $post->post_content );
            $desc = wp_trim_words( $content, 30, '...' );
        }
    } else {
        $desc = get_bloginfo( 'description' );
    }
    $desc = esc_attr( trim( $desc ) );

    // TITLE & URL
    if ( is_singular() && isset( $post ) ) {
        $title = get_the_title( $post );
        $url   = get_permalink( $post );
    } else {
        $title = get_bloginfo( 'name' );
        $url   = home_url();
    }
    $title = esc_attr( $title );

    // IMAGE selection: priority
    // 1) custom meta '_social_image_id' (attachment ID)
    // 2) featured image
    // 3) custom logo (theme_mod 'custom_logo')
    // 4) site icon (get_site_icon_url)
    $image_url = '';
    $image_width = '';
    $image_height = '';
    $image_alt = '';

    // helper to try attachment IDs and get social sized image
    $try_attachment = function( $att_id ) use ( &$image_url, &$image_width, &$image_height, &$image_alt ) {
        if ( ! $att_id ) {
            return false;
        }
        $social = hiregen_get_social_image_for_attachment( $att_id );
        if ( $social && ! empty( $social['url'] ) ) {
            $image_url = esc_url( $social['url'] );
            $image_width  = ! empty( $social['width'] ) ? intval( $social['width'] ) : '';
            $image_height = ! empty( $social['height'] ) ? intval( $social['height'] ) : '';
            $image_alt = get_post_meta( $att_id, '_wp_attachment_image_alt', true );
            return true;
        }
        return false;
    };

    if ( is_singular() && isset( $post ) ) {
        $custom_social_id = get_post_meta( $post->ID, '_social_image_id', true );
        if ( $custom_social_id ) {
            $try_attachment( $custom_social_id );
        }
    }

    if ( empty( $image_url ) && is_singular() && isset( $post ) && has_post_thumbnail( $post ) ) {
        $thumb_id = get_post_thumbnail_id( $post );
        if ( $thumb_id ) {
            $try_attachment( $thumb_id );
        }
    }

    if ( empty( $image_url ) ) {
        $custom_logo_id = get_theme_mod( 'custom_logo' ); // attachment id or false
        if ( $custom_logo_id ) {
            $try_attachment( $custom_logo_id );
        }
    }

    // Fallback to site icon (may be small)
    if ( empty( $image_url ) && function_exists( 'get_site_icon_url' ) ) {
        $site_icon = get_site_icon_url();
        if ( $site_icon ) {
            $image_url = esc_url( $site_icon );
            // width/height unknown for site icon
        }
    }

    // Output meta tags (head)
    echo "\n<!-- hiregen meta / social tags -->\n";
    echo '<meta name="description" content="' . $desc . '">' . "\n";

    // OpenGraph
    echo '<meta property="og:locale" content="' . esc_attr( get_locale() ) . '" />' . "\n";
    echo '<meta property="og:type" content="website" />' . "\n";
    echo '<meta property="og:title" content="' . $title . '" />' . "\n";
    echo '<meta property="og:description" content="' . $desc . '" />' . "\n";
    echo '<meta property="og:url" content="' . esc_url( $url ) . '" />' . "\n";
    echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '" />' . "\n";

    if ( $image_url ) {
        echo '<meta property="og:image" content="' . $image_url . '" />' . "\n";
        if ( $image_width ) {
            echo '<meta property="og:image:width" content="' . intval( $image_width ) . '" />' . "\n";
        }
        if ( $image_height ) {
            echo '<meta property="og:image:height" content="' . intval( $image_height ) . '" />' . "\n";
        }
        if ( $image_alt ) {
            echo '<meta property="og:image:alt" content="' . esc_attr( $image_alt ) . '" />' . "\n";
        }
        echo '<link rel="image_src" href="' . $image_url . '" />' . "\n";
    }

    // Twitter
    $twitter_card = ( $image_url ) ? 'summary_large_image' : 'summary';
    echo '<meta name="twitter:card" content="' . $twitter_card . '" />' . "\n";
    echo '<meta name="twitter:title" content="' . $title . '" />' . "\n";
    echo '<meta name="twitter:description" content="' . $desc . '" />' . "\n";
    if ( $image_url ) {
        echo '<meta name="twitter:image" content="' . $image_url . '" />' . "\n";
    }

    echo "<!-- /hiregen meta -->\n";
}
add_action( 'wp_head', 'hiregen_output_meta_and_social', 5 );


/* HIREGEN_MENU_POLYFILL_ADDED */
/**
 * Hiregen theme additions:
 * - add_theme_support( 'title-tag' )
 * - register primary menu
 * - print JSON-LD via wp_head
 * - attach menu polyfill inline (in case menu markup lacks bootstrap attributes)
 *
 * Appended automatically by assistant to help fix dropdown issues.
 * If you already have theme setup functions, merge the add_theme_support() and register_nav_menus() calls into them instead.
 */

add_action( 'after_setup_theme', 'hiregen_theme_setup' );
if ( ! function_exists( 'hiregen_theme_setup' ) ) {
    function hiregen_theme_setup() {
        // Let WP manage the document title
        add_theme_support( 'title-tag' );

        // Register primary nav menu
        register_nav_menus( array(
            'primary' => __( 'Primary Menu', 'hiregen-recruitment' ),
        ) );
    }
}

add_action( 'wp_head', 'hiregen_print_jsonld', 5 );
if ( ! function_exists( 'hiregen_print_jsonld' ) ) {
    function hiregen_print_jsonld() {
        $org_logo = get_theme_mod( 'hiregen_header_logo' );
        $org_graph = array(
            "@context" => "https://schema.org",
            "@graph" => array(
                array_filter( array(
                    "@type" => "Organization",
                    "@id"   => trailingslashit( home_url() ) . "#org",
                    "name"  => get_bloginfo( 'name' ),
                    "url"   => trailingslashit( home_url() ),
                    "logo"  => $org_logo ? esc_url( $org_logo ) : null,
                    "sameAs" => array(),
                ) ),
                array(
                    "@type" => "WebSite",
                    "@id"   => trailingslashit( home_url() ) . "#website",
                    "url"   => trailingslashit( home_url() ),
                    "name"  => get_bloginfo( 'name' ),
                    "publisher" => array( "@id" => trailingslashit( home_url() ) . "#org" ),
                )
            )
        );

        $org_graph['@graph'][0] = array_filter( $org_graph['@graph'][0] );

        echo '<script type="application/ld+json">' . PHP_EOL;
        echo wp_json_encode( $org_graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
        echo PHP_EOL . '</script>' . PHP_EOL;
    }
}

/**
 * Attach dropdown polyfill inline to hiregen-main or hiregen-bootstrap-js (if present).
 * Falls back to registering an empty footer handle if neither is available.
 */
add_action( 'wp_enqueue_scripts', 'hiregen_add_menu_polyfill_inline', 25 );
if ( ! function_exists( 'hiregen_add_menu_polyfill_inline' ) ) {
    function hiregen_add_menu_polyfill_inline() {
        $polyfill_js = "(function(){try{document.addEventListener('DOMContentLoaded',function(){var selectors=['.navbar-nav .menu-item-has-children > a','.navbar-nav .page_item_has_children > a'];var items=[];selectors.forEach(function(s){document.querySelectorAll(s).forEach(function(e){items.push(e);});});items.forEach(function(a){if(!a)return;if(!a.hasAttribute('data-bs-toggle')){a.setAttribute('data-bs-toggle','dropdown');a.classList.add('dropdown-toggle');a.setAttribute('aria-expanded','false');}if(!a.classList.contains('nav-link'))a.classList.add('nav-link');var li=a.closest('li');if(li){if(!li.classList.contains('dropdown'))li.classList.add('dropdown');if(!li.classList.contains('nav-item'))li.classList.add('nav-item');var submenu=li.querySelector('.sub-menu, .children');if(submenu && !submenu.classList.contains('dropdown-menu')){submenu.classList.add('dropdown-menu');submenu.querySelectorAll('a').forEach(function(c){if(!c.classList.contains('dropdown-item'))c.classList.add('dropdown-item');});}}});});}catch(e){if(window.console)console.error('Hiregen menu polyfill error:',e);} })();";

        if ( wp_script_is( 'hiregen-main', 'enqueued' ) ) {
            wp_add_inline_script( 'hiregen-main', $polyfill_js );
        } elseif ( wp_script_is( 'hiregen-bootstrap-js', 'enqueued' ) ) {
            wp_add_inline_script( 'hiregen-bootstrap-js', $polyfill_js );
        } else {
            wp_register_script( 'hiregen-menu-polyfill-fallback', '', array(), false, true );
            wp_enqueue_script( 'hiregen-menu-polyfill-fallback' );
            wp_add_inline_script( 'hiregen-menu-polyfill-fallback', $polyfill_js );
        }
    }
}
/* End HIREGEN_MENU_POLYFILL_ADDED */


function hiregen_render_pricing_section() {

    if ( ! get_theme_mod( 'hiregen_pricing_enable', true ) ) {
        return;
    }

    $bg     = get_theme_mod( 'hiregen_pricing_bg', '#ffffff' );
    $sub    = get_theme_mod( 'hiregen_pricing_subtitle' );
    $title  = get_theme_mod( 'hiregen_pricing_title' );
    $desc   = get_theme_mod( 'hiregen_pricing_desc' );
    $html   = get_theme_mod( 'hiregen_pricing_html' );

    ?>
    <section id="pricing" class="hiregen-pricing-section" style="background-color: <?php echo esc_attr( $bg ); ?>;">
        <div class="container">

            <?php if ( $sub ) : ?>
                <span class="section-subtitle"><?php echo esc_html( $sub ); ?></span>
            <?php endif; ?>

            <?php if ( $title ) : ?>
                <h2 class="section-title"><?php echo esc_html( $title ); ?></h2>
            <?php endif; ?>

            <?php if ( $desc ) : ?>
                <div class="section-description">
                    <?php echo wp_kses_post( wpautop( $desc ) ); ?>
                </div>
            <?php endif; ?>

            <?php if ( $html ) : ?>
                <div class="pricing-html">
                    <?php echo wp_kses_post( $html ); ?>
                </div>
            <?php endif; ?>

        </div>
    </section>
    <?php
}





