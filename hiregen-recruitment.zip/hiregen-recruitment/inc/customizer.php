<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Hiregen Theme Customizer settings (hardened, sanitized, and using selective refresh where possible).
 *
 * NOTE:
 * - Sanitization callbacks are applied at register time. Always escape when outputting theme_mods.
 * - Selective refresh partials are registered only if the customizer supports it.
 */

/* Optional helper sanitize for checkboxes (keeps current behavior) */
if ( ! function_exists( 'hiregen_sanitize_checkbox' ) ) {
	/**
	 * Normalize the checkbox value to boolean true/false.
	 *
	 * @param mixed $checked Incoming value.
	 * @return bool
	 */
	function hiregen_sanitize_checkbox( $checked ) {
		return ( isset( $checked ) && ( $checked === true || $checked === '1' || $checked === 1 || $checked === 'on' ) ) ? true : false;
	}
}

/**
 * Hiregen Theme Customizer additions — Popup settings
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'hiregen_sanitize_checkbox' ) ) {
    function hiregen_sanitize_checkbox( $checked ) {
        return ( ( isset( $checked ) && true == $checked ) ? true : false );
    }
}

if ( ! function_exists( 'hiregen_sanitize_text' ) ) {
    function hiregen_sanitize_text( $text ) {
        return sanitize_text_field( $text );
    }
}

if ( ! function_exists( 'hiregen_sanitize_html' ) ) {
    function hiregen_sanitize_html( $html ) {
        return wp_kses_post( $html );
    }
}

if ( ! function_exists( 'hiregen_customize_register_popup' ) ) :
function hiregen_customize_register_popup( $wp_customize ) {
    // Add Popup Section
    if ( ! $wp_customize->get_section( 'hiregen_popup_section' ) ) {
        $wp_customize->add_section( 'hiregen_popup_section', array(
            'title'    => __( 'Popup', 'hiregen-recruitment' ),
            'panel'    => 'hiregen_panel_home',
            'priority' => 71,
        ) );
    }

    // On/Off Checkbox
    $wp_customize->add_setting(
        'hiregen_popup_enable',
        array(
            'default'           => false,
            'sanitize_callback' => 'hiregen_sanitize_checkbox',
            'transport'         => 'refresh',
        )
    );
    $wp_customize->add_control(
        'hiregen_popup_enable',
        array(
            'label'   => __( 'Enable Homepage Popup', 'hiregen-recruitment' ),
            'section' => 'hiregen_popup_section',
            'type'    => 'checkbox',
        )
    );

    // Title
    $wp_customize->add_setting(
        'hiregen_popup_title',
        array(
            'default'           => __( 'Subscribe to our updates', 'hiregen-recruitment' ),
            'sanitize_callback' => 'hiregen_sanitize_text',
            'transport'         => 'postMessage',
        )
    );
    $wp_customize->add_control(
        'hiregen_popup_title',
        array(
            'label'   => __( 'Popup Title', 'hiregen-recruitment' ),
            'section' => 'hiregen_popup_section',
            'type'    => 'text',
        )
    );

    // Description
    $wp_customize->add_setting(
        'hiregen_popup_desc',
        array(
            'default'           => __( 'Get career tips and new job alerts — enter your name and email.', 'hiregen-recruitment' ),
            'sanitize_callback' => 'hiregen_sanitize_html',
            'transport'         => 'postMessage',
        )
    );
    $wp_customize->add_control(
        'hiregen_popup_desc',
        array(
            'label'   => __( 'Popup Description', 'hiregen-recruitment' ),
            'section' => 'hiregen_popup_section',
            'type'    => 'textarea',
        )
    );

    // Button text
    $wp_customize->add_setting(
        'hiregen_popup_button_text',
        array(
            'default'           => __( 'Subscribe', 'hiregen-recruitment' ),
            'sanitize_callback' => 'hiregen_sanitize_text',
            'transport'         => 'postMessage',
        )
    );
    $wp_customize->add_control(
        'hiregen_popup_button_text',
        array(
            'label'   => __( 'Button Text', 'hiregen-recruitment' ),
            'section' => 'hiregen_popup_section',
            'type'    => 'text',
        )
    );

    // Storage options section
    if ( ! $wp_customize->get_section( 'hiregen_popup_section_settings' ) ) {
        $wp_customize->add_section( 'hiregen_popup_section_settings', array(
            'title'    => __( 'Popup Settings', 'hiregen-recruitment' ),
            'panel'    => 'hiregen_panel_home',
            'priority' => 70,
        ) );
    }

    $wp_customize->add_setting( 'hiregen_popup_storage', array(
        'default' => 'cookie',
        'sanitize_callback' => 'sanitize_text_field',
    ) );
    $wp_customize->add_control( 'hiregen_popup_storage', array(
        'label'   => __( 'Popup persistence method', 'hiregen-recruitment' ),
        'section' => 'hiregen_popup_section_settings',
        'type'    => 'radio',
        'choices' => array(
            'cookie'       => __( 'Cookie (server-friendly)', 'hiregen-recruitment' ),
            'localStorage' => __( 'localStorage (client-only)', 'hiregen-recruitment' ),
        ),
    ) );

    $wp_customize->add_setting( 'hiregen_popup_cookie_subdomain', array(
        'default' => false,
        'sanitize_callback' => 'absint',
    ) );
    $wp_customize->add_control( 'hiregen_popup_cookie_subdomain', array(
        'label'   => __( 'When using cookie, set cookie for top-level domain (e.g. .example.com)', 'hiregen-recruitment' ),
        'section' => 'hiregen_popup_section_settings',
        'type'    => 'checkbox',
    ) );
}
add_action( 'customize_register', 'hiregen_customize_register_popup', 50 );
endif;

/**
 * Register customizer settings
 *
 * @param WP_Customize_Manager $wp_customize
 */
function hiregen_customize_register( $wp_customize ) {

	// Helper: add selective refresh partial if available.
	$selective_refresh = isset( $wp_customize->selective_refresh ) ? $wp_customize->selective_refresh : null;

	// -----------------------------
	// Site Icon control (WP core handles the setting).
	// -----------------------------
	if ( class_exists( 'WP_Customize_Site_Icon_Control' ) ) {
		$hiregen_header_section = 'hiregen_header_section';

		$wp_customize->add_control(
			new WP_Customize_Site_Icon_Control(
				$wp_customize,
				'site_icon',
				array(
					'label'       => __( 'Site Icon', 'hiregen-recruitment' ),
					'section'     => $hiregen_header_section,
					'description' => __( 'The Site Icon appears in browser tabs and mobile apps. Square, 512×512 recommended.', 'hiregen-recruitment' ),
					'priority'    => 60,
				)
			)
		);
	} else {
		// Fallback for older WP versions: a fallback setting with url sanitization.
		$wp_customize->add_setting(
			'hiregen_site_icon_fallback',
			array(
				'default'           => '',
				'capability'        => 'manage_options',
				'sanitize_callback' => 'esc_url_raw',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Image_Control(
				$wp_customize,
				'hiregen_site_icon_fallback',
				array(
					'label'       => __( 'Site Icon (fallback)', 'hiregen-recruitment' ),
					'section'     => 'hiregen_header_section',
					'description' => __( 'Upload a square image (minimum 512x512).', 'hiregen-recruitment' ),
					'priority'    => 60,
				)
			)
		);
	}

	// Main panel id used across sections
	$panel_id = 'hiregen_panel_home';

	// ================= Our Products Section =================
	$wp_customize->add_section(
		'hiregen_products_section',
		array(
			'title'    => __( 'Our Products', 'hiregen-recruitment' ),
			'priority' => 24,
			'panel'    => $panel_id,
		)
	);

	// Enable / disable section
	$wp_customize->add_setting(
		'hiregen_products_enable',
		array(
			'default'           => true,
			'sanitize_callback' => 'hiregen_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'hiregen_products_enable',
		array(
			'type'    => 'checkbox',
			'section' => 'hiregen_products_section',
			'label'   => __( 'Display Our Products Section', 'hiregen-recruitment' ),
		)
	);

	// Background color (sanitized hex)
	$wp_customize->add_setting(
		'hiregen_products_bg_color',
		array(
			'default'           => '#ffffff',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage', // safe for color changes; we'll add partial refresh for critical CSS consumers
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'hiregen_products_bg_color',
			array(
				'label'   => __( 'Background Color', 'hiregen-recruitment' ),
				'section' => 'hiregen_products_section',
			)
		)
	);

	// Subtitle (text)
	$wp_customize->add_setting(
		'hiregen_products_subtitle',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'hiregen_products_subtitle',
		array(
			'label'   => __( 'Subtitle', 'hiregen-recruitment' ),
			'section' => 'hiregen_products_section',
			'type'    => 'text',
		)
	);

	// Title (text)
	$wp_customize->add_setting(
		'hiregen_products_title',
		array(
			'default'           => __( 'Our Products', 'hiregen-recruitment' ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'hiregen_products_title',
		array(
			'label'   => __( 'Title', 'hiregen-recruitment' ),
			'section' => 'hiregen_products_section',
			'type'    => 'text',
		)
	);

	// Description (textarea) - allow basic markup via wp_kses_post
	$wp_customize->add_setting(
		'hiregen_products_desc',
		array(
			'default'           => '',
			'sanitize_callback' => 'wp_kses_post',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'hiregen_products_desc',
		array(
			'label'   => __( 'Description', 'hiregen-recruitment' ),
			'section' => 'hiregen_products_section',
			'type'    => 'textarea',
		)
	);

	// Number of products (int)
	$wp_customize->add_setting(
		'hiregen_products_number',
		array(
			'default'           => 3,
			'sanitize_callback' => 'absint',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'hiregen_products_number',
		array(
			'label'   => __( 'Number of Products to Show', 'hiregen-recruitment' ),
			'section' => 'hiregen_products_section',
			'type'    => 'number',
		)
	);

	// Button text
	$wp_customize->add_setting(
		'hiregen_products_btn_text',
		array(
			'default'           => __( 'View All Products →', 'hiregen-recruitment' ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'hiregen_products_btn_text',
		array(
			'label'   => __( 'Button Text', 'hiregen-recruitment' ),
			'section' => 'hiregen_products_section',
			'type'    => 'text',
		)
	);

	// Button URL - attempt archive link then fallback
	$default_products_url = '';
	if ( function_exists( 'get_post_type_archive_link' ) ) {
		$default_products_url = @get_post_type_archive_link( 'hiregen_product' );
	}
	if ( empty( $default_products_url ) ) {
		$default_products_url = home_url( '/products/' );
	}
	$default_products_url = esc_url_raw( $default_products_url );

	$wp_customize->add_setting(
		'hiregen_products_btn_url',
		array(
			'default'           => $default_products_url,
			'sanitize_callback' => 'esc_url_raw',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'hiregen_products_btn_url',
		array(
			'label'   => __( 'Button URL', 'hiregen-recruitment' ),
			'section' => 'hiregen_products_section',
			'type'    => 'url',
		)
	);

	// Register selective refresh partials (if supported)
	if ( $selective_refresh ) {
		// Title partial for our products (example selector - adjust to match your template)
		$selective_refresh->add_partial(
			'hiregen_products_title',
			array(
				'selector'        => '.hiregen-products .section-title, .hiregen-products h2', // tweak as needed
				'render_callback' => function () {
					echo esc_html( get_theme_mod( 'hiregen_products_title', __( 'Our Products', 'hiregen-recruitment' ) ) );
				},
			)
		);

		$selective_refresh->add_partial(
			'hiregen_products_subtitle',
			array(
				'selector'        => '.hiregen-products .section-subtitle', // tweak as needed
				'render_callback' => function () {
					echo esc_html( get_theme_mod( 'hiregen_products_subtitle', '' ) );
				},
			)
		);

		$selective_refresh->add_partial(
			'hiregen_products_btn_text',
			array(
				'selector'        => '.hiregen-products .products-cta .btn',
				'render_callback' => function () {
					echo esc_html( get_theme_mod( 'hiregen_products_btn_text', __( 'View All Products →', 'hiregen-recruitment' ) ) );
				},
			)
		);
	}






	/* ------------------------------------------------------------------
	 * Hiregen Customizer: FAQ Section Settings
	 * ------------------------------------------------------------------ */
	$wp_customize->add_section(
		'hiregen_faqs_section',
		array(
			'title'    => __( 'FAQ Section', 'hiregen-recruitment' ),
			'priority' => 36,
			'panel'    => $panel_id,
		)
	);

	$wp_customize->add_setting(
		'hiregen_faqs_enable',
		array(
			'default'           => true,
			'sanitize_callback' => 'hiregen_sanitize_checkbox',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'hiregen_faqs_enable',
		array(
			'label'    => __( 'Enable FAQ Section', 'hiregen-recruitment' ),
			'section'  => 'hiregen_faqs_section',
			'type'     => 'checkbox',
			'priority' => 5,
		)
	);

	$wp_customize->add_setting(
		'hiregen_faqs_bg',
		array(
			'default'           => '#f7f7f7',
			'sanitize_callback' => 'sanitize_hex_color',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'hiregen_faqs_bg',
			array(
				'label'    => __( 'Background Color', 'hiregen-recruitment' ),
				'section'  => 'hiregen_faqs_section',
				'priority' => 10,
			)
		)
	);

	$wp_customize->add_setting(
		'hiregen_faqs_subtitle',
		array(
			'default'           => '',
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'hiregen_faqs_subtitle',
		array(
			'label'    => __( 'Subtitle', 'hiregen-recruitment' ),
			'section'  => 'hiregen_faqs_section',
			'type'     => 'text',
			'priority' => 20,
		)
	);

	$wp_customize->add_setting(
		'hiregen_faqs_title',
		array(
			'default'           => __( 'Frequently Asked Questions', 'hiregen-recruitment' ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'hiregen_faqs_title',
		array(
			'label'    => __( 'Title', 'hiregen-recruitment' ),
			'section'  => 'hiregen_faqs_section',
			'type'     => 'text',
			'priority' => 30,
		)
	);

	$wp_customize->add_setting(
		'hiregen_faqs_desc',
		array(
			'default'           => '',
			'sanitize_callback' => 'wp_kses_post',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'hiregen_faqs_desc',
		array(
			'label'    => __( 'Description', 'hiregen-recruitment' ),
			'section'  => 'hiregen_faqs_section',
			'type'     => 'textarea',
			'priority' => 40,
		)
	);

	$wp_customize->add_setting(
		'hiregen_faqs_btn_text',
		array(
			'default'           => __( 'View All FAQs', 'hiregen-recruitment' ),
			'sanitize_callback' => 'sanitize_text_field',
			'transport'         => 'postMessage',
		)
	);
	$wp_customize->add_control(
		'hiregen_faqs_btn_text',
		array(
			'label'    => __( 'Button Text', 'hiregen-recruitment' ),
			'section'  => 'hiregen_faqs_section',
			'type'     => 'text',
			'priority' => 50,
		)
	);

	// Button URL with stable fallback
	$default_faq_url = home_url( '/faq/' );
	if ( function_exists( 'get_post_type_archive_link' ) ) {
		$archive_link = @get_post_type_archive_link( 'hiregen_faq' );
		if ( ! empty( $archive_link ) ) {
			$default_faq_url = $archive_link;
		}
	}

	$wp_customize->add_setting(
		'hiregen_faqs_btn_url',
		array(
			'default'           => esc_url_raw( $default_faq_url ),
			'sanitize_callback' => 'esc_url_raw',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'hiregen_faqs_btn_url',
		array(
			'label'       => __( 'Button URL', 'hiregen-recruitment' ),
			'section'     => 'hiregen_faqs_section',
			'type'        => 'url',
			'priority'    => 60,
			'input_attrs' => array(
				'placeholder' => esc_attr__( '/faq/ or full URL to FAQ archive', 'hiregen-recruitment' ),
			),
		)
	);

	$wp_customize->add_setting(
		'hiregen_faqs_count',
		array(
			'default'           => 6,
			'sanitize_callback' => 'absint',
			'transport'         => 'refresh',
		)
	);
	$wp_customize->add_control(
		'hiregen_faqs_count',
		array(
			'label'       => __( 'Number of FAQs to show', 'hiregen-recruitment' ),
			'section'     => 'hiregen_faqs_section',
			'type'        => 'number',
			'input_attrs' => array( 'min' => 1, 'max' => 50 ),
			'priority'    => 70,
		)
	);

	// ==========================
	// Sub Header Setting
	// ==========================
	$wp_customize->add_section(
		'hiregen_sub_header',
		array(
			'title'    => __( 'Sub Header Setting', 'hiregen-recruitment' ),
			'panel'    => $panel_id,
			'priority' => 44,
		)
	);

	$wp_customize->add_setting(
		'hiregen_subheader_bgcolor',
		array(
			'default'           => '#0d6efd',
			'transport'         => 'postMessage',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'hiregen_subheader_bgcolor',
			array(
				'label'   => __( 'Background Color', 'hiregen-recruitment' ),
				'section' => 'hiregen_sub_header',
			)
		)
	);

	$wp_customize->add_setting(
		'hiregen_subheader_bgimage',
		array(
			'default'           => '',
			'transport'         => 'refresh',
			'sanitize_callback' => 'esc_url_raw',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Image_Control(
			$wp_customize,
			'hiregen_subheader_bgimage',
			array(
				'label'   => __( 'Background Image', 'hiregen-recruitment' ),
				'section' => 'hiregen_sub_header',
			)
		)
	);

	$wp_customize->add_setting(
		'hiregen_subheader_fontcolor',
		array(
			'default'           => '#ffffff',
			'transport'         => 'postMessage',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'hiregen_subheader_fontcolor',
			array(
				'label'   => __( 'Font Color', 'hiregen-recruitment' ),
				'section' => 'hiregen_sub_header',
			)
		)
	);

	$wp_customize->add_setting(
		'hiregen_subheader_breadcrumb_textcolor',
		array(
			'default'           => '#cccccc',
			'transport'         => 'postMessage',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'hiregen_subheader_breadcrumb_textcolor',
			array(
				'label'   => __( 'Breadcrumb Text Color', 'hiregen-recruitment' ),
				'section' => 'hiregen_sub_header',
			)
		)
	);

	$wp_customize->add_setting(
		'hiregen_subheader_breadcrumb_linkcolor',
		array(
			'default'           => '#ffffff',
			'transport'         => 'postMessage',
			'sanitize_callback' => 'sanitize_hex_color',
		)
	);
	$wp_customize->add_control(
		new WP_Customize_Color_Control(
			$wp_customize,
			'hiregen_subheader_breadcrumb_linkcolor',
			array(
				'label'   => __( 'Breadcrumb Link Color', 'hiregen-recruitment' ),
				'section' => 'hiregen_sub_header',
			)
		)
	);

	// Example selective refresh partials for subheader text (if available)
	if ( $selective_refresh ) {
		$selective_refresh->add_partial(
			'hiregen_subheader_fontcolor',
			array(
				'selector'        => '.site-subheader', // adjust selector to your theme markup
				'render_callback' => function () {
					// No raw markup here; templates should use get_theme_mod() and escape output.
					echo '';
				},
			)
		);
	}
}
add_action( 'customize_register', 'hiregen_customize_register' );
