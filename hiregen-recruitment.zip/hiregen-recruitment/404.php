<?php
/**
 * 404 template — safe, accessible, useful
 * Place: wp-content/themes/your-active-theme/404.php
 */

defined( 'ABSPATH' ) || exit;
get_header();
?>

<main id="main" class="site-main py-5" role="main" aria-labelledby="page-404-title">
  <div class="container text-center">

    <header class="mb-4" role="region" aria-live="polite">
      <h1 id="page-404-title" class="display-3 fw-bold mb-2 text-danger">404</h1>
      <h2 class="h4 mb-3"><?php esc_html_e( "Oops! That page can’t be found.", "hiregen-recruitment" ); ?></h2>

      <p class="mb-3 text-muted">
        <?php esc_html_e( "It looks like nothing was found at this location. Try a search, check the sitemap, or browse recent content.", "hiregen-recruitment" ); ?>
      </p>
    </header>

    <!-- Search form -->
    <div class="mb-4">
      <?php get_search_form(); ?>
    </div>

    <!-- Helpful quick links -->
    <div class="mb-4">
      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn-primary me-2" aria-label="<?php echo esc_attr__( 'Return to homepage', 'hiregen-recruitment' ); ?>">
        <?php esc_html_e( "Back to Home", "hiregen-recruitment" ); ?>
      </a>

      <?php
      // Link to sitemap if it exists (common path). Use filter to allow override.
      $sitemap_url = apply_filters( 'hiregen_404_sitemap_url', esc_url( home_url( '/sitemap.xml' ) ) );
      if ( $sitemap_url ) : ?>
        <a href="<?php echo esc_url( $sitemap_url ); ?>" class="btn btn-outline-secondary" aria-label="<?php echo esc_attr__( 'View sitemap', 'hiregen-recruitment' ); ?>">
          <?php esc_html_e( 'View Sitemap', 'hiregen-recruitment' ); ?>
        </a>
      <?php endif; ?>
    </div>

    <!-- Recent posts (safe output) -->
    <section class="recent-posts mb-4" aria-label="<?php esc_attr_e( 'Recent posts', 'hiregen-recruitment' ); ?>">
      <h3 class="h6 mb-3"><?php esc_html_e( 'Recent posts', 'hiregen-recruitment' ); ?></h3>
      <div class="list-group list-group-flush">
        <?php
        $recent = get_posts( array(
          'posts_per_page'      => 5,
          'post_status'         => 'publish',
          'ignore_sticky_posts' => true,
        ) );
        if ( ! empty( $recent ) ) :
          foreach ( $recent as $p ) : ?>
            <a href="<?php echo esc_url( get_permalink( $p ) ); ?>" class="list-group-item list-group-item-action text-start">
              <?php echo esc_html( wp_trim_words( get_the_title( $p ), 12, '...' ) ); ?>
            </a>
          <?php endforeach;
          wp_reset_postdata();
        else : ?>
          <p class="text-muted small mb-0"><?php esc_html_e( 'No recent posts available.', 'hiregen-recruitment' ); ?></p>
        <?php endif; ?>
      </div>
    </section>

    <!-- Useful pages (example), keep sanitized -->
    <section class="useful-pages mb-5" aria-label="<?php esc_attr_e( 'Useful pages', 'hiregen-recruitment' ); ?>">
      <h3 class="h6 mb-3"><?php esc_html_e( 'Helpful pages', 'hiregen-recruitment' ); ?></h3>
      <ul class="list-unstyled d-inline-block text-start">
        <li><a href="<?php echo esc_url( home_url( '/contact/' ) ); ?>"><?php esc_html_e( 'Contact us', 'hiregen-recruitment' ); ?></a></li>
        <li><a href="<?php echo esc_url( home_url( '/jobs/' ) ); ?>"><?php esc_html_e( 'Browse jobs', 'hiregen-recruitment' ); ?></a></li>
        <li><a href="<?php echo esc_url( home_url( '/blog/' ) ); ?>"><?php esc_html_e( 'Blog', 'hiregen-recruitment' ); ?></a></li>
      </ul>
    </section>

  </div>
</main>

<?php
get_footer();
