<?php
/**
 * Archive template for Projects CPT
 * Place this file in your theme / child theme root as:
 *   wp-content/themes/your-theme/archive-hiregen_project.php
 *
 * Uses Bootstrap 5 markup. Adjust classes to match your theme.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

get_header(); // <-- loads head, styles, scripts, bootstrap, etc.
?>

<?php
// Sub Header Section
?>
<div class="sub-header py-4">
  <div class="container">
    <?php
    // Get the "Projects" section title from Customizer
    $projects_title = get_theme_mod( 'hiregen_projects_title', '' );

    if ( ! empty( $projects_title ) ) {
        $title_to_show = $projects_title;
    } else {
        // fallback: normal post type archive title (string)
        $title_to_show = (string) post_type_archive_title( '', false );
    }
    ?>

    <h1 class="entry-title fw-bold"><?php echo wp_kses_post( $title_to_show ); ?></h1>

    <div class="breadcrumb mb-0" aria-label="<?php echo esc_attr__( 'Breadcrumb', 'hiregen-recruitment' ); ?>">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="color:inherit;"><?php esc_html_e( 'Home', 'hiregen-recruitment' ); ?></a>
        &nbsp;→&nbsp;
        <?php echo esc_html( wp_strip_all_tags( $title_to_show ) ); ?>
    </div>
  </div>
</div>


<main id="main" class="site-main py-4" role="main">
  <div class="container">

    <?php if ( have_posts() ) : ?>
      <div class="row g-4"> <!-- grid of cards -->
        <?php
        $i = 0;
        while ( have_posts() ) : the_post();
          $i++;
          $post_id = get_the_ID();
          // safe numeric index for potential use in ids
          $card_id = 'projectCard' . (int) $i;
        ?>
          <div class="col-12 col-md-6 col-lg-4">
            <article id="post-<?php echo (int) $post_id; ?>" <?php post_class( 'card p-3 shadow-sm' ); ?> aria-labelledby="<?php echo esc_attr( $card_id ); ?>-title">

              <?php if ( has_post_thumbnail( $post_id ) ) : ?>
                <a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" class="d-block" aria-hidden="false">
                  <div class="img-fluid card-img rounded overflow-hidden" style="height: 190px;">
                    <?php
                    // Get a safe alt (prefer image alt meta if set, else use title)
                    $thumb_id = get_post_thumbnail_id( $post_id );
                    $img_alt  = '';
                    if ( $thumb_id ) {
                        $img_alt = trim( get_post_meta( $thumb_id, '_wp_attachment_image_alt', true ) );
                    }
                    if ( empty( $img_alt ) ) {
                        $img_alt = get_the_title( $post_id );
                    }
                    // Ensure alt is escaped when passed to the_post_thumbnail attributes
                    the_post_thumbnail(
                        'large',
                        array(
                            'class' => 'img-fluid w-100 h-100',
                            'style' => 'object-fit:cover; display:block;',
                            'alt'   => esc_attr( $img_alt ),
                            'loading' => 'lazy',
                        )
                    );
                    ?>
                  </div>
                </a>
              <?php endif; ?>

              <div class="card-body d-flex flex-column">
                <h5 id="<?php echo esc_attr( $card_id ); ?>-title" class="mb-2">
                  <a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" class="stretched-link">
                    <?php echo esc_html( get_the_title( $post_id ) ); ?>
                  </a>
                </h5>

                <p class="mb-3">
                  <?php
                  // Prefer explicit excerpt if present, otherwise trim content.
                  if ( has_excerpt( $post_id ) ) {
                      echo wp_kses_post( wp_trim_words( get_the_excerpt( $post_id ), 28, '...' ) );
                  } else {
                      // Use get_the_content() and apply the_content filters so shortcodes/embeds work,
                      // then allow safe HTML via wp_kses_post.
                      $raw_content = apply_filters( 'the_content', get_post_field( 'post_content', $post_id ) );
                      echo wp_kses_post( wp_trim_words( wp_strip_all_tags( $raw_content ), 28, '...' ) );
                  }
                  ?>
                </p>

                <div class="mt-auto">
                  <a href="<?php echo esc_url( get_permalink( $post_id ) ); ?>" class="btn btn-sm btn-outline-secondary" aria-label="<?php echo esc_attr( sprintf( esc_html__( 'Read more about %s', 'hiregen-recruitment' ), wp_strip_all_tags( get_the_title( $post_id ) ) ) ); ?>">
                    <?php esc_html_e( 'Read More', 'hiregen-recruitment' ); ?>
                  </a>
                </div>
              </div><!-- .card-body -->

            </article><!-- .card -->
          </div><!-- .col -->
        <?php endwhile; ?>

        <?php
        // restore global post data just in case
        wp_reset_postdata();
        ?>
      </div><!-- .row -->

      <div class="mt-5 d-flex justify-content-center" role="navigation" aria-label="<?php echo esc_attr__( 'Projects navigation', 'hiregen-recruitment' ); ?>">
        <?php
        the_posts_pagination( array(
          'mid_size'           => 2,
          'prev_text'          => esc_html__( '← Prev', 'hiregen-recruitment' ),
          'next_text'          => esc_html__( 'Next →', 'hiregen-recruitment' ),
          'screen_reader_text' => esc_html__( 'Projects navigation', 'hiregen-recruitment' ),
        ) );
        ?>
      </div>

    <?php else : ?>

      <div class="no-results py-5 text-center" role="status" aria-live="polite">
        <h2><?php esc_html_e( 'No projects found', 'hiregen-recruitment' ); ?></h2>
        <p class="text-muted"><?php esc_html_e( 'There are no projects to display yet. Please check back later.', 'hiregen-recruitment' ); ?></p>
      </div>

    <?php endif; ?>
  </div><!-- .container -->
</main>

<?php
get_footer();
