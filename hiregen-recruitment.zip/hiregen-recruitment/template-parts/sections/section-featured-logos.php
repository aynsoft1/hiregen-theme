<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Featured Logos section - sanitized & deduplicated
 */

// theme mods (use hiregen_get_theme_mod if available)
function hiregen_mod( $key, $default = '' ) {
    if ( function_exists( 'hiregen_get_theme_mod' ) ) {
        return hiregen_get_theme_mod( $key, $default );
    }
    return get_theme_mod( $key, $default );
}

$bg_raw    = hiregen_mod( 'hiregen_featured_logos_bg', '#ffffff' );
$bg       = sanitize_hex_color( $bg_raw ) ?: '#ffffff';
$limit    = absint( hiregen_mod( 'hiregen_featured_logos_limit', 10 ) );
$limit    = $limit > 0 ? min( $limit, 100 ) : 10; // clamp to reasonable max

$args  = array(
    'post_type'      => 'hiregen_logo',
    'posts_per_page' => $limit,
    'orderby'        => 'menu_order date',
    'order'          => 'ASC',
);
$logos = new WP_Query( $args );

// helper: render single logo item (post in global $post expected)
function hiregen_render_logo_item( $post_id ) {
    $logo_link_raw = get_post_meta( $post_id, '_hiregen_logo_url', true );
    $logo_link     = $logo_link_raw ? esc_url( $logo_link_raw ) : '';

    $thumb_id = get_post_thumbnail_id( $post_id );
    if ( $thumb_id ) {
        // attempt to get a responsive image URL / HTML
        $img_html = wp_get_attachment_image( $thumb_id, 'medium', false, array( 'class' => 'img-fluid', 'loading' => 'lazy' ) );

        // get alt text (fallback to post title)
        $alt = get_post_meta( $thumb_id, '_wp_attachment_image_alt', true );
        if ( ! $alt ) {
            $alt = get_the_title( $post_id );
        }

        // ensure alt attribute present in markup (wp_get_attachment_image normally includes it)
        // wrap with link if provided
        if ( $logo_link ) {
            printf(
                '<a href="%1$s" target="_blank" rel="noopener noreferrer" aria-label="%2$s">%3$s</a>',
                esc_url( $logo_link ),
                esc_attr( sprintf( /* translators: %s: logo title */ __( 'Visit %s', 'hiregen-recruitment' ), get_the_title( $post_id ) ) ),
                $img_html
            );
        } else {
            echo $img_html;
        }
    } else {
        // no thumbnail - print a text fallback (escaped)
        $title = get_the_title( $post_id );
        if ( $logo_link ) {
            printf(
                '<a href="%1$s" target="_blank" rel="noopener noreferrer">%2$s</a>',
                esc_url( $logo_link ),
                esc_html( $title )
            );
        } else {
            echo '<span>' . esc_html( $title ) . '</span>';
        }
    }
}
?>

<?php if ( $logos->have_posts() ) : ?>
<section id="featured-logos" class="py-5" style="background-color:<?php echo esc_attr( $bg ); ?>;">
  <div class="container">
    <div class="logo-marquee" aria-hidden="false">
      <div class="logo-track">
        <?php
        // First pass
        while ( $logos->have_posts() ) :
            $logos->the_post();
            $post_id = get_the_ID();
        ?>
          <div class="logo-item" role="group" aria-label="<?php echo esc_attr( get_the_title( $post_id ) ); ?>">
            <?php hiregen_render_logo_item( $post_id ); ?>
          </div>
        <?php endwhile; ?>

        <?php
        // Duplicate loop for seamless marquee (rewind_posts preferred)
        $logos->rewind_posts();
        while ( $logos->have_posts() ) :
            $logos->the_post();
            $post_id = get_the_ID();
        ?>
          <div class="logo-item" role="group" aria-label="<?php echo esc_attr( get_the_title( $post_id ) ); ?>">
            <?php hiregen_render_logo_item( $post_id ); ?>
          </div>
        <?php endwhile; wp_reset_postdata(); ?>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>
