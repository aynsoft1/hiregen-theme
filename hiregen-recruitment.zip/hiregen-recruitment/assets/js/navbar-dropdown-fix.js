// navbar-dropdown-fix.js
// Adds Bootstrap-compatible classes/attributes to WP menus so dropdowns work
// (Safe progressive enhancement — doesn't rely on being in body tag.)

(function () {
  'use strict';

  function initNavMenus() {
    var menus = document.querySelectorAll('.navbar .menu, .navbar .navbar-nav, .navbar .wp_page_menu');
    if (!menus.length) return;

    menus.forEach(function(menu){
      var parents = menu.querySelectorAll('li.menu-item-has-children, li.page_item_has_children');
      parents.forEach(function(li){
        // add bootstrap dropdown class to parent <li>
        li.classList.add('dropdown');

        // add toggle class/attributes to the first anchor
        var a = li.querySelector('a');
        if (a) {
          a.classList.add('nav-link', 'dropdown-toggle');
          a.setAttribute('role','button');
          a.setAttribute('aria-expanded','false');
          a.setAttribute('data-bs-toggle','dropdown');
          // Ensure href exists (if # or null, keep as-is)
        }

        // convert the child UL to dropdown-menu and mark its links
        var childUL = li.querySelector('ul');
        if (childUL) {
          childUL.classList.add('dropdown-menu');
          childUL.querySelectorAll('a').forEach(function(link){
            link.classList.add('dropdown-item');
          });
        }
      });
    });

    // Desktop hover: reveal submenus on mouseenter/mouseleave for non-touch large screens
    if (window.matchMedia && window.matchMedia('(min-width: 992px)').matches) {
      document.querySelectorAll('.navbar .dropdown').forEach(function(dd){
        dd.addEventListener('mouseenter', function(){
          dd.classList.add('show');
          var menu = dd.querySelector('.dropdown-menu');
          if (menu) menu.classList.add('show');
        });
        dd.addEventListener('mouseleave', function(){
          dd.classList.remove('show');
          var menu = dd.querySelector('.dropdown-menu');
          if (menu) menu.classList.remove('show');
        });
      });
    }
  }

  // Run on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initNavMenus);
  } else {
    initNavMenus();
  }
})();
