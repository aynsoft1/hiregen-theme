<?php
/**
 * Register block pattern category and block patterns for Hiregen Recruitment theme.
 *
 * Place this file in: inc/block-patterns.php
 * Include it from functions.php: require get_template_directory() . '/inc/block-patterns.php';
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! function_exists( 'hiregen_register_block_pattern_category' ) ) {
    /**
     * Register a custom block pattern category for the theme.
     */
    function hiregen_register_block_pattern_category() {
        if ( function_exists( 'register_block_pattern_category' ) ) {
            register_block_pattern_category(
                'hiregen',
                array( 'label' => __( 'Hiregen', 'hiregen-recruitment' ) )
            );
        }
    }
    add_action( 'init', 'hiregen_register_block_pattern_category', 9 );
}

if ( ! function_exists( 'hiregen_register_block_patterns' ) ) {
    /**
     * Register block patterns.
     */
    function hiregen_register_block_patterns() {
        if ( ! function_exists( 'register_block_pattern' ) ) {
            return;
        }

        // Hero pattern
        register_block_pattern(
            'hiregen/hero-large',
            array(
                'title'       => __( 'Hero — Large centered', 'hiregen-recruitment' ),
                'description' => __( 'Big headline with subtitle and primary call to action.', 'hiregen-recruitment' ),
                'categories'  => array( 'hiregen-recruitment', 'featured' ),
                'content'     => '
<!-- wp:group {"align":"full","className":"hiregen-hero","style":{"spacing":{"padding":{"top":"4rem","bottom":"4rem"}}},"backgroundColor":"primary","textColor":"background"} -->
<div class="wp-block-group alignfull hiregen-hero has-background-color has-primary-background-color has-text-color has-background" style="padding-top:4rem;padding-bottom:4rem"><div class="wp-block-group__inner-container"><!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":1} -->
<h1>' . esc_html__( 'Hire the right talent, faster', 'hiregen-recruitment' ) . '</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"fontSize":"normal"} -->
<p>' . esc_html__( 'A recruitment theme built for job boards and hiring teams. Post jobs, manage applicants and convert candidates into employees.', 'hiregen-recruitment' ) . '</p>
<!-- /wp:paragraph -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-primary"} -->
<div class="wp-block-button is-style-primary"><a class="wp-block-button__link">' . esc_html__( 'Get Started', 'hiregen-recruitment' ) . '</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div></div>
<!-- /wp:group -->',
            )
        );

        // CTA pattern
        register_block_pattern(
            'hiregen/cta-centered',
            array(
                'title'       => __( 'CTA — Centered', 'hiregen-recruitment' ),
                'description' => __( 'Short call to action with supporting text and a button.', 'hiregen-recruitment' ),
                'categories'  => array( 'hiregen-recruitment' ),
                'content'     => '
<!-- wp:group {"align":"wide","className":"hiregen-cta","style":{"spacing":{"padding":{"top":"2rem","bottom":"2rem"}}}} -->
<div class="wp-block-group alignwide hiregen-cta" style="padding-top:2rem;padding-bottom:2rem"><div class="wp-block-group__inner-container"><!-- wp:paragraph {"align":"center","fontSize":"large"} -->
<p class="has-text-align-center has-large-font-size">' . esc_html__( 'Ready to grow your team?', 'hiregen-recruitment' ) . '</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"className":"is-style-outline"} -->
<div class="wp-block-button is-style-outline"><a class="wp-block-button__link">' . esc_html__( 'Request Demo', 'hiregen-recruitment' ) . '</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div></div>
<!-- /wp:group -->',
            )
        );

        // Two-column features pattern
        register_block_pattern(
            'hiregen/features-two-column',
            array(
                'title'       => __( 'Features — Two columns', 'hiregen-recruitment' ),
                'description' => __( 'Two column features list with icons (use icon blocks or emojis).', 'hiregen-recruitment' ),
                'categories'  => array( 'hiregen-recruitment', 'columns' ),
                'content'     => '
<!-- wp:columns {"align":"wide"} -->
<div class="wp-block-columns alignwide"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3>' . esc_html__( 'Smart matching', 'hiregen-recruitment' ) . '</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>' . esc_html__( 'AI-powered suggestions and resume matching to speed up hiring.', 'hiregen-recruitment' ) . '</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":3} -->
<h3>' . esc_html__( 'Easy to manage', 'hiregen-recruitment' ) . '</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>' . esc_html__( 'A simple dashboard and job manager that fits your workflow.', 'hiregen-recruitment' ) . '</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->',
            )
        );
    }
    add_action( 'init', 'hiregen_register_block_patterns' );
}
