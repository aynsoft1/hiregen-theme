=== Hiregen Recruitment ===
Contributors: hiregen, vikaschawla
Tags: recruitment, job-board, wp-job-manager, contact-form-7, bootstrap, responsive, career, hr, company
Requires at least: 5.6
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Hiregen Recruitment is a lightweight, responsive WordPress theme designed for **recruitment websites**, **HR agencies**, and **job portals**.  
It’s built with **Bootstrap 5**, integrates seamlessly with **WP Job Manager** and **Contact Form 7**, and includes customizable homepage sections powered by the WordPress Customizer.

Key features:
* Clean, modern design optimized for mobile and desktop.
* Ready integration with [WP Job Manager](https://wordpress.org/plugins/wp-job-manager/).
* Built-in sections for Services, Testimonials, Team, and Clients.
* Supports **Custom Logo**, **Customizer color settings**, and **Theme Options**.
* SEO and schema-ready (includes structured data for JobPosting).
* Accessibility-conscious (skip links, proper headings, ARIA roles).
* Translation-ready (`.pot` file included).
* Fully compatible with WordPress block editor (Gutenberg).

== Installation ==
1. Download the theme ZIP file or install directly via WordPress admin under **Appearance → Themes → Add New**.
2. Click **Activate** after installation.
3. Install the recommended plugins when prompted:
   - **WP Job Manager** – to add and manage job listings.
   - **Contact Form 7** – to manage job application and contact forms.
4. Configure your homepage under **Appearance → Customize → Homepage Sections**.
5. Add jobs, team members, testimonials, and services using the respective custom post types.

== Recommended Plugins ==
* **WP Job Manager** — for managing job listings.
* **Contact Form 7** — for form management.
* **Breadcrumb NavXT** *(optional)* — for breadcrumbs.
* **Elementor** or **Block Editor** — for custom page layouts.

== Customization ==
Navigate to **Appearance → Customize** to access:
* **Header Settings:** Logo upload, CTA button, navigation colors.
* **Footer Settings:** Background color, social links, column order.
* **Typography & Colors:** Change font families and color schemes.
* **Homepage Sections:** Enable or disable key homepage blocks.
* **Job Listings Layout:** Adjust job grid or list view display.
* **Performance Settings:** Enable/disable preloader and scripts.

== Developer Information ==
* **Template Hierarchy:** Follows standard WordPress theme structure (header.php, footer.php, index.php, single.php, page.php, archive.php, search.php, 404.php).
* **Bootstrap:** Loaded locally from `/assets/css/` and `/assets/js/`.
* **Sanitization:** All Customizer inputs use `sanitize_text_field`, `esc_url_raw`, and `wp_kses_post`.
* **Accessibility:** Includes `skip-link`, `aria-labels`, and semantic headings.
* **Translation:** All strings wrapped in translation functions (`__()`, `_e()`, `esc_html__()`).

== Frequently Asked Questions ==
= Does this theme include WP Job Manager? =
No. WP Job Manager is a **recommended plugin**, not bundled. You can install it via Plugins → Add New.

= Can I use Elementor or Gutenberg with this theme? =
Yes. The theme is compatible with **Elementor**, **Block Editor (Gutenberg)**, and classic content layouts.

= Is Bootstrap loaded from a CDN? =
No. Bootstrap 5 is **bundled locally** for offline and GDPR-friendly usage.

= Does it support structured data for jobs? =
Yes. `single.php` and `page.php` output schema.org **JobPosting** JSON-LD for job listings.

= How can I change the header logo or colors? =
Go to **Appearance → Customize → Header Settings** and upload your logo or pick custom colors.

== Screenshots ==
1. Homepage with Hero and Job Listings.
2. Job Details page layout.
3. Footer widgets and contact section.
4. Customizer panel for theme settings.

== Changelog ==
= 1.0.0 =
* Initial public release.
* Added structured data, accessibility fixes, and Customizer controls.

== Credits ==
This theme uses the following open-source resources:
* [Bootstrap 5](https://getbootstrap.com/) – Licensed under MIT.
* [Font Awesome / Bootstrap Icons](https://icons.getbootstrap.com/) – Licensed under MIT.
* [WP Job Manager](https://wpjobmanager.com/) – by Automattic (plugin integration).
* [Underscores](https://underscores.me/) starter theme framework (base structure).
* [Contact Form 7](https://wordpress.org/plugins/contact-form-7/) – by Takayuki Miyoshi.

== Support ==
For documentation, updates, or support, visit:  
📘 [https://hiregen.com](https://hiregen.com)  
📧 Email: support@hiregen.com  

== License ==
Hiregen Recruitment WordPress Theme is distributed under the **GNU General Public License v2 or later**.

---

✅ **Highlights Added:**
- Detailed installation & customization steps.  
- Developer-focused notes (Bootstrap source, accessibility, sanitization).  
- Credits and support info for Theme Review compliance.  
- Safe, no user input, and all external references escaped.

Would you like me to create a short **`README.md`** (Markdown version) for GitHub as well? It would be formatted for developers with badges and quick-start commands.
