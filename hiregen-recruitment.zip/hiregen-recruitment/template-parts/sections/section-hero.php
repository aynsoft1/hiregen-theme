<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

/**
 * Hero section (sanitized & i18n-ready)
 */

// Theme mod getters (use hiregen_get_theme_mod if available)
function hiregen_get_mod( $key, $default = '' ) {
    if ( function_exists( 'hiregen_get_theme_mod' ) ) {
        return hiregen_get_theme_mod( $key, $default );
    }
    return get_theme_mod( $key, $default );
}

/* --- Raw values --- */
$subtitle_raw       = hiregen_get_mod( 'hiregen_hero_subtitle', __( 'Find your next hire', 'hiregen-recruitment' ) );
$title_raw          = hiregen_get_mod( 'hiregen_hero_title', __( '<strong>Hire the best</strong> for your team', 'hiregen-recruitment' ) );
$desc_raw           = hiregen_get_mod( 'hiregen_hero_description', __( 'Search jobs or post one in seconds.', 'hiregen-recruitment' ) );
$img_raw            = hiregen_get_mod( 'hiregen_hero_image', '' );
$primary_text_raw   = hiregen_get_mod( 'hiregen_hero_primary_text', __( 'Start Your Search', 'hiregen-recruitment' ) );
$primary_url_raw    = hiregen_get_mod( 'hiregen_hero_primary_url', '#' );
$secondary_text_raw = hiregen_get_mod( 'hiregen_hero_secondary_text', __( 'Contact Us', 'hiregen-recruitment' ) );
$secondary_url_raw  = hiregen_get_mod( 'hiregen_hero_secondary_url', '#' );

/* list items (4) */
$li = array();
for ( $i = 1; $i <= 6; $i++ ) {
    $li[] = hiregen_get_mod( 'hiregen_hero_li_' . $i, '' );
}

/* Background settings */
$hero_bg_color_raw = hiregen_get_mod( 'hiregen_hero_bg', '' );
$hero_bg_image_raw = hiregen_get_mod( 'hiregen_hero_bg_image', '' );

/* --- Sanitize / normalize --- */
$subtitle       = sanitize_text_field( $subtitle_raw );
$primary_text   = sanitize_text_field( $primary_text_raw );
$secondary_text = sanitize_text_field( $secondary_text_raw );

/* URLs - keep raw then validate */
$primary_url    = $primary_url_raw ? esc_url_raw( $primary_url_raw ) : '';
$secondary_url  = $secondary_url_raw ? esc_url_raw( $secondary_url_raw ) : '';

/* Title & description: allow a very small safe subset of tags in title/desc */
$allowed_html_title = array(
    'strong' => array(),
    'em'     => array(),
    'br'     => array(),
    'span'   => array( 'class' => array() ),
);
$allowed_html_desc = array(
    'p'      => array(),
    'br'     => array(),
    'strong' => array(),
    'em'     => array(),
    'ul'     => array(),
    'ol'     => array(),
    'li'     => array(),
    'a'      => array(
        'href' => array(),
        'title' => array(),
        'rel' => array(),
        'target' => array(),
    ),
);

/* sanitize title/desc using allowed tags (kept purposely permissive for simple markup) */
$title = wp_kses( $title_raw, $allowed_html_title );
$desc  = wp_kses( $desc_raw, $allowed_html_desc );

/* image handling: theme_mod may be URL or attachment ID — normalize to URL & alt */
$hero_img_url = '';
$hero_img_alt = get_bloginfo( 'name' ); // fallback alt
$hero_img_w   = '';
$hero_img_h   = '';

if ( ! empty( $img_raw ) ) {
    if ( is_numeric( $img_raw ) ) {
        $img_id = absint( $img_raw );
        $tmp    = wp_get_attachment_image_src( $img_id, 'full' );
        if ( ! empty( $tmp[0] ) ) {
            $hero_img_url = esc_url( $tmp[0] );
            $hero_img_w   = $tmp[1];
            $hero_img_h   = $tmp[2];
            $alt_meta = get_post_meta( $img_id, '_wp_attachment_image_alt', true );
            if ( ! empty( $alt_meta ) ) {
                $hero_img_alt = sanitize_text_field( $alt_meta );
            }
        }
    } else {
        // assume URL
        $hero_img_url = esc_url( $img_raw );
        $img_id = attachment_url_to_postid( $img_raw );
        if ( $img_id ) {
            $tmp = wp_get_attachment_image_src( $img_id, 'full' );
            if ( ! empty( $tmp[0] ) ) {
                $hero_img_w = $tmp[1];
                $hero_img_h = $tmp[2];
            }
            $alt_meta = get_post_meta( $img_id, '_wp_attachment_image_alt', true );
            if ( ! empty( $alt_meta ) ) {
                $hero_img_alt = sanitize_text_field( $alt_meta );
            }
        }
    }
}

/* sanitize background values */
$hero_bg_color = sanitize_hex_color( $hero_bg_color_raw );
$hero_bg_image = $hero_bg_image_raw ? esc_url( $hero_bg_image_raw ) : '';

/* Build inline style safely (we will escape it when printing) */
$hero_style = '';
if ( $hero_bg_image ) {
    // Use esc_url above and then build style
    $hero_style = sprintf( "background-image: url('%s'); background-size: cover; background-position: center center;", $hero_bg_image );
} elseif ( $hero_bg_color ) {
    $hero_style = 'background-color: ' . $hero_bg_color . ';';
}

/* sanitize list items */
$hero_list = array();
foreach ( $li as $item ) {
    $item = trim( $item );
    if ( $item !== '' ) {
        $hero_list[] = sanitize_text_field( $item );
    }
}

/* Helper: validate link is usable (not '#', not javascript) */
function hiregen_is_good_url( $url ) {
    if ( empty( $url ) ) {
        return false;
    }
    $u = trim( $url );
    if ( in_array( $u, array( '#', '' ), true ) ) {
        return false;
    }
    if ( 0 === stripos( $u, 'javascript:' ) ) {
        return false;
    }
    return true;
}

$show_primary   = hiregen_is_good_url( $primary_url ) && ( '' !== $primary_text );
$show_secondary = hiregen_is_good_url( $secondary_url ) && ( '' !== $secondary_text );

?>
<section id="hero" class="hiregen-hero py-5" <?php if ( $hero_style ) : ?>style="<?php echo esc_attr( $hero_style ); ?>"<?php endif; ?>>
  <div class="container">
    <div class="row gx-5 align-items-center">
      <div class="col-md-6">
        <?php if ( $subtitle ) : ?>
          <p class="badge-custom"><?php echo esc_html( $subtitle ); ?></p>
        <?php endif; ?>

        <h1 class="display-3 fw-bold hero-title"><?php echo $title; /* already sanitized via wp_kses */ ?></h1>

        <?php if ( $desc ) : ?>
          <p class="lead mb-4"><?php echo $desc; /* sanitized above */ ?></p>
        <?php endif; ?>

        <?php if ( ! empty( $hero_list ) ) : ?>
          <div class="row g-2 mb-4">
            <?php foreach ( $hero_list as $item ) : ?>
              <div class="col-12 col-md-6">
                <p class="mb-2 lead" aria-hidden="false">✓ <?php echo esc_html( $item ); ?></p>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>

        <?php if ( $show_primary || $show_secondary ) : ?>
          <div class="hero-buttons">
            <?php if ( $show_primary ) : ?>
              <a href="<?php echo esc_url( $primary_url ); ?>" class="btn btn-primary me-3" role="button">
                <?php echo esc_html( $primary_text ); ?> &rarr;
              </a>
            <?php endif; ?>

            <?php if ( $show_secondary ) : ?>
              <a href="<?php echo esc_url( $secondary_url ); ?>" class="btn btn-outline-secondary ms-2" role="button">
                <?php echo esc_html( $secondary_text ); ?> &rarr;
              </a>
            <?php endif; ?>
          </div>
        <?php endif; ?>

      </div>

      <div class="col-md-6 text-center">
        <?php if ( $hero_img_url ) : ?>
          <img src="<?php echo esc_url( $hero_img_url ); ?>" 
               alt="<?php echo esc_attr( $hero_img_alt ); ?>" 
               class="img-fluid rounded-custom"
               fetchpriority="high"
               loading="eager"
               <?php if ( $hero_img_w ) echo ' width="' . intval( $hero_img_w ) . '"'; ?>
               <?php if ( $hero_img_h ) echo ' height="' . intval( $hero_img_h ) . '"'; ?>
          />
        <?php else : ?>
          <!-- Optional: decorative SVG or placeholder could go here -->
        <?php endif; ?>
      </div>
    </div>
  </div>
</section>
