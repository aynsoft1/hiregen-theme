<?php
/**
 * Job dashboard shortcode content.
 *
 * @see         https://wpjobmanager.com/document/template-overrides/
 * @author      Automattic
 * @package     wp-job-manager
 * @category    Template
 * @version     2.3.0
 *
 * @var array     $job_dashboard_columns Array of the columns to show on the job dashboard page.
 * @var int       $max_num_pages Maximum number of pages
 * @var WP_Post[] $jobs Array of job post results.
 * @var array     $job_actions Array of actions available for each job.
 * @var string    $search_input Search input.
 */

use WP_Job_Manager\Job_Overlay;
use WP_Job_Manager\UI\Notice;
use WP_Job_Manager\UI\UI_Elements;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Resolve Post a Job URL robustly and sanitize for output.
 */
$submit_job_form_page_id = get_option( 'job_manager_submit_job_form_page_id' );
$submit_url              = '';

if ( $submit_job_form_page_id ) {
	$submit_url = get_permalink( $submit_job_form_page_id );
}

if ( ! $submit_url ) {
	$submit_page = get_page_by_path( 'post-a-job' );
	if ( $submit_page ) {
		$submit_url = get_permalink( $submit_page->ID );
	}
}

if ( ! $submit_url ) {
	$submit_url = home_url( '/post-a-job/' );
}

$submit_url = esc_url( $submit_url );

/**
 * Sanitize / normalize incoming search input (do not trust raw GET values).
 * $search_input should already be provided by the surrounding code, but sanitize here.
 */
$search_input = isset( $search_input ) ? wp_unslash( $search_input ) : '';
$search_input = sanitize_text_field( $search_input );
?>
<div id="job-manager-job-dashboard" class="alignwide jm-dashboard jm-ui">
	<div class="jm-dashboard__intro">
<div class="jm-dashboard__filters">
    <?php
    /**
     * Use the WP standard get_search_form() so plugins can filter/replace the form.
     * We provide a theme searchform.php (see below) to keep the same 'search' field name
     * and styling expected by the job dashboard.
     */
    get_search_form();
    ?>
</div>


		<div class="jm-dashboard__actions">
			<?php if ( function_exists( 'job_manager_user_can_submit_job_listing' ) && job_manager_user_can_submit_job_listing() ) : ?>
				<a class="btn btn-primary" href="<?php echo $submit_url; ?>">
					<span><?php echo esc_html_x( 'Add Job', 'button', 'hiregen-recruitment' ); ?></span>
				</a>
			<?php endif; ?>
		</div>
	</div>

	<?php $table_class = ( is_array( $job_dashboard_columns ) && count( $job_dashboard_columns ) > 4 ) ? 'jm-dashboard-table--large' : ''; ?>
	<div class="job-manager-jobs jm-dashboard-table <?php echo esc_attr( $table_class ); ?>">
		<?php if ( empty( $jobs ) ) : ?>
			<div class="jm-dashboard-empty">
				<?php
				// Build a safe message for the Notice dialog.
				if ( $search_input ) {
					/* translators: %s: search term */
					$message = sprintf( __( 'No results found for "%s".', 'hiregen-recruitment' ), esc_html( $search_input ) );
				} else {
					$message = __( 'You do not have any active listings.', 'hiregen-recruitment' );
				}

				echo wp_kses_post( Notice::dialog( array( 'message' => $message ) ) );
				?>
			</div>
		<?php else : ?>
			<div class="jm-dashboard-header">
				<?php
				if ( is_array( $job_dashboard_columns ) ) :
					foreach ( $job_dashboard_columns as $key => $column ) :
						// create a safe CSS class and safely output the label
						$safe_key = sanitize_html_class( $key );
						$label = is_scalar( $column ) ? (string) $column : '';
					?>
						<div class="jm-dashboard-job-column jm-dashboard-job-column-label <?php echo esc_attr( $safe_key ); ?>">
							<?php echo esc_html( $label ); ?>
						</div>
					<?php
					endforeach;
				endif;
				?>
				<div class="jm-dashboard-job-column jm-dashboard-job-column-label actions">
					<?php echo esc_html_x( 'Actions', 'dashboard column label', 'hiregen-recruitment' ); ?>
				</div>
			</div>

			<div class="jm-dashboard-rows">
				<?php
				// Loop jobs
				foreach ( (array) $jobs as $job ) : // phpcs:ignore WordPress.NamingConventions.ValidVariableName.VariableNotSnakeCase
					// Ensure we have a WP_Post object
					if ( ! ( $job instanceof WP_Post ) ) {
						continue;
					}
				?>
					<div class="jm-dashboard-job">
						<?php
						if ( is_array( $job_dashboard_columns ) ) :
							foreach ( $job_dashboard_columns as $key => $column ) :
								$safe_key = sanitize_html_class( $key );
								$label = is_scalar( $column ) ? (string) $column : '';
								// Aria label must be safe text.
								$aria_label = wp_strip_all_tags( $label );
						?>
								<div class="jm-dashboard-job-column <?php echo esc_attr( $safe_key ); ?>" aria-label="<?php echo esc_attr( $aria_label ); ?>">
									<div class="jm-dashboard-job-column-label"><?php echo esc_html( $label ); ?></div>
									<?php
									/**
									 * Allow plugins/themes to render the column content.
									 * The callback responsible for these outputs should
									 * itself escape output — but we cannot control that here.
									 * Keep action call, but do not echo unescaped data in this template.
									 */
									do_action( 'job_manager_job_dashboard_column_' . $safe_key, $job );
									?>
								</div>
						<?php
							endforeach;
						endif;
						?>

						<div class="jm-dashboard-job-column actions job-dashboard-job-actions">
							<?php
							// Render actions column hooks first (some callbacks may add content).
							do_action( 'job_manager_job_dashboard_column_actions', $job, isset( $job_actions[ $job->ID ] ) ? $job_actions[ $job->ID ] : array() );
							?>

							<?php
							// Build a safe actions HTML string from provided $job_actions
							$actions_html = '';

							if ( ! empty( $job_actions[ $job->ID ] ) && is_array( $job_actions[ $job->ID ] ) ) {
								foreach ( $job_actions[ $job->ID ] as $action ) {
									// Validate expected array keys and sanitize.
									$action_url   = isset( $action['url'] ) ? esc_url( wp_unslash( $action['url'] ) ) : '';
									$action_name  = isset( $action['name'] ) ? sanitize_html_class( $action['name'] ) : '';
									$action_label = isset( $action['label'] ) ? sanitize_text_field( $action['label'] ) : '';

									if ( $action_url && $action_label ) {
										// Build safe link string.
										$actions_html .= '<a href="' . $action_url . '" class="jm-dashboard-action jm-ui-button--link job-dashboard-action-' . esc_attr( $action_name ) . '">' . esc_html( $action_label ) . '</a>' . "\n";
									}
								}
							}

							// Output actions menu using UI helper. Ensure helper returns safe content.
							echo UI_Elements::actions_menu( $actions_html );
							?>
						</div>
					</div>
				<?php endforeach; // end jobs loop ?>
			</div>
		<?php endif; ?>
	</div>

	<?php
	// Pagination template: pass sanitized max_num_pages (int).
	$max_num_pages = isset( $max_num_pages ) ? absint( $max_num_pages ) : 0;
	get_job_manager_template( 'pagination.php', array( 'max_num_pages' => $max_num_pages ) );
	?>
</div>
