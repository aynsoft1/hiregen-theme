<?php
/**
 * home.php - Posts index (blog archive) template (sanitized & i18n-ready)
 * Place in theme root: wp-content/themes/your-active-theme/home.php
 */

defined( 'ABSPATH' ) || exit;

get_header();
?>

<?php
// Sub Header Section
?>

<div class="sub-header py-4">
  <div class="container">
    <?php if ( is_home() || is_archive() ) : ?>
        <?php
        // Use customizer values for blog page title if available (prefer hiregen_get_theme_mod if present)
        $blog_page_title_raw = ( function_exists( 'hiregen_get_theme_mod' ) ) ? hiregen_get_theme_mod( 'hiregen_blog_title', '' ) : get_theme_mod( 'hiregen_blog_title', '' );
        $blog_page_title_raw = (string) $blog_page_title_raw;
        $blog_page_title = $blog_page_title_raw !== '' ? sanitize_text_field( $blog_page_title_raw ) : __( 'Our Blog', 'hiregen-recruitment' );
        ?>
        <h1 class="entry-title fw-bold"><?php echo esc_html( $blog_page_title ); ?></h1>
    <?php else : ?>
        <h2 class="entry-title fw-bold"><?php echo esc_html( get_the_title() ); ?></h2>
    <?php endif; ?>

    <div class="breadcrumb mb-0">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html__( 'Home', 'hiregen-recruitment' ); ?></a>
        &nbsp;&rarr;&nbsp;
        <?php
        if ( is_home() || is_archive() ) {
            echo esc_html( $blog_page_title );
        } else {
            echo esc_html( get_the_title() );
        }
        ?>
    </div>
  </div>
</div>

<main id="main" class="site-main py-4" role="main">
  <div class="container">
    <?php if ( have_posts() ) : ?>
      <div class="row g-4">
        <?php while ( have_posts() ) : the_post(); ?>
          <?php
            $post_id    = get_the_ID();
            $permalink  = get_permalink( $post_id );
            $permalink  = $permalink ? esc_url( $permalink ) : '#';
            $post_title = get_the_title( $post_id );
          ?>
          <div class="col-12 col-md-6 col-lg-4">
            <article id="post-<?php echo esc_attr( $post_id ); ?>" <?php post_class( 'card h-100 p-3 shadow-sm' ); ?>>

              <?php if ( has_post_thumbnail( $post_id ) ) : ?>
                <a href="<?php echo $permalink; ?>" class="d-block">
                  <div class="img-fluid card-img rounded overflow-hidden" style="height:190px;">
                    <?php
                    $thumb_id = get_post_thumbnail_id( $post_id );
                    $alt_meta = $thumb_id ? get_post_meta( $thumb_id, '_wp_attachment_image_alt', true ) : '';
                    $alt_text = $alt_meta ? $alt_meta : ( $post_title ? $post_title : sprintf( __( 'Post %d', 'hiregen-recruitment' ), $post_id ) );

                    // the_post_thumbnail prints responsive img markup; pass attributes via array
                    the_post_thumbnail( 'large', array(
                        'class'   => 'img-fluid w-100 h-100',
                        'style'   => 'object-fit:cover; display:block;',
                        'alt'     => esc_attr( $alt_text ),
                        'loading' => 'lazy',
                    ) );
                    ?>
                  </div>
                </a>
              <?php endif; ?>

              <div class="card-body d-flex flex-column">
                <h5 class="mb-2">
                  <a href="<?php echo $permalink; ?>" class="stretched-link"><?php echo esc_html( $post_title ); ?></a>
                </h5>

                <div class="card-text text-muted mb-3">
                  <?php
                  if ( has_excerpt( $post_id ) ) {
                      echo wp_kses_post( wp_trim_words( get_the_excerpt(), 28, '...' ) );
                  } else {
                      echo wp_kses_post( wp_trim_words( get_the_content(), 28, '...' ) );
                  }
                  ?>
                </div>

                <div class="mt-auto">
                  <a href="<?php echo $permalink; ?>" class="btn btn-sm btn-outline-secondary" role="button"><?php esc_html_e( 'Read More', 'hiregen-recruitment' ); ?></a>
                </div>
              </div>

            </article>
          </div>
        <?php endwhile; ?>
      </div>

      <div class="mt-5 d-flex justify-content-center">
        <?php
        the_posts_pagination( array(
          'mid_size'  => 2,
          'prev_text' => __( '← Prev', 'hiregen-recruitment' ),
          'next_text' => __( 'Next →', 'hiregen-recruitment' ),
        ) );
        ?>
      </div>

    <?php else : ?>
      <div class="no-results py-5 text-center">
        <h2><?php esc_html_e( 'No posts found', 'hiregen-recruitment' ); ?></h2>
      </div>
    <?php endif; ?>

  </div>
</main>

<?php get_footer(); ?>
