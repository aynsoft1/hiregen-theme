<?php
/**
 * Hiregen Optimization & PWA Features
 * Included from functions.php
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * --------------------------------------------------------------------------
 * 1. WebP Image Support (Auto-convert on upload)
 * --------------------------------------------------------------------------
 * Checks if the server supports WebP and converts JPG/PNG uploads.
 */
function hiregen_auto_convert_webp( $file ) {
    // Check if it's an image we want to convert
    $type = $file['type'];
    if ( 'image/jpeg' !== $type && 'image/png' !== $type ) {
        return $file;
    }

    // Check if the server's image editor supports WebP
    $args = array( 'mime_type' => 'image/webp' );
    if ( ! wp_image_editor_supports( $args ) ) {
        return $file; // WebP not supported by server
    }

    $file_path = $file['file'];
    $path_info = pathinfo( $file_path );
    
    // Safety check
    if ( ! isset( $path_info['dirname'], $path_info['filename'] ) ) {
        return $file;
    }

    // Create editor instance
    $image_editor = wp_get_image_editor( $file_path );
    if ( is_wp_error( $image_editor ) ) {
        return $file;
    }

    // Build new path
    $new_file_path = $path_info['dirname'] . '/' . $path_info['filename'] . '.webp';

    // Attempt to save as WebP
    $saved = $image_editor->save( $new_file_path, 'image/webp' );

    if ( ! is_wp_error( $saved ) && file_exists( $saved['path'] ) ) {
        // Success: Update the file array to point to the new WebP
        $file['file'] = $saved['path'];
        $file['type'] = 'image/webp';
        
        // Update URL extension
        $ext = '.' . $path_info['extension'];
        $file['url'] = str_replace( $ext, '.webp', $file['url'] );

        // Remove the original source file to save space (Standard "Convert" behavior)
        if ( file_exists( $file_path ) ) {
            @unlink( $file_path );
        }
    }

    return $file;
}
// Hook into upload handling
add_filter( 'wp_handle_upload', 'hiregen_auto_convert_webp' );


/**
 * --------------------------------------------------------------------------
 * 2. PWA Support (Manifest & Meta)
 * --------------------------------------------------------------------------
 */
function hiregen_pwa_header_tags() {
    $manifest_url = get_template_directory_uri() . '/manifest.json';

    // Theme color
    echo '<meta name="theme-color" content="#6f42c1">' . "\n";
    
    // Manifest
    echo '<link rel="manifest" href="' . esc_url( $manifest_url ) . '">' . "\n";
}
add_action( 'wp_head', 'hiregen_pwa_header_tags' );


/**
 * --------------------------------------------------------------------------
 * 3. Sitemap URL Cleanup
 * --------------------------------------------------------------------------
 * Removes 'hiregen_' prefix from the generated sitemap URLs and adds rewrite rules
 * so the cleaner URLs resolve to the correct CPT sitemap.
 */

// 1. Modify the URLs in the sitemap index
function hiregen_clean_sitemap_urls( $entry ) {
    // Map of internal CPT slug => clean URL slug
    $mappings = array(
        'hiregen_service'     => 'services',
        'hiregen_project'     => 'projects',
        'hiregen_testimonial' => 'testimonial',
        'hiregen_team'        => 'teams',
        'hiregen_product'     => 'products',
        'hiregen_faq'         => 'faq',
    );

    foreach ( $mappings as $cpt => $clean_slug ) {
        // Look for the default WP structure: wp-sitemap-posts-hiregen_service-1.xml
        $search = 'wp-sitemap-posts-' . $cpt;
        $replace = 'wp-sitemap-posts-' . $clean_slug;
        if ( strpos( $entry['loc'], $search ) !== false ) {
            $entry['loc'] = str_replace( $search, $replace, $entry['loc'] );
        }
    }
    return $entry;
}
add_filter( 'wp_sitemaps_index_entry', 'hiregen_clean_sitemap_urls' );

// 2. Add rewrite rules to map clean URLs back to internal CPTs
function hiregen_sitemap_rewrites() {
    // Map clean URL slug => internal CPT slug
    $rewrites = array(
        'services'    => 'hiregen_service',
        'projects'    => 'hiregen_project',
        'testimonial' => 'hiregen_testimonial',
        'teams'       => 'hiregen_team',
        'products'    => 'hiregen_product',
        'faq'         => 'hiregen_faq',
    );

    foreach ( $rewrites as $clean_slug => $cpt ) {
        add_rewrite_rule(
            '^wp-sitemap-posts-' . $clean_slug . '-(\d+)\.xml$',
            'index.php?sitemap=posts&sitemap-subtype=' . $cpt . '&paged=$matches[1]',
            'top'
        );
    }
}
add_action( 'init', 'hiregen_sitemap_rewrites' );
