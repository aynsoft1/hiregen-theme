<?php
/**
 * Single post template — Bootstrap 5 friendly
 * Save as: wp-content/themes/your-active-theme/single.php
 *
 * Changes:
 * - safe title handling (escaped)
 * - breadcrumb built from safe parts (escaped URLs & labels)
 * - uses the_content() (respects filters)
 * - job JSON-LD sanitised and filterable
 * - accessibility roles and small ARIA improvements
 */

defined( 'ABSPATH' ) || exit;
get_header();
?>

<?php
// -----------------------------
// Sub Header / Breadcrumb area
// -----------------------------

// Get a safe title for display (not calling the_title() which echoes)
$title_to_show = get_the_title( get_queried_object_id() );
$safe_title    = $title_to_show ? wp_strip_all_tags( $title_to_show ) : get_bloginfo( 'name' );

// Build breadcrumb parts as an array of safe items (links or plain labels)
$breadcrumb_parts = array();

// Home
$breadcrumb_parts[] = '<a href="' . esc_url( home_url( '/' ) ) . '" rel="home">' . esc_html__( 'Home', 'hiregen-recruitment' ) . '</a>';

// For singular posts/pages/CPT show taxonomy/parent/post-type archive where helpful
if ( is_singular() ) {
    $post_id   = get_queried_object_id();
    $post_type = get_post_type( $post_id );

    $term_output = '';

    if ( 'post' === $post_type ) {
        $cats = get_the_category( $post_id );
        if ( ! empty( $cats ) && ! is_wp_error( $cats ) ) {
            $cat = $cats[0];
            $term_output = '<a href="' . esc_url( get_category_link( $cat ) ) . '">' . esc_html( $cat->name ) . '</a>';
        }
    } else {
        // Custom post types: prefer hierarchical taxonomies
        $taxes = get_object_taxonomies( $post_type, 'objects' );
        if ( ! empty( $taxes ) ) {
            foreach ( $taxes as $tax ) {
                if ( ! empty( $tax->hierarchical ) ) {
                    $terms = wp_get_post_terms( $post_id, $tax->name );
                    if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
                        $t = $terms[0];
                        $link = get_term_link( $t );
                        if ( ! is_wp_error( $link ) ) {
                            $term_output = '<a href="' . esc_url( $link ) . '">' . esc_html( $t->name ) . '</a>';
                            break;
                        }
                    }
                }
            }
        }

        // fallback to first non-hierarchical taxonomy (skip tags if desired)
        if ( empty( $term_output ) ) {
            foreach ( $taxes as $tax ) {
                if ( 'post_tag' === $tax->name ) {
                    continue;
                }
                $terms = wp_get_post_terms( $post_id, $tax->name );
                if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
                    $t = $terms[0];
                    $link = get_term_link( $t );
                    if ( ! is_wp_error( $link ) ) {
                        $term_output = '<a href="' . esc_url( $link ) . '">' . esc_html( $t->name ) . '</a>';
                        break;
                    }
                }
            }
        }


        // If still empty and this is a page with parent, show parent
        if ( empty( $term_output ) && is_page( $post_id ) ) {
            $post_obj = get_post( $post_id );
            if ( ! empty( $post_obj->post_parent ) ) {
                $parent = get_post( $post_obj->post_parent );
                if ( $parent ) {
                    $term_output = '<a href="' . esc_url( get_permalink( $parent ) ) . '">' . esc_html( get_the_title( $parent ) ) . '</a>';
                }
            }
        }

        // Lastly show post type archive if available
        if ( empty( $term_output ) ) {
            $pt_obj = get_post_type_object( $post_type );
            if ( $pt_obj && ! empty( $pt_obj->has_archive ) ) {
                $archive_link = get_post_type_archive_link( $post_type );
                if ( $archive_link ) {
                    $label = ! empty( $pt_obj->labels->name ) ? $pt_obj->labels->name : $pt_obj->label;
                    $term_output = '<a href="' . esc_url( $archive_link ) . '">' . esc_html( $label ) . '</a>';
                }
            }
        }
    }

    if ( $term_output ) {
        $breadcrumb_parts[] = $term_output;
    }
    // intentionally do not append the post title here to avoid duplicating the H1
} else {
    // archives / other contexts
    if ( is_archive() ) {
        $breadcrumb_parts[] = esc_html( get_the_archive_title() );
    }
}

// join with separator (use safe HTML)
$breadcrumb_html = implode( ' <span class="breadcrumb-sep" aria-hidden="true">→</span> ', $breadcrumb_parts );
?>

<div class="sub-header py-4">
  <div class="container">
    <h1 class="entry-title fw-bold"><?php echo esc_html( $safe_title ); ?></h1>

    <div class="breadcrumb mb-0" aria-label="<?php esc_attr_e( 'Breadcrumb', 'hiregen-recruitment' ); ?>">
      <?php echo wp_kses( $breadcrumb_html, array(
              'a' => array( 'href' => array(), 'rel' => array(), 'title' => array(), 'class' => array() ),
              'span' => array( 'class' => array(), 'aria-hidden' => array() ),
          ) );
      ?>
    </div>
  </div>
</div>

<main id="content" class="site-main py-4" role="main" aria-labelledby="main-title">
  <div class="container">
    <?php
    if ( have_posts() ) :
        while ( have_posts() ) :
            the_post();

            // ----------------------------
            // JOBPOSTING JSON-LD (if job)
            // ----------------------------
            $is_job = ( 'job_listing' === get_post_type() ) || get_post_meta( get_the_ID(), '_is_job_posting', true );

            if ( $is_job ) {

                $job_id          = get_the_ID();
                $title           = get_the_title( $job_id );
                // Prefer excerpt for description; if absent, create a safe text excerpt from content.
                $description_raw = get_the_excerpt() ? get_the_excerpt() : wp_trim_words( wp_strip_all_tags( get_the_content() ), 30, '...' );
                $date_posted     = get_the_date( 'c', $job_id ); // ISO 8601
                $valid_through   = get_post_meta( $job_id, '_job_expires', true ); // validate format if possible
                $employment      = get_post_meta( $job_id, '_job_type', true );
                $salary_amount   = get_post_meta( $job_id, '_job_salary', true );
                $salary_currency = get_post_meta( $job_id, '_job_salary_currency', true ) ?: 'INR';
                $org_name        = get_post_meta( $job_id, '_hiring_organization', true );
                if ( empty( $org_name ) ) {
                    $org_name = get_bloginfo( 'name' );
                }
                $job_location = get_post_meta( $job_id, '_job_location', true );
                $remote_flag  = get_post_meta( $job_id, '_job_remote', true );

                // Build primitive structure with sanitisation
                $job_posting = array(
                    '@context' => 'https://schema.org/',
                    '@type'    => 'JobPosting',
                    'title'    => wp_strip_all_tags( $title ),
                    'description' => wp_strip_all_tags( $description_raw ),
                    'datePosted'  => $date_posted,
                    'hiringOrganization' => array(
                        '@type' => 'Organization',
                        'name'  => wp_strip_all_tags( $org_name ),
                        'sameAs'=> esc_url_raw( home_url() ),
                    ),
                    'identifier' => array(
                        '@type' => 'PropertyValue',
                        'name'  => wp_strip_all_tags( get_bloginfo( 'name' ) ),
                        'value' => (string) $job_id,
                    ),
                    'employmentType' => $employment ? sanitize_text_field( $employment ) : null,
                    'validThrough'   => $valid_through ? sanitize_text_field( $valid_through ) : null,
                    'jobLocationType'=> null,
                    'jobLocation'    => null,
                );

                // salary handling: numeric -> structured, otherwise string
                if ( $salary_amount ) {
                    if ( is_numeric( $salary_amount ) ) {
                        $job_posting['baseSalary'] = array(
                            '@type'    => 'MonetaryAmount',
                            'currency' => sanitize_text_field( $salary_currency ),
                            'value'    => array(
                                '@type'    => 'QuantitativeValue',
                                'value'    => (float) $salary_amount,
                                'unitText' => get_post_meta( $job_id, '_job_salary_unit', true ) ?: 'MONTH',
                            ),
                        );
                    } else {
                        $job_posting['baseSalary'] = wp_strip_all_tags( $salary_amount );
                    }
                }

                if ( $remote_flag ) {
                    $job_posting['jobLocationType'] = 'TELECOMMUTE';
                    unset( $job_posting['jobLocation'] );
                } elseif ( $job_location ) {
                    $job_posting['jobLocation'] = array(
                        '@type' => 'Place',
                        'address' => array(
                            '@type' => 'PostalAddress',
                            'addressLocality' => wp_strip_all_tags( $job_location ),
                        ),
                    );
                } else {
                    // neither remote nor a location — remove blank keys
                    unset( $job_posting['jobLocation'] );
                    unset( $job_posting['jobLocationType'] );
                }

                // add URL
                $job_posting['url'] = esc_url_raw( get_permalink( $job_id ) );

                /**
                 * filter: allow plugins/themes to modify the structured data before output
                 * Usage: add_filter( 'hiregen_jobposting_json', function( $arr, $post ) { ... }, 10, 2 );
                 */
                $job_posting = apply_filters( 'hiregen_jobposting_json', $job_posting, get_post( $job_id ) );

                // Remove empty/null entries recursively
                $remove_empty_recursive = function ( $v ) use ( &$remove_empty_recursive ) {
                    if ( is_array( $v ) ) {
                        foreach ( $v as $k => $val ) {
                            if ( $val === null || $val === '' ) {
                                unset( $v[ $k ] );
                            } else {
                                $v[ $k ] = $remove_empty_recursive( $val );
                            }
                        }
                    }
                    return $v;
                };

                $job_posting = $remove_empty_recursive( $job_posting );

                // Output JSON-LD safely
                echo '<script type="application/ld+json">' . wp_json_encode( $job_posting, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
            } else {
                // Generic Schema for Blog Posts or other Articles
                if ( is_singular() ) {
                    $schema_type = 'Article'; // default
                    if ( is_singular( 'post' ) ) {
                         $schema_type = 'BlogPosting';
                    }

                    $schema_logo = get_theme_mod( 'hiregen_header_logo' );
                    $schema = array(
                        '@context' => 'https://schema.org',
                        '@type'    => $schema_type,
                        'headline' => wp_strip_all_tags( get_the_title() ),
                        'image'    => has_post_thumbnail() ? get_the_post_thumbnail_url( null, 'large' ) : '',
                        'author'   => array(
                            '@type' => 'Person',
                            'name'  => get_the_author(),
                        ),
                        'publisher' => array(
                            '@type' => 'Organization',
                            'name'  => get_bloginfo( 'name' ),
                            'logo'  => array(
                                '@type' => 'ImageObject',
                                'url'   => $schema_logo ? esc_url( $schema_logo ) : '',
                            ),
                        ),
                        'datePublished' => get_the_date( 'c' ),
                        'dateModified'  => get_the_modified_date( 'c' ),
                        'description'   => wp_strip_all_tags( get_the_excerpt() ? get_the_excerpt() : wp_trim_words( get_the_content(), 30 ) ),
                        'mainEntityOfPage' => array(
                            '@type' => 'WebPage',
                            '@id'   => get_permalink(),
                        ),
                    );
                    echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
                }
            } // end is_job
            ?>

            <div class="row gx-5">

              <!-- Left: post content (Centered) -->
              <div class="col-12 col-lg-10 mx-auto">
                <div class="card card-body p-4">
                  <article id="post-<?php the_ID(); ?>" <?php post_class(); ?> aria-labelledby="main-title">
                    <?php
                    // Featured image (escaped via core)
                    if ( has_post_thumbnail() ) : ?>
                      <figure class="post-thumbnail mb-4">
                        <?php
                        the_post_thumbnail( 'large', array(
                          'class'   => 'img-fluid card-img rounded overflow-hidden w-100',
                          'alt'     => the_title_attribute( array( 'echo' => false ) ),
                          'loading' => 'lazy',
                        ) );
                        ?>
                      </figure>
                    <?php endif;
                    ?>

                    <div class="entry-content">
                      <?php
                      // Use the_content() so shortcodes/blocks/filters run as expected
                      the_content();

                      wp_link_pages( array(
                          'before' => '<nav class="page-links"><span class="fw-semibold">' . esc_html__( 'Pages:', 'hiregen-recruitment' ) . '</span>',
                          'after'  => '</nav>',
                      ) );
                      ?>
                    </div>

                    <footer class="entry-footer mt-4">
                      <?php the_tags( '<div class="post-tags"><strong>' . esc_html__( 'Tags:', 'hiregen-recruitment' ) . '</strong> ', ', ', '</div>' ); ?>
                    </footer>
                  </article>

                  <!-- Comments -->
                  <?php
                  if ( comments_open() || get_comments_number() ) {
                      comments_template();
                  }
                  ?>
                </div>
              </div>

            </div><!-- /.row -->

        <?php
        endwhile;
    else :
        // No posts found (edge-case)
        ?>
        <div class="card card-body p-4">
          <h2><?php esc_html_e( 'Nothing found', 'hiregen-recruitment' ); ?></h2>
          <p><?php esc_html_e( 'Sorry, nothing matched your criteria. Try a search instead.', 'hiregen-recruitment' ); ?></p>
          <?php get_search_form(); ?>
        </div>
    <?php endif; ?>
  </div><!-- /.container -->
</main>

<?php
get_footer();
