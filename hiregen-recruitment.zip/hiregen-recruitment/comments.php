<?php
/**
 * Template for displaying comments and the comment form.
 *
 * @package Hiregen
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/*
 * If the post is password protected, return early: comments are not shown.
 */
if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="comments-area" aria-live="polite">

	<?php if ( have_comments() ) : ?>
		<h2 class="comments-title">
			<?php
			$comments_number = get_comments_number();

			/* translators: 1: number of comments, 2: post title */
			$comments_title = sprintf(
				/* translators: singular and plural forms. */
				_nx(
					'One reply to &ldquo;%2$s&rdquo;',
					'%1$s replies to &ldquo;%2$s&rdquo;',
					$comments_number,
					'comments title',
					'hiregen-recruitment'
				),
				number_format_i18n( $comments_number ),
				'<span>' . esc_html( get_the_title() ) . '</span>'
			);

			// $comments_title contains limited HTML (<span>), allow it through safe KSES.
			echo wp_kses_post( $comments_title );
			?>
		</h2>

		<ol class="comment-list">
			<?php
			// Output the comments. Callback may be provided by the theme via functions.php.
			wp_list_comments(
				array(
					'style'      => 'ol',
					'short_ping' => true,
					'avatar_size'=> 64,
				)
			);
			?>
		</ol>

		<?php
		// Comments navigation (previous/next links).
		the_comments_navigation();
		?>

	<?php endif; // have_comments() ?>

	<?php
	// If comments are closed and there are comments, display a note.
	if ( ! comments_open() && get_comments_number() ) :
		?>
		<p class="no-comments"><?php echo esc_html__( 'Comments are closed.', 'hiregen-recruitment' ); ?></p>
	<?php endif; ?>

	<?php
	// Only show the comment form if comments are open for this post.
	if ( comments_open() ) {

		$comment_form_args = array(
			'title_reply'          => esc_html__( 'Leave a Reply', 'hiregen-recruitment' ),
			'title_reply_before'   => '<h3 id="reply-title" class="comment-reply-title">',
			'title_reply_after'    => '</h3>',
			'comment_notes_before' => '<p class="comment-notes">' . wp_kses_post( __( 'Your email address will not be published. Required fields are marked *', 'hiregen-recruitment' ) ) . '</p>',
			'label_submit'         => esc_html__( 'Post Comment', 'hiregen-recruitment' ),
		);

		comment_form( $comment_form_args );
	}
	?>

</div>
